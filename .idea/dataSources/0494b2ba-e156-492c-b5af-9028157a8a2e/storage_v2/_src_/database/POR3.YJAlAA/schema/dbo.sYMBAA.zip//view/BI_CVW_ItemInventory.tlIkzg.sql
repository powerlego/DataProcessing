-- SQL Deploy  3/29/2018 8:38 AM
CREATE View [dbo].[BI_CVW_ItemInventory]
 
AS
Select Items.NUM, Items.CurrentStore
, SUM(Items.Price) as [Total Rental Cost]
, SUM(Trans.Qty * Items.PriceEach) as [Total On Rent Cost]
, 'SERIALIZED RENTAL' as [Item Type] 
from
(select	i.NUM,i.CurrentStore, p.PriceEach, SUM(p.QuantityPurchased * p.PriceEach) as Price
from ItemFile i
left outer join 
ItemPurchaseDetail p
on i.NUM = p.ItemNumber
where PATINDEX('%#%',i.[KEY]) > 0 and i.QTY > 0  and i.TYPE NOT IN ('V', 'S','F','B','M','W', 'P', 'E','I', 'O')
group by i.NUM,i.CurrentStore, p.PriceEach) Items
LEFT OUTER JOIN
(select	Tr.CNTR,
TransactionItems.ITEM, 
TransactionItems.Qty as Qty
from Transactions Tr
inner join
TransactionItems
ON Tr.CNTR = TransactionItems.CNTR
where Tr.stat like 'O_') Trans
ON Items.NUM = Trans.ITEM
group by Items.NUM, Items.CurrentStore
UNION
 
Select Items.NUM, Items.CurrentStore
, SUM(Items.Price) as [Total Rental Cost]
, SUM(Trans.Qty * Items.PriceEach) as [Total On Rent Cost]
, 'BULK RENTAL' as [Item Type] 
from
(select	i.NUM,i.CurrentStore, p.PriceEach, SUM(p.QuantityPurchased * p.PriceEach) as Price
from ItemFile i
left outer join 
ItemPurchaseDetail p
on i.NUM = p.ItemNumber
where PATINDEX('%#%',i.[KEY]) = 0 and i.QTY > 0  and i.TYPE NOT IN ('V', 'S','F','B','M','W', 'P', 'E','I', 'O')
group by i.NUM,i.CurrentStore, p.PriceEach) Items
LEFT OUTER JOIN
(select	Tr.CNTR, Tr.STR
,TransactionItems.ITEM, 
TransactionItems.Qty as Qty
from Transactions Tr
inner join
TransactionItems
ON Tr.CNTR = TransactionItems.CNTR
where Tr.stat like 'O_') Trans
ON Items.NUM = Trans.ITEM
group by Items.NUM, Items.CurrentStore

go

