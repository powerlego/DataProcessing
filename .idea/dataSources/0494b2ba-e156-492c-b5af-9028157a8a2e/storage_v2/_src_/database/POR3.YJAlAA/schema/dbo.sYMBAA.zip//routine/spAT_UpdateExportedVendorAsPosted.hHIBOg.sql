
CREATE PROCEDURE [dbo].[spAT_UpdateExportedVendorAsPosted](
 @pilAxpId int 
,@pisType varchar(4)
,@pilObjId int
,@pilBusAreaId Int
,@posErrorMsg varchar(512) OUTPUT -- any user / server error
) 
--WITH ENCRYPTION 
AS

SET NOCOUNT ON
SET @posErrorMsg = NULL
DECLARE @lErrorNo Int

     DECLARE @bUpdateSupp Bit,
		     @AccountingVendorId Int,
 		     @AccountingLink VarChar(25),
		     @VendorNumber int

	UPDATE dbo.AccountingAPIQueueVendor
		 SET DatePosted = GetDate(),
			 DateChanged = GetDate()
	   WHERE [AccountingAPIQueueVendorId] = @pilObjId

   SELECT @AccountingVendorId = ISNULL(vf.AccountingVendorId,0),
		  @VendorNumber = vf.VendorNumber
	 FROM VendorFile vf
	INNER JOIN AccountingAPIQueueVendor aqv on aqv.VendorNumber = vf.VendorNumber
	WHERE aqv.AccountingAPIQueueVendorId = @pilObjId

   IF (@AccountingVendorId = 0)
   BEGIN
		INSERT INTO AccountingVendor(AccountingLink, [Disabled])
							  VALUES (CAST(@VendorNumber AS VARCHAR(12)), 0)

		SELECT @AccountingVendorId = SCOPE_IDENTITY()
		SELECT @AccountingLink = CAST(@VendorNumber AS VARCHAR(12))

		UPDATE VendorFile
		   SET AccountingVendorId = @AccountingVendorId,
			   GLLink = @VendorNumber
		  FROM AccountingAPIQueueVendor 
		 WHERE AccountingAPIQueueVendor.VendorNumber = VendorFile.VendorNumber
		   AND AccountingAPIQueueVendor.AccountingAPIQueueVendorId = @pilObjId

   END
   ELSE
   BEGIN
		SET @AccountingLink = (SELECT av.AccountingLink
								 FROM AccountingVendor av
								INNER JOIN VendorFile vf on vf.AccountingVendorId = av.id
								WHERE vf.VendorNumber = @VendorNumber)
	END
		
	UPDATE AccountingAPIQueueVendor
	SET ExternalId = @AccountingLink
	WHERE AccountingAPIQueueVendorId = @pilObjId

RETURN

go

grant execute on spAT_UpdateExportedVendorAsPosted to PORUser
go

