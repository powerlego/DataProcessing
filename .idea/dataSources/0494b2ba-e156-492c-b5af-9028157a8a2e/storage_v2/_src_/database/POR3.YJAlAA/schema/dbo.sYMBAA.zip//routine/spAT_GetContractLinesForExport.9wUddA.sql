
CREATE PROCEDURE [dbo].[spAT_GetContractLinesForExport](
	@pilIvcId Int
) 
-- WITH ENCRYPTION
AS
-- Note also used by THC30
SET NOCOUNT ON
 
DECLARE
 @sLCTNominalCode Varchar(20)
,@sLCTNominalName Varchar(80)
,@sLCTDescription Varchar(128)
,@cLCTValue Money
,@sLCTTaxCode Varchar(5)
,@nLCTTaxRate Real
,@cLCTTaxValue Money
SET @sLCTTaxCode = NULL
SET @cLCTValue = NULL
 
IF EXISTS (SELECT 1 FROM dbo.TaxTable)

SELECT 
 ISNULL(TrD.OffsetAccountNumber,'')													AS IVL_NOMINAL_LEDGER_CODE
,'Income'																			AS NMC_NAME
,ISNULL(Tx.AccountingLink,'')														AS IVL_TAX_CODE
,CASE WHEN Trd.LineItemTypeId = 2
	  THEN CAST((ABS(Tr.TaxAmount) / ABS(tr.TotalAmount)) AS REAL)
	  ELSE CAST(0 AS REAL) END														AS IVL_LINE_TAX_RATE
,CASE WHEN Trd.LineItemTypeId = 2
	  THEN CAST(Tr.TaxAmount AS DECIMAL(12,2))
	  ELSE CAST(0 AS DECIMAL(12,2)) 														
	  END																			AS IVL_TAX_AMOUNT
,REPLACE(ISNULL(TrD.ItemMemo, ''),'Sales Tax','Tax')								AS IVL_DETAILS
,CASE WHEN Trd.LineItemTypeId = 2
	  THEN CAST(0 AS DECIMAL(12,2)) 
	  ELSE CASE WHEN Tr.TransCodeId In (40,43) THEN CAST(-TrD.ItemAmount AS DECIMAL(12,2)) 
	            ELSE CAST(TrD.ItemAmount AS DECIMAL(12,2)) END  														
	  END																			AS IVL_CHARGE
,Tr.CustomerPONumber																AS IVL_CUSTOMER_REFERENCE
,Tr.ContractNumber																    AS DispCONTRACTNUMBER
,'Hct'																				AS InvoiceSource
,''																					AS CreditNoteNumber
,ISNULL(TrD.ItemNumber,'')															AS DispSTOCKNUMBER
,TrD.LineNumber																		AS ORDERBY1
,i.[KEY]																			AS IVL_CURR_EQUIPMENT_CODE
,i.[Num]																			AS IVL_CURR_STOCKNO
,ti.DDT																				AS IVL_DATE_FROM
,NULL																			    AS IVL_DATE_TO
,Cast(TrD.ItemQuantity As Varchar(12))												AS IVL_QUANTITY
,CASE WHEN Trd.LineItemTypeId = 2
	  THEN CAST(0 AS DECIMAL(12,2)) 
	  ELSE CASE WHEN TrD.ItemQuantity = 0 
				THEN CASE WHEN Tr.TransCodeId In (40,43) THEN (-TrD.ItemAmount) ELSE (TrD.ItemAmount) END
				ELSE CASE WHEN Tr.TransCodeId In (40,43) THEN (-TrD.ItemAmount / Trd.ItemQuantity) ELSE (TrD.ItemAmount / Trd.ItemQuantity) END
			END 														
	  END																			AS IVL_UNIT_PRICE
,Replace(TrD.ItemMemo,'Sales Tax', 'Tax')											AS IVL_NOTES
,'Main'																				AS ADR_NAME
,ISNULL(cst.Address,'') + ' ' + ISNULL(cst.Address2, '') + ' ' + 
 ISNULL(cst.CITY, '') + ' ' + ISNULL(cst.ZIP,'')									AS SiteAddress
,''																					AS SKI_PROVISIONAL_TYPE
,''																					AS IsCreditedForInvNo
,''																				    AS IVL_PRICE_PER
,''																				    AS IVL_NOTES2
,ISNULL(adpt.AccountingLink,'')														AS IVL_ACCOUNTS_DEPT
,''																				    AS IVL_UNIT_TYPE
,CASE WHEN LEFT(ti.TXTY,1) = 'R' THEN 'HIRE'
      WHEN LEFT(ti.TXTY,1) = 'S' THEN 'SALE'
      ELSE 'MISC' END																AS IVL_ITEM_TYPE
,0																					AS DURATION_PERIOD_QTY
,0																					AS DURATION_PERIOD_DAY_QTY
,''																				    AS LineReference
,''																				    AS HireChargePeriod
, ISNULL(ti.Nontaxable,t.Nontaxable)												AS NonTaxable
, Tr.Store																			AS StoreNumber
, TrD.LineItemTypeId																AS LineItemTypeId
FROM AccountingAPIQueueTr Tr
INNER JOIN AccountingAPIQueueTRDetail TrD On TrD.AccountingAPIQueueTRId = Tr.Id
INNER JOIN AccountNumbers A On A.Store = Tr.Store
INNER JOIN Transactions t On t.CNTR = Tr.ContractNumber
LEFT OUTER JOIN TransactionItems ti On ti.CNTR = Tr.ContractNumber and ti.LineNumber = Trd.LineNumber
LEFT OUTER JOIN CustomerFile cst on cst.CNUM = Tr.CustomerNumber
LEFT OUTER JOIN ItemFile i ON i.NUM = TrD.ItemNumber
LEFT OUTER JOIN ItemDepartment IDpt ON i.Department = iDpt.Department
LEFT OUTER JOIN AccountingDepartment aDpt ON IDpt.AccountingDepartmentId = aDpt.Id
LEFT OUTER JOIN TaxTable Tx ON Tx.TaxCode = (CASE WHEN ISNULL(t.TaxCode,0) = 0 THEN cst.TaxCode ELSE t.TaxCode END)
WHERE   Tr.Id = @pilIvcId
AND Trd.LineItemTypeId NOT IN (6)

RETURN
go

grant execute on spAT_GetContractLinesForExport to PORUser
go

