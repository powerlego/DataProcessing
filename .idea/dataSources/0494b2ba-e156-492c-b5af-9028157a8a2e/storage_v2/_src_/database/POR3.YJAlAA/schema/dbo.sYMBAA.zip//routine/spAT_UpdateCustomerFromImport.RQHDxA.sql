
CREATE PROCEDURE [dbo].[spAT_UpdateCustomerFromImport](
 @pisAccNo Varchar(20)
,@picCST_ACCT_BALANCE Money
,@picCST_CREDIT_LIMIT Money
,@pibCST_ON_HOLD Bit
,@picCST_AGED_DEBT_1 Money
,@picCST_AGED_DEBT_2 Money
,@picCST_AGED_DEBT_3 Money
,@picCST_AGED_DEBT_4 Money
,@picCST_AGED_DEBT_5 Money
,@pisCST_UNPAID_INVS Varchar(2000)
,@posErrorMsg varchar(512) OUTPUT -- any user / server error
) 
--WITH ENCRYPTION 
AS
SET NOCOUNT ON
DECLARE @lErrorNo int
SET @posErrorMsg = NULL

--IF EXISTS (SELECT 1
--           FROM   dbo.TH_CUSTOMERS 
--           WHERE  CST_ACCOUNT_NUMBER = @pisAccNo)
--BEGIN
--  -- Clear export flag if we have just created the customer from accounts
--  UPDATE dbo.TH_CUSTOMERS 
--  SET  
--   CST_ACCT_BALANCE = @picCST_ACCT_BALANCE 
--  ,CST_CREDIT_LIMIT = @picCST_CREDIT_LIMIT
--  ,CST_ON_HOLD = COALESCE(@pibCST_ON_HOLD, CST_ON_HOLD)
--  ,CST_UNPAID_INVS = @pisCST_UNPAID_INVS
--  ,CST_AGED_DEBT_1 = @picCST_AGED_DEBT_1
--  ,CST_AGED_DEBT_2 = @picCST_AGED_DEBT_2
--  ,CST_AGED_DEBT_3 = @picCST_AGED_DEBT_3
--  ,CST_AGED_DEBT_4 = @picCST_AGED_DEBT_4
--  ,CST_AGED_DEBT_5 = @picCST_AGED_DEBT_5
--  ,CST_EXPORT_FLAG =
--     CASE WHEN CST_EXPORT_FLAG = 1 AND 
--               dbo.fnlbTruncDate(CST_DATE_CREATED) = dbo.fnlbTruncDate(GETDATE())
--          THEN 0 ELSE CST_EXPORT_FLAG END
--  WHERE CST_ACCOUNT_NUMBER = @pisAccNo
  
--  EXEC @lErrorNo = dbo.splbTestError @@ERROR, 'spAT_UpdateCustomerFromImport\100', @posErrorMsg output
--  IF @lErrorNo != 0 RETURN @lErrorNo
--END

RETURN
go

grant execute on spAT_UpdateCustomerFromImport to PORUser
go

