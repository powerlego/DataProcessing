create view OpenSales as
SELECT TransactionItems.CNTR         AS [Contract Number],
       CustomerFile.NAME             as [Customer Name],
       Transactions.DATE             AS [Transaction Date],
       Salesman.Name                 AS [Transaction Sales Rep],
       TransactionItems.ITEM         as [Item No],
       ItemFile.Name                 as [Item Name],
       TransactionItems.QTY,
       TransactionItems.PRIC         as [Sales Price],
       ItemDepartment.DepartmentName as [Item Department],
       ItemFile.CurrentStore         AS [Location],
       Transactions.DeliveryDate,
       Transactions.DeliveryAddress,
       Transactions.DeliveryCity,
       Transactions.DeliveryZip,
       Transactions.Contact          as [Delivery Contact],
       Transactions.ContactPhone     as [Delivery Contact Phone Num],
       CustomerFile.Terms,
       CustomerFile.BillContact,
       CustomerFile.BillPhone,
       CustomerFile.BillAddress1,
       CustomerFile.BillAddress2,
       CustomerFile.BillCityState,
       CustomerFile.BillZip,
       CustomerFile.BillZip4,
       CustomerFile.Email,
       CustomerFile.FAX,
       Transactions.TaxCode,
       Transactions.JBPO,
       Transactions.Notes,
       Transactions.JBID,
       TransactionType.TypeName,
       TransactionItems.Comments,
       Transactions.EventEndDate,
       Transactions.ReviewBilling,
       TaxTable.TaxRent1,
       Transactions.PickupDate
FROM TransactionItems
         LEFT JOIN Transactions on Transactions.CNTR = TransactionItems.CNTR
         LEFT JOIN ItemFile on TransactionItems.ITEM = ItemFile.NUM
         LEFT JOIN CustomerFile on Transactions.CUSN = CustomerFile.CNUM
         LEFT JOIN ItemDepartment on ItemFile.Department = ItemDepartment.Department
         INNER JOIN (SELECT DISTINCT CustomerFile.NAME        as Customer_Name,
                                     Transactions.TOTL        as Transaction_Total,
                                     Transactions.STAT        as Transaction_Status,
                                     Transactions.CNTR        as Transaction_Contract,
                                     Transactions.PAID,
                                     Transactions.CLDT        as Transaction_Close_Date,
                                     Salesman_Cntr.Name       as Contract_Sales_Rep_Name,
                                     TransactionType.TypeName as Transaction_Type,
                                     Salesman_customer.Name   as Customer_Sales_Rep_Name,
                                     Salesman_jobsite.Name    as Jobsite_Sales_Rep_Name,
                                     Transactions.DEPP        as Deprication,
                                     CustomerFile.CurrentBalance,
                                     CustomerFile.Terms
                     FROM Transactions
                              LEFT OUTER JOIN CustomerFile ON Transactions.CUSN = CustomerFile.CNUM
                              LEFT OUTER JOIN Salesman Salesman_Cntr ON Transactions.Salesman = Salesman_Cntr.Number
                              LEFT OUTER JOIN CustomerJobSite ON Transactions.JobSite = CustomerJobSite.Number
                              LEFT OUTER JOIN TransactionType
                                              ON Transactions.TransactionType = TransactionType.TypeNumber
                              LEFT OUTER JOIN TransactionOperation
                                              ON Transactions.Operation = TransactionOperation.OperationNumber
                              LEFT OUTER JOIN ParameterFile ON Transactions.STR = ParameterFile.Store
                              LEFT OUTER JOIN Salesman Salesman_jobsite
                                              ON CustomerJobSite.Salesman = Salesman_jobsite.Number
                              LEFT OUTER JOIN CustomerType ON CustomerFile.Type = CustomerType.Type
                              LEFT OUTER JOIN Salesman Salesman_customer
                                              ON CustomerFile.Salesman = Salesman_customer.Number
                     WHERE (Transactions.TOTL <> Transactions.PAID OR Transactions.DEPP <> 0)
                       AND Transactions.Archived = 0
                       AND Transactions.PYMT <> N'T'
                       AND Transactions.STAT NOT LIKE 'R%'
                       AND Transactions.STAT NOT LIKE 'Q%'
                       AND Transactions.STAT NOT LIKE 'C%') Q ON Q.Transaction_Contract = TransactionItems.CNTR
         LEFT JOIN Salesman on Transactions.Salesman = Salesman.Number
         LEFT JOIN TransactionType on Transactions.TransactionType = TransactionType.TypeNumber
         LEFT JOIN TaxTable on Transactions.TaxCode = TaxTable.TaxCode
go

