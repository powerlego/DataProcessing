
CREATE  PROCEDURE [dbo].[spAT_GetPayableLinesForExport](
 @pilPivId Int
) 
-- WITH ENCRYPTION
AS
SET NOCOUNT ON

SELECT 
 ISNULL(pil.AccountNumber,'')									AS PIL_NOMINAL_CODE
,ISNULL(nmc.GLAccount,'')										AS NMC_NAME
,REPLACE(pil.Reference, CHAR(13) + CHAR(10), '; ')				AS PIL_DESCRIPTION
,pil.Amount														AS PIL_NET_AMOUNT
,ISNULL(txc.AccountingLink,ISNULL(vtxc.AccountingLink, ''))		AS PIL_TAX_CODE
,CASE WHEN CHARINDEX(UPPER(ISNULL(ITEMFILE.[TYPE],'xx')),'TL HURANVKD') > 0
		  THEN CASE WHEN pf.CapitalizeExtraCharges = 1
					THEN 0
					ELSE CAST((pod.taxeach * pod.QuantityReceived) AS Decimal(12,2))
					END
	  WHEN CHARINDEX(UPPER(ISNULL(ITEMFILE.[TYPE],'xx')),'SFMPEWB') > 0
		  THEN CASE WHEN pf.InventoryExtraCharges = 1
					THEN 0
					ELSE CAST((pod.taxeach * pod.QuantityReceived) AS Decimal(12,2))
					END
	  ELSE CAST((pod.taxeach * pod.QuantityReceived) AS Decimal(12,2)) 
	  END														AS PIL_TAX_AMOUNT
,CAST(ISNULL(txc.TaxSale1,0) AS Real)							AS TXC_RATE
,ISNULL(adpt.AccountingLink,'')									AS PIL_ACCOUNTS_DEPT
,piv.Store														AS StoreNumber

FROM  ((((dbo.AccountingAPIQueuePOdetail	AS pil
       INNER JOIN dbo.AccountingAPIQueuePO AS piv
         ON pil.AccountingAPIQueuePOid = piv.AccountingAPIQueuePOId)
	   INNER JOIN dbo.PurchaseOrder AS po
	     ON po.PONumber = piv.PONumber
	   INNER JOIN dbo.PurchaseOrderDetail AS pod 
	     ON pod.PONumber = pil.PONumber AND pod.LineNumber = pil.LineNumber
	   INNER JOIN dbo.ParameterFile AS pf
	     ON pf.Store = po.Store
       LEFT OUTER JOIN dbo.TaxTable AS txc
         ON po.TaxCode = txc.TaxCode)
       LEFT OUTER JOIN dbo.PurchaseOrderGL AS nmc
         ON pod.GLNumber = nmc.[Number])
	   INNER JOIN VendorFile vf 
	     ON vf.VendorNumber = piv.VendorNumber)
       LEFT OUTER JOIN dbo.TaxTable AS vtxc
         ON vf.TaxCode = vtxc.TaxCode
	   LEFT OUTER JOIN ItemFile
	     ON ITEMFILE.NUM = pod.ItemNumber
	   LEFT OUTER JOIN ItemDepartment IDpt
	     ON ItemFile.Department = iDpt.Department
	   LEFT OUTER JOIN AccountingDepartment aDpt
	     ON IDpt.AccountingDepartmentId = aDpt.Id

WHERE pil.AccountingAPIQueuePOid = @pilPivId
AND   (COALESCE(pil.Amount,0) <> 0)
ORDER BY pil.LineNumber

RETURN

go

grant execute on spAT_GetPayableLinesForExport to PORUser
go

