
CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_GetReservationValue] 
	@WidgetDataFilter KeyValuePair READONLY

AS
BEGIN
SET NOCOUNT ON;
DECLARE	
		@Style Int = 2,
		@DateGrouping	nVarchar(16) = null,
        @StoreNo		VarChar(3) = null,
        @StartDate      Date,
        @EndDate        Date,
		@DateFormat		nvarchar(5) = 'en-US';

SELECT @StoreNo = SUBSTRING([Value], 1, 20) FROM @WidgetDataFilter WHERE [Key] = 'StoreNo';
SELECT @Style = CAST([Value] AS INT) FROM @WidgetDataFilter WHERE [Key] = 'PeriodStyle';
SELECT @StartDate = CAST([Value] AS DATETIME) FROM @WidgetDataFilter WHERE [Key] = 'CurrentDate';

IF @StartDate IS NULL
	BEGIN
	SET @StartDate = GETDATE();
	END

IF (@Style = 1)
       BEGIN
	   SET @DateGrouping = 'Daily';
	   SET @EndDate = DATEADD(day, 7, @StartDate);
       END
ELSE IF (@Style = 2)
       BEGIN
	   SET @DateGrouping = 'Monthly';
	   SET @EndDate = DATEADD(month, 12, @StartDate);
       END

ELSE IF (@Style = 3)
		BEGIN
		SET @DateGrouping = 'Quarterly';
		SET @EndDate = DATEADD(YEAR,2,DATEADD(yy,DATEDIFF(yy, 0, @StartDate),0));
        END

ELSE IF (@Style = 4)
		BEGIN
		SET @DateGrouping = 'Yearly';
		SET @EndDate = DATEADD(YEAR,8,DATEADD(yy,DATEDIFF(yy, 0, @StartDate),0));
		END  

ELSE IF (@Style = 5)
	   BEGIN
	   SET @DateGrouping = 'All';
	   SET @EndDate = DATEADD(YEAR,12,DATEADD(yy,DATEDIFF(yy, 0, @StartDate),0));
       END
	

CREATE TABLE #Reservation_Tbl (
    [Date] [nvarchar](50),
	[Period] [nvarchar](50),
	[ReservationValue] Decimal(9,2)
)

-- ====================================
-- Split up to allow for proper ordering
-- ====================================
IF(@Style = 1) -- Next 7 days (daily)
	BEGIN

		INSERT INTO #Reservation_Tbl
			([Date],[Period], [ReservationValue])
	
		SELECT	FORMAT(Resertbl.[date], 'd', @DateFormat) AS [Date],
				@DateGrouping as Period, 
				SUM(Resertbl.ReservationValue) as [ReservationValue]
		FROM
				(SELECT MAX(T.[Date]) as [Date],
					SUM(IIF(t.[Date] >= @StartDAte, T.totl,0)) AS ReservationValue
 					FROM dbo.Transactions T
					WHERE T.[date] >= @StartDate AND T.[date] < @EndDate 
						AND (@StoreNo IS NULL OR @StoreNo = 'All' OR @StoreNo = '000' OR (@StoreNo LIKE '%' + T.[STR] + '%'))
						AND RIGHT(Left(T.[STAT] + '  ',2),1) Not In ('C') 
						AND LEFT(T.CNTR,1) Not In ('h','l','q','s','t')
					GROUP BY DATEPART(yy, T.[Date]), DATEPART(mm, T.[Date]), DATEPART(dd, T.[Date])
				) AS Resertbl
		GROUP BY FORMAT(Resertbl.[date], 'd', @DateFormat), Resertbl.[Date]
		ORDER by DATEPART(yy, Resertbl.[Date]), DATEPART(mm, Resertbl.[Date]), DATEPART(dd, Resertbl.[date]) ASC

	END
ELSE IF(@Style = 2) --Monthly
	BEGIN

		INSERT INTO #Reservation_Tbl
			([Date],[Period], [ReservationValue])

		SELECT	FORMAT(Resertbl.[date], 'y', @DateFormat) AS [Date],
				@DateGrouping as Period, 
				SUM(Resertbl.ReservationValue) as [ReservationValue]
		FROM
			 (SELECT MAX(T.[Date]) as [Date],
					SUM(IIF(t.[Date] >= @StartDate, T.totl,0)) AS ReservationValue
 					FROM dbo.Transactions T
					WHERE T.[date] >= @StartDate AND T.[date] < @EndDate 
							AND (@StoreNo IS NULL OR @StoreNo = 'All' OR @StoreNo = '000' OR T.[STR] = @StoreNo)
							AND RIGHT(Left(T.[STAT] + '  ',2),1) Not In ('C') 
							AND LEFT(T.CNTR,1) Not In ('h','l','q','s','t')
					GROUP BY DATEPART(yy, T.[Date]), DATEPART(mm, T.[Date])
			 ) AS Resertbl
		GROUP BY DATEPART(yy, Resertbl.[Date]), DATEPART(mm, Resertbl.[Date]), FORMAT(Resertbl.[date], 'y', @DateFormat), Resertbl.Date
		ORDER BY DATEPART(yy, Resertbl.[Date]), DATEPART(mm, Resertbl.[Date]) asc

	END
ELSE -- quarterly, yearly, all
	BEGIN

		INSERT INTO #Reservation_Tbl
			([Date],[Period], [ReservationValue])

		SELECT (Resertbl.PeriodLabel) as [Date], 
			@DateGrouping as Period, 
			SUM(Resertbl.ReservationValue) as [ReservationValue]
		FROM
			 (SELECT IIF(@DateGrouping='Quarterly', IIF((t.[date]) >= @startDate,t.totl,0), 
						IIF(@DateGrouping='Yearly',   iif((t.[date]) >= @startdate,t.totl,0),t.totl)) AS ReservationValue,
					IIF(@DateGrouping='Quarterly',concat(year(t.[date]),'-Q',DATEPART(QUARTER, t.[date])),
 						IIF(@DateGrouping='Yearly',convert(varchar(50),year(t.[date])),'All')) AS PeriodLabel
 					FROM dbo.Transactions T
					WHERE T.[date] >= @StartDate AND T.[date] < @EndDate 
						AND (@StoreNo IS NULL OR @StoreNo = 'All' OR @StoreNo = '000' OR T.[STR] = @StoreNo)
						AND RIGHT(Left(T.[STAT] + '  ',2),1) Not In ('C') 
						AND LEFT(T.CNTR,1) Not In ('h','l','q','s','t')
			 ) AS Resertbl
		GROUP BY Resertbl.PeriodLabel
		ORDER by Resertbl.PeriodLabel
	 
	END

-- =============================

SELECT * FROM #Reservation_Tbl
DROP TABLE #Reservation_Tbl;

END
go

