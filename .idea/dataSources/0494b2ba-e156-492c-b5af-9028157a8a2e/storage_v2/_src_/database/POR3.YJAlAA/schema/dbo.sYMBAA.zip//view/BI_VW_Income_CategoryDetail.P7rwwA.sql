CREATE VIEW [dbo].[BI_VW_Income_CategoryDetail]
 
AS 
SELECT CategoryIncomeDetail.Batch, 
       CategoryIncomeDetail.TransactionStore, 
	   CategoryIncomeDetail.ItemStore, 
	   CategoryIncomeDetail.TransactionDate, 
	   ItemCategory.Name AS [Category Name], 
	   CategoryIncomeDetail.AccountingMethodCode, 
	   IncomeType.Description, 
	   CategoryIncomeDetail.IncomeAmount, 
	   CategoryIncomeDetail.CNTR, 
	   ItemFile.[KEY], 
	   ItemFile.Name, 
	   ItemFile.Header, 
	   VendorFile.VendorName
 FROM (((CategoryIncomeDetail LEFT JOIN ItemCategory ON CategoryIncomeDetail.Category = ItemCategory.Category) 
 LEFT JOIN ItemFile ON CategoryIncomeDetail.ItemNumber = ItemFile.NUM) 
 LEFT JOIN IncomeType ON CategoryIncomeDetail.IncomeTypeCode = IncomeType.IncomeTypeCode) 
 LEFT JOIN VendorFile ON ItemFile.VendorNumber1 = VendorFile.VendorNumber
go

