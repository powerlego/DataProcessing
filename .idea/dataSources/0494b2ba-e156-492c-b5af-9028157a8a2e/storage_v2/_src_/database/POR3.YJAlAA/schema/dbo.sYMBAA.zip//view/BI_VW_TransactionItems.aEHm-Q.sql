-- SQL Deploy  3/29/2018 8:38 AM
CREATE VIEW BI_VW_TransactionItems
 
AS
SELECT 0 AS BHISTORY,
TI.[CNTR] as [Trans_Item.Contract No]
,TI.[SUBF] as [Trans_Item.Contract Line No] 
,TI.[ITEM] as [Trans_Item.No]
,TI.[QTY] as [Trans_Item.Qty]
,TI.[HRSC] as [Trans_Item.Hours Rented]
,TI.[DDT] as [Trans_Item.Due Date]
,TI.[DTM] as [Trans_Item.Due Time]
,TI.[TXTY] as [Trans_Item.Line Status]
,TI.[PRIC] as [Trans_Item.Price]
,TI.[Desc] as [Trans_Item.Desc]
,TI.[Comments] as [Trans_Item.Comments]
,TI.[DmgWvr] as [Trans_Item.Damage Waiver]
,TI.[ItemPercentage]  as [Trans_Item.Item %]
,TI.[DiscountPercent] as [Trans_Item.Discount %]
,TI.[Nontaxable] as [Trans_Item.Non-Taxable]
,TI.[Nondiscount] as [Trans_Item.Non-Discountable]
 
 
,TI.[DiscountAmount] as [Trans_Item.Discount Amt]
,TI.[DailyAmount] as [Trans_Item.Daily Amt]
,TI.[WeeklyAmount] as [Trans_Item.Weekly Amt]
,TI.[MonthlyAmount] as [Trans_Item.Monthly Amt]
,TI.[MinimumAmount] as [Trans_Item.Minimum Amt]
,TI.[ReadingOut] as [Trans_Item.Meter Out]
,TI.[ReadingIn] as [Trans_Item.Meter In]
,TI.[RainHours] as [Trans_Item.Downtime Hrs]
 
,TI.[RetailPrice] as [Trans_Item.Retail Price]
,TI.[KitField] as [Trans_Item.Kit Field]
,TI.[ConfirmedDate] as [Trans_Item.Confirmed Date]
,TI.[SubrentQuantity] as [Trans_Item.Subrent Qty]
,TI.[Substatus] as [Trans_Item.Subrent Status]
 
,TI.[LineNumber] as [Trans_Item.Line No]
FROM [dbo].[TransactionItems] TI
UNION
SELECT 1 AS BHISTORY,
TIH.[CNTR] as [Trans_Item.Contract No]
,TIH.[SUBF] as [Trans_Item.Contract Line No]
,TIH.[ITEM] as [Trans_Item.No]
,TIH.[QTY] as [Trans_Item.Qty]
,TIH.[HRSC] as [Trans_Item.Hours Rented]
,TIH.[DDT] as [Trans_Item.Due Date]
,TIH.[DTM] as [Trans_Item.Due Time]
,TIH.[TXTY]  as [Trans_Item.Line Status]
,TIH.[PRIC] as [Trans_Item.Price]
,TIH.[Desc] as [Trans_Item.Desc]
,TIH.[Comments] as [Trans_Item.Comments]
,TIH.[DmgWvr] as [Trans_Item.Damage Waiver]
,TIH.[ItemPercentage]  as [Trans_Item.Item %]
,TIH.[DiscountPercent] as [Trans_Item.Discount %]
,TIH.[Nontaxable] as [Trans_Item.Non-Taxable]
,TIH.[Nondiscount] as [Trans_Item.Non-Discountable]
 
 
,TIH.[DiscountAmount] as [Trans_Item.Discount Amt]
,TIH.[DailyAmount] as [Trans_Item.Daily Amt]
,TIH.[WeeklyAmount] as [Trans_Item.Weekly Amt]
,TIH.[MonthlyAmount] as [Trans_Item.Monthly Amt]
,TIH.[MinimumAmount] as [Trans_Item.Minimum Amt]
,TIH.[ReadingOut] as [Trans_Item.Meter Out]
,TIH.[ReadingIn] as [Trans_Item.Meter In]
,TIH.[RainHours] as [Trans_Item.Downtime Hrs]
 
,TIH.[RetailPrice] as [Trans_Item.Retail Price]
,TIH.[KitField] as [Trans_Item.Kit Field]
,TIH.[ConfirmedDate] as [Trans_Item.Confirmed Date]
,TIH.[SubrentQuantity] as [Trans_Item.Subrent Qty]
,TIH.[Substatus] as [Trans_Item.Subrent Status]
 
,TIH.[LineNumber] as [Trans_Item.Line No]
FROM [dbo].[TransItemsHistory] TIH

go

