
CREATE VIEW qryDataMarketing
AS
SELECT CustomerFile.[KEY] AS CustomerKey, 
              CustomerFile.[NAME] AS CustomerName, 
              Authorized.[Name] AS ContactName, 
              Authorized.ActiveDate AS ContactActiveDate, 
              Authorized.Department AS ContactDepartment, 
              Authorized.Phone AS ContatPhone, 
              Authorized.MOBILE AS ContactMobile, 
              Authorized.Fax AS ContactFax, 
              Authorized.Email AS ContactEmail, 
              CustomerFile.Email AS CustomerEmail, 
              CustomerFile.Address, 
              CustomerFile.Address2, 
              CustomerFile.CITY, 
              CustomerFile.ZIP, 
              CustomerFile.ZIP4, 
              CustomerFile.Birthdate, 
              CustomerFile.Employer, 
              CustomerFile.Phone, 
              CustomerFile.WORK, 
              CustomerFile.MOBILE, 
              CustomerFile.FAX, 
              CustomerFile.PAGER, 
              CustomerFile.CNUM, 
              CustomerFile.OpenDate, 
              CustomerFile.LastActive, 
              CustomerFile.CreditLimit, 
              IIf([CustomerFile].[Status]='E','Account','Cash') AS Status, 
              CASE [CustomerFile].[Restrictions]
                     When 'K' Then 'No Checks'
                     When 'D' Then 'No Deposits'
                     When 'R' Then 'Pay-on-Return'
                     When 'S' Then 'Sales Only'
                     When 'U' Then 'Undesirable'
                     When 'W' Then 'Wanted'
                     When 'C' Then 'Closed'
                     When 'H' Then 'Credit Hold'
                     When '3' Then 'Allow 60 Days'
                     When '6' Then 'Allow 90 Days'
                     When '9' Then 'Allow 120 Days'
                     When 'N' Then 'Allow Any Days'
                     When 'O' Then 'Pay-on-Open'
                     Else 'Unknown' 
              End AS Options, 
              CustomerFile.IncomeYear, 
              CustomerFile.IncomeLastYear, 
              CustomerFile.IncomeLife, 
              CustomerFile.NumberContracts, 
              CustomerFile.TaxCode, 
              CustomerType.[Description] AS CustomerType, 
              CustomerFile.DeleteDmgWvr, 
              CustomerFile.DeleteFinanceCharge, 
              CustomerFile.LastPayDate, 
              CustomerFile.HighBalance, 
              CustomerFile.CurrentBalance, 
              Salesman.[Name] AS SalesmanName, 
              CustomerFile.DeleteItemPercentage, 
              CustomerFile.BillContact, 
              CustomerFile.BillPhone, 
              CustomerFile.BillAddress1, 
              CustomerFile.BillAddress2, 
              CustomerFile.BillCityState, 
              CustomerFile.BillZip, 
              CustomerFile.BillZip4, 
              CustomerFile.TaxId, 
              CustomerFile.TaxExemptNumber, 
              CustomerFile.TaxExemptExpire, 
              CustomerFile.InsuranceNumber, 
              CustomerFile.InsuranceExpire, 
              CustomerFile.Terms, 
              CustomerFile.FinanceChargeDays, 
              CustomerFile.FederalId, 
              CustomerFile.UserDefined1, 
              CustomerFile.UserDefined2, 
              CustomerFile.PriceLevel, 
              CustomerHeard.HeardName AS CustomerHeard, 
              CustomerFile.NoEmail AS NoMarketingEmails, 
              CustomerFile.ContractorLicense, 
              CustomerFile.ContractorExpire, 
              CustomerFile.WebsitePortal, 
              CustomerFile.MonthToMonth, 
              CustomerTypePricing.[Description] AS CustomerPricingType, 
              CustomerGroup.GroupName AS CustomerGroup, 
              CommissionLevelCustomer.[Description] AS CustomerCommissionLevel, 
              CustomerFile.[Language] AS CustomerLanguage
   FROM Salesman 
  RIGHT JOIN CustomerFile   ON Salesman.Number = CustomerFile.Salesman 
  RIGHT JOIN CustomerType ON CustomerType.Type = CustomerFile.Type
   LEFT JOIN Authorized                         ON CustomerFile.CNUM = Authorized.CNUM
   LEFT JOIN CustomerHeard                      ON CustomerFile.HeardAboutUs = CustomerHeard.HeardNumber
   LEFT JOIN CustomerTypePricing         ON CustomerFile.PricingType = CustomerTypePricing.PricingType 
   LEFT JOIN CustomerGroup                      ON CustomerFile.[Group] = CustomerGroup.CustomerGroup 
   LEFT JOIN CommissionLevelCustomer     ON CustomerFile.CommissionLevel = CommissionLevelCustomer.CommissionLevelCustomer
   --FROM ((((Salesman 
   --RIGHT JOIN (CustomerType 
   --RIGHT JOIN (CustomerFile 
   --LEFT JOIN Authorized ON CustomerFile.CNUM = Authorized.CNUM) ON CustomerType.Type = CustomerFile.Type) ON Salesman.Number = CustomerFile.Salesman) 
   --LEFT JOIN CustomerHeard ON CustomerFile.HeardAboutUs = CustomerHeard.HeardNumber) 
   --LEFT JOIN CustomerTypePricing ON CustomerFile.PricingType = CustomerTypePricing.PricingType) 
   --LEFT JOIN CustomerGroup ON CustomerFile.[Group] = CustomerGroup.CustomerGroup) 
   --LEFT JOIN CommissionLevelCustomer ON CustomerFile.CommissionLevel = CommissionLevelCustomer.CommissionLevelCustomer
       --WHERE (([Authorized].[InactiveDate])>GetDate() OR (IsNull([Authorized].[InactiveDate],0)<>0))
WHERE (IsNull([Authorized].[InactiveDate], GetDate()) > GetDate())


go

