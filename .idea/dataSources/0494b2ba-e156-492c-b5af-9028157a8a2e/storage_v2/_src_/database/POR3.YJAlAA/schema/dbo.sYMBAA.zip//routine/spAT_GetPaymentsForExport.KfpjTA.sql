
CREATE PROCEDURE [dbo].[spAT_GetPaymentsForExport](
 @pilBusAreaId Int
) 
-- WITH ENCRYPTION
AS
SET NOCOUNT ON

SELECT 
 Tr.TransDate										AS CTX_DATE
,Tr.Id											    AS CTX_ID
,CASE WHEN Tr.TransCodeId IN (40,43) 
		THEN ISNULL(Trd.OffsetAccountNumber,'')
	  ELSE ISNULL(Tr.AccountNumber,'') END			AS BANK_ACCOUNT	
,Tr.TransAmount										AS CTX_AMOUNT
,CASE WHEN Tr.TransCodeId IN (40,43) 
		THEN CAST(1 AS BIT)
	  ELSE CAST(0 AS BIT) END						AS IS_CREDIT
,CAST(1 AS Bit)										AS IS_CASH
,CASE WHEN Tr.TransCodeId IN (40,43) 
		THEN CAST(Tr.TransAmount AS Decimal(12,2))
	  ELSE CAST(0 AS Decimal(12,2)) END				AS CTX_UNALLOC_SA_AMOUNT
,NULL												AS CTX_UNALLOC_SA_TXID
,CASE WHEN Tr.TransCodeId IN (40,43) 
		THEN ''
	  ELSE Tr.ContractNumber END					AS IVC_USER_INVOICE_NUMBER
,CASE WHEN Tr.TransCodeId IN (40,43) 
		THEN 'CREDIT'
	  ELSE 'H' END									AS IVC_INVOICE_TYPE
,Tr.Id												AS IVC_UNPAID_TX_ID
,Tr.ContractNumber									AS SOURCE_DOC_REFNO
,'C'												AS SOURCE_DOC_TYPE
,Tr.Id												AS SOURCE_DOC_ID
--,CASE cf.Status
--	  WHEN 'E' THEN RTRIM(LTRIM(Tr.CustomerNumber))
--	  ELSE RTRIM(LTRIM(x.GenericCashCustomerNumber)) END AS ACCOUNT_NO
--,CASE WHEN ac.AccountingLink IS NOT NULL
--		THEN RTRIM(LTRIM(Tr.CustomerNumber))
--	  ELSE RTRIM(LTRIM(x.GenericCashCustomerNumber)) END AS ACCOUNT_NO
,RTRIM(LTRIM(ac.AccountingLink))					AS ACCOUNT_NO
,CASE WHEN Tr.TransCodeId = 13
		THEN 'Paid Prior to Close'
	  WHEN Tr.TransCodeId IN (40,43)
		THEN 'AR Credit'
	  ELSE '' END									AS CTX_NOTES
,''													AS ADJ_NOMINAL_CODE
,Tr.Store											AS DEPOT_DEPARTMENT
FROM AccountingAPIQueueTR Tr
INNER JOIN Transactions T ON T.CNTR = Tr.ContractNumber
INNER JOIN CustomerFile cf ON cf.CNUM = Tr.CustomerNumber
LEFT OUTER JOIN AccountingCustomer ac ON ac.id = cf.AccountingCustomerId
LEFT OUTER JOIN AccountingAPIQueueTRDetail Trd ON Trd.AccountingAPIQueueTRId = Tr.Id
--INNER JOIN AccountNumbers AcctNos on AcctNos.Store = Tr.Store
--INNER JOIN ExportFormat x ON x.ExportFormatId = AcctNos.ExportFormat
--LEFT OUTER JOIN CustomerFile cfx ON cfx.CNUM = x.GenericCashCustomerNumber
--LEFT OUTER JOIN AccountingCustomer acx ON acx.id = cfx.AccountingCustomerId

Where Tr.DatePosted Is NUll
  AND Tr.DateCancelled Is NULL
  AND tr.TransCodeId in (10,13,40,43)
  AND Tr.Direction = 1
  AND Tr.RetryCount <= 10
  AND ISNULL(T.AccountingLink,'') <> ''

RETURN
go

grant execute on spAT_GetPaymentsForExport to PORUser
go

