

/*****************************************************************************************/
-- POR.DBO.spGetTransactionItems
-- Called from Crystal Report
--
-- PARAMETERS: none
--
-- HISTORY: 09/12/2019 CM (3839) CREATED
-- 09/27/2019  DJ  (3839) REVISED
--              07/16/2020  LW  Added Standdown logic, ParentContract & LineNumber
--              10/26/2020  LW  Removed the history table unions
--              10/26/2020  LW  Added new CF.DirectPayRefNo field only in 2020DEV

/*****************************************************************************************/

CREATE PROCEDURE [dbo].[spGetTransactionItems]
    @Language   Int ,
@ContractNo   NVarChar(20) ,
@ContractFormatNumber Int
 
 AS

SET NOCOUNT ON

DECLARE @ExRate numeric(20,3)
SELECT  @Exrate =Currency.ExchRate
  FROM ( SELECT  iif(EX.CurrencyNumber = 0 or EX.CurrencyNumber is null,1, EX.ExchangeRate) as ExchRate
  FROM Transactions EX Where EX.CNTR = @ContractNo

UNION

SELECT  iif(EX.CurrencyNumber = 0 or EX.CurrencyNumber is null,1, EX.ExchangeRate) as ExchRate
  FROM TransHistory EX Where EX.CNTR = @ContractNo
  ) as Currency
 
BEGIN

SELECT TITbl.[CNTR], TITbl.[Comments],
dbo.fnPORRound(@ExRate *   TITbl.[DailyAmount])  as DailyAmount, --currency
TITbl.[DDT], TITbl.[Desc],
dbo.fnPORRound(@ExRate  *   TITbl.[DiscountAmount]) as [DiscountAmount], -- currency
cast([DiscountPercent] as numeric(20,3)) as DiscountPercent,  -- discount %
dbo.fnPORRound(@ExRate   *  TITbl.[DmgWvr]) as [DmgWvr], --currency
TITbl.[DTM], TITbl.[HRSC],
dbo.fnPORRound(@ExRate  *  TITbl.IPTransItems ) as IPTransItems,  --currency
dbo.fnPORRound(@ExRate  * TITbl.[MinimumAmount]) as [MinimumAmount],--currency
dbo.fnPORRound(@ExRate  * TITbl.[MonthlyAmount]) as [MonthlyAmount], --currency
dbo.fnPORRound(@ExRate * TITbl.PRIC)  as [PRIC], --currency
TITbl.[QTY], TITbl.[ContractLink],TITbl.[SubrentQuantity], TITbl.[RainHours], TITbl.[ReadingIn], TITbl.[ReadingOut],
dbo.fnPORRound(@ExRate  * TITbl.[RetailPrice]) as [RetailPrice] ,  --currency
TITbl.[Sort], TITbl.[SUBF], TITbl.TXTY,
dbo.fnPORRound(@ExRate  *  TITbl.[WeeklyAmount]) as [WeeklyAmount], --currency
TITbl.[CaseQty],
dbo.fnPORRound(@ExRate  * TITbl.DMGItem) as DMGItem,--currency
TITbl.[Key], TITbl.[Location], TITbl.[MANF], TITbl.[MODN], TITbl.[Msg],
iif(ItemTL.[INST] Is Null,TITbl.[INST],ItemTL.[INST]) AS [ItemInstruct],
iif(ItemTL.[Name] Is Null,TITbl.[Name],ItemTL.[Name]) AS [ItemName],
iif(ItemTL.[DescriptionLong] Is Null,TITbl.[DescriptionLong],ItemTL.[DescriptionLong]) AS [ItemNameLong],
iif(ItemTL.[Group] Is Null,TITbl.[Group],ItemTL.[Group]) AS [ItemGroup],
iif(ItemTL.[UserDefined1] Is Null,TITbl.[UserDefined1],ItemTL.[UserDefined1]) AS [UserDefined1],
iif(ItemTL.[UserDefined2] Is Null,TITbl.[UserDefined2],ItemTL.[UserDefined2]) AS [UserDefined2],
iif(CatTL.CategoryName Is Null,TITbl.CategoryName,CatTL.CategoryName) AS CategoryName,
iif(DivTL.DivisionName Is Null,TITbl.DivisionName,DivTL.DivisionName) AS DivisionName,        
iif(DeptTL.DepartmentName Is Null,TITbl.DepartmentName,DeptTL.DepartmentName) AS DepartmentName,
iif(ItemCommTL.Specs Is Null,TITbl.Specs,ItemCommTL.Specs) AS Specs,
iif(ItemCommTL.PrintOut Is Null,TITbl.PrintOut,ItemCommTL.PrintOut) AS PrintOut,
iif(ItemCommTL.ItemCommentNotes Is Null,TITbl.ItemCommentNotes,ItemCommTL.ItemCommentNotes) AS ItemCommentNotes,
iif(ItemTypeTL.TypeDescrip Is Null,TITbl.TypeDescrip,ItemTypeTL.TypeDescrip) AS TypeDescrip,
iif(ItemTypeTL.ItemType Is Null,TITbl.ItemType,ItemTypeTL.ItemType) AS ItemType,
iif(WarnTL.[Message] Is Null,TITbl.[Message],WarnTL.[Message]) AS [Message],
iif(HeaderTL.HeaderNum Is Null,TITbl.HeaderNUM,HeaderTL.HeaderNum) AS HeaderNum,
iif(HeaderTL.HeaderName Is Null,TITbl.HeaderName,HeaderTL.HeaderName) AS HeaderName,
iif(HeaderTL.HeaderUserDefined1 Is Null,TITbl.HeaderUserDefined1,HeaderTL.HeaderUserDefined1) AS HeaderUserDefined1,
iif(HeaderTL.HeaderUserDefined2 Is Null,TITbl.HeaderUserDefined2,HeaderTL.HeaderUserDefined2) AS HeaderUserDefined2,
iif(HeaderTL.HeaderDescriptionLong Is Null,TITbl.HeaderDescriptionLong,HeaderTL.HeaderDescriptionLong) AS HeaderDescriptionLong,
iif(Comm1TL.Comments1Specs Is Null,TITbl.Comments1Specs,Comm1TL.Comments1Specs) AS Comments1Specs,
iif(Comm1TL.Comments1PrintOut Is Null,TITbl.Comments1PrintOut,Comm1TL.Comments1PrintOut) AS Comments1PrintOut,
iif(Comm1TL.Comments1Notes Is Null,TITbl.Comments1Notes,Comm1TL.Comments1Notes) AS Comments1Notes,
TITbl.HeaderKey, TITbl.HeaderType, TITbl.HeaderPartNumber, TITbl.HeaderMANF, TITbl.HeaderMODN, TITbl.HeaderSerialNumber,
TITbl.HeaderRentalCase, TITbl.[Nontaxable], TITbl.DefaultSort, TITbl.[NoPrintOnContract], TITbl.[NUM], TITbl.[PartNumber],
TITbl.[HideOnWebsite], TITbl.[PER1], TITbl.[PER2], TITbl.[PER3], TITbl.[PER4], TITbl.[PER5], TITbl.[PER6], TITbl.[PER7],
TITbl.[PER8], TITbl.[PER9], TITbl.[PER10],
dbo.fnPORRound(@ExRate  * TITbl.[PriceLevelA]) as [PriceLevelA], --
dbo.fnPORRound(@ExRate  * TITbl.[PriceLevelB]) as [PriceLevelB],
dbo.fnPORRound(@ExRate  * TITbl.[PriceLevelC]) as [PriceLevelC],
dbo.fnPORRound(@ExRate  * TITbl.[Rate1]) as [Rate1] , -- currency
dbo.fnPORRound(@ExRate  * TITbl.[RATE2]) as [Rate2], -- currency
dbo.fnPORRound(@ExRate  * TITbl.[RATE3]) as [Rate3], -- currency
dbo.fnPORRound(@ExRate  * TITbl.[RATE4]) as [Rate4], -- currency
dbo.fnPORRound(@ExRate  * TITbl.[RATE5]) as [Rate5],-- currency
dbo.fnPORRound(@ExRate  * TITbl.[RATE6]) as [Rate6], -- currency
dbo.fnPORRound(@ExRate  * TITbl.[RATE7]) as [Rate7], -- currency
dbo.fnPORRound(@ExRate  * TITbl.[RATE8]) as [Rate8], -- currency
dbo.fnPORRound(@ExRate  * TITbl.[RATE9]) as [Rate9], -- currency
dbo.fnPORRound(@ExRate  * TITbl.[RATE10]) as [Rate10],-- currency
TITbl.[Header], TITbl.[RentalCase],
dbo.fnPORRound(@ExRate  *  TITbl.[ReplacementCost]) as [ReplacementCost], --currency
dbo.fnPORRound(@ExRate  *  TITbl.[SELL]) as [SELL], --currency
TITbl.[SerialNumber], TITbl.[SetupTime], TITbl.[Type], TITbl.[Weight],
cast(TITbl.[Percentage] as numeric(20,3)) as [Percentage], -- %
TITbl.ItemQty, TITbl.[QuantityOnOrder], TITbl.GroupType,
TITbl.TIEngineID, TITbl.TIBillSat, TITbl.TIBillSun, TITbl.VendorName, TITbl.LogisticsIN, TITbl.LogisticsOUT,
iif(ParmTL.STORE_NAME Is Null,ContractTbl.STORE_NAME,ParmTL.STORE_NAME) AS STORE_NAME,
iif(ParmTL.STORE_STRT Is Null,ContractTbl.STORE_STRT,ParmTL.STORE_STRT) AS STORE_STRT,
iif(ParmTL.RemitName Is Null,ContractTbl.RemitName,ParmTL.RemitName) AS RemitName,
iif(ParmTL.RemitStreet Is Null,ContractTbl.RemitStreet,ParmTL.RemitStreet) AS RemitStreet,
iif(ParmTL.ItemPercentageName Is Null,ContractTbl.ItemPercentageName,ParmTL.ItemPercentageName) AS ItemPercentageName,
iif(ParmTL.ItemDefined1 Is Null,ContractTbl.ItemDefined1,ParmTL.ItemDefined1) AS ItemDefined1,
iif(ParmTL.ItemDefined2 Is Null,ContractTbl.ItemDefined2,ParmTL.ItemDefined2) AS ItemDefined2,
iif(ParmTL.DamageWaiverName Is Null,ContractTbl.DamageWaiverName,ParmTL.DamageWaiverName) AS DamageWaiverName,
iif(TOPERTL.OperationNumber Is Null,ContractTbl.OperationNumber,TOPERTL.OperationNumber) AS OperationNumber,
iif(TOPERTL.OperationName Is Null,ContractTbl.OperationName,TOPERTL.OperationName) AS OperationName,
iif(DTruckTL.DTruckName Is Null,ContractTbl.DTruckName,DTruckTL.DTruckName) AS DTruckName,
iif(PTruckTL.PTruckName Is Null,ContractTbl.PTruckName,PTruckTL.PTruckName) AS PTruckName,
iif(CustTL.[CustomerPrintOut] Is Null,ContractTbl.[CustomerPrintOut],CustTL.[CustomerPrintOut]) AS [CustomerPrintOut],
ContractTbl.STORE_WEB, ContractTbl.DEF_RATE_CODE, ContractTbl.PRT_OPN_CHG, ContractTbl.METER_HRS_DAY, ContractTbl.AGE_FLG,
ContractTbl.RemitCityStateZip, ContractTbl.RemitPhone, ContractTbl.RemitFax, ContractTbl.ItemPercentOnDmgWvr, ContractTbl.CopiesCreditCardReceipt,
ContractTbl.PORUserNumber, ContractTbl.CollectDepositAsRentSale, ContractTbl.RoundOverTimeToNextDay, ContractTbl.StoreLanguage, ContractTbl.ClearPrintDue,
ContractTbl.IntegrateCard, ContractTbl.TotalOpenCash, ContractTbl.STORE_CITY, ContractTbl.STORE_ZIP, ContractTbl.STORE_PHONE,ContractTbl.[CKN],
ContractTbl.[CLDT], ContractTbl.[CMDT], ContractTbl.[Completed], ContractTbl.[Billed], ContractTbl.TCNTR, ContractTbl.[CONT], ContractTbl.[Contact],
ContractTbl.[ContactPhone], ContractTbl.[CUSN], ContractTbl.[DamageWaiverExempt], ContractTbl.[ItemPercentageExempt], ContractTbl.[DATE], ContractTbl.SaleDiscount,
ContractTbl.RentDiscount, ContractTbl.[DeliverToCompany], ContractTbl.[DeliveryAddress], ContractTbl.[DeliveryCity], ContractTbl.[DeliveryDate], ContractTbl.[DeliveryNotes],
ContractTbl.[DeliverySetupTime], ContractTbl.[DeliveryTrip], ContractTbl.[DeliveryZip], ContractTbl.[Delvr],
dbo.fnPORRound(@ExRate  *  ContractTbl.[DEPP]) as [DEPP], -- desired deposit currency
dbo.fnPORRound(@ExRate  *  ContractTbl.[DEPR]) as [DEPR], -- Required deposit currency
dbo.fnPORRound(@ExRate  *  ContractTbl.DMGTrans) as DMGTrans,-- currency
ContractTbl.[DPMT], -- string
ContractTbl.[EventEndDate],
dbo.fnPORRound(@ExRate  *  ContractTbl.IPTrans) as IPTrans,
ContractTbl.[JBID], ContractTbl.[JBPO], ContractTbl.[JOBN], ContractTbl.[Notes], ContractTbl.[OrderedBy],
dbo.fnPORRound(@ExRate  *  ContractTbl.[OTHR]) as [OTHR],
dbo.fnPORRound(@ExRate  *  ContractTbl.[PAID]) as [PAID],
ContractTbl.[PickedUpBy], ContractTbl.[Pickup], ContractTbl.[PickupDate], ContractTbl.[PickupTrip], ContractTbl.[PriceLevel],
ContractTbl.[PYMT], --string
dbo.fnPORRound(@ExRate  *  ContractTbl.[RENT]) as [RENT],
dbo.fnPORRound(@ExRate  *  ContractTbl.[SALE]) as [SALE],
ContractTbl.[SameAddress], ContractTbl.[STAT], ContractTbl.[STR],
dbo.fnPORRound(@ExRate  *  ContractTbl.[TAX]) as [TAX], --currency TAX ??
ContractTbl.[TIME],
dbo.fnPORRound(@ExRate  *  ContractTbl.[TOTL]) as [TOTL], --currency
ContractTbl.[OPID], ContractTbl.[Salesman], ContractTbl.[TaxCode], ContractTbl.[Modification], ContractTbl.PromptPayDisc, ContractTbl.NTaxTrans,
ContractTbl.[TransactionType],
dbo.fnPORRound(@ExRate  *  ContractTbl.[Discount])as [Discount],  --currency
ContractTbl.[PickupSameAddress], ContractTbl.[PickupAddress], ContractTbl.[PickupCity], ContractTbl.PickupZip, ContractTbl.PickupNotes,
ContractTbl.[PickupFromCompany],
dbo.fnPORRound(@ExRate  *  ContractTbl.[DesiredDeposit]) as [DesiredDeposit], --currency
ContractTbl.[PickupContact], ContractTbl.[PickupContactPhone], ContractTbl.CustName, ContractTbl.[Address],  ContractTbl.[CITY],
ContractTbl.[ZIP], ContractTbl.[ZIP4], ContractTbl.[Address2], ContractTbl.[Terms],
ContractTbl.[Phone], ContractTbl.[WORK], ContractTbl.[MOBILE], ContractTbl.[FAX],
ContractTbl.[BillContact], ContractTbl.[BillCityState], ContractTbl.[BillZip], ContractTbl.[BillZip4],
ContractTbl.[BillAddress2], ContractTbl.[BillAddress1], ContractTbl.[Status], ContractTbl.CustKEY,
ContractTbl.[CNUM], ContractTbl.[Language], ContractTbl.StoreCount,
ContractTbl.CntrSalesName, ContractTbl.CntrSalesEmail, ContractTbl.CntrSalesCell, ContractTbl.CustSalesName,
ContractTbl.CustSalesEmail, ContractTbl.CustSalesCell, ContractTbl.JobSalesName,
ContractTbl.JobSalesCell, ContractTbl.CountryCode, ContractTbl.StoreFax, ContractTbl.PFABillSun,
ContractTbl.PFABillSat, ContractTbl.TEngineID, ContractTbl.TBillSun, ContractTbl.TBillSat,
ContractTbl.BusinessNumber, ContractTbl.OPNO, ContractTbl.OPNM,ContractTbl.OPNOAssgn, ContractTbl.OPNMAssgn, ContractTbl.TaxDescription,
ContractTbl.TaxRent1, --number
ContractTbl.TaxSale1, --number
ContractTbl.TaxDW1,--number
ContractTbl.DisplayBreakoutOnContract,
ContractTbl.TaxItemPercentage1, ContractTbl.Brand_Location, ContractTbl.Brand_Name,
ContractTbl.Brand_Street, ContractTbl.Brand_City, ContractTbl.Brand_Zip, ContractTbl.Brand_Phone,
ContractTbl.Brand_Fax, ContractTbl.Brand_Web, ContractTbl.Brand_RemitName, ContractTbl.Brand_RemitStreet,
ContractTbl.Brand_RemitCityStateZip, ContractTbl.Brand_RemitPhone, ContractTbl.Brand_RemitFax,
ContractTbl.TranslatedLegalEase, ContractTbl.BaseLegalEase, ContractTbl.TranslatedCreditCard,
ContractTbl.BaseCreditCard, ContractTbl.TranslatedMarketingPage,
ContractTbl.BaseMarketingPage, ContractTbl.FormatNumber, ContractTbl.FHeader, ContractTbl.FDetail,
ContractTbl.FShadeColor, ContractTbl.FBarcode, ContractTbl.FBillTo, ContractTbl.FFaxCover,
ContractTbl.FRemitTo, ContractTbl.CaliforniaSig, ContractTbl.WithoutAmounts, ContractTbl.ShowNoTime,
ContractTbl.DetailColumn1, ContractTbl.DetailColumn2, ContractTbl.DetailColumn3, ContractTbl.DetailColumn4,
ContractTbl.DetailColumn5, ContractTbl.DetailColumn6, ContractTbl.DetailColumn7, ContractTbl.DetailColumnS1,
ContractTbl.DetailColumnS2, ContractTbl.DetailColumnS3, ContractTbl.DetailColumnS4,
ContractTbl.DetailColumnS5, ContractTbl.DetailColumnS6, ContractTbl.DetailColumnS7, ContractTbl.PrintSpecs,
ContractTbl.ItemPrintOut, ContractTbl.PaymentDetail, ContractTbl.PrintOperName, ContractTbl.ContDueDate,
ContractTbl.ShowMods, ContractTbl.ShowSig, ContractTbl.PrintItemRate, ContractTbl.PrintDiscDetail,
ContractTbl.PrintContComments, ContractTbl.ShowContractFooter, ContractTbl.DeliveryComments,
ContractTbl.ShowAllItems, ContractTbl.DeliveryAtTop, ContractTbl.FormatSetUp,
ContractTbl.PrintTotalsSection, ContractTbl.ShowRetailPricing, ContractTbl.PrintLegalEase,
ContractTbl.PrintItemPicture, ContractTbl.PrintDeliveryTruck, ContractTbl.PrintCCAuthorization,
ContractTbl.PrintMarketingPage, ContractTbl.Footer, ContractTbl.GroupBy, ContractTbl.SubGroup,
ContractTbl.WebLinksHeader, ContractTbl.WebLinksItems,
ContractTbl.DiscountedRates, --boolean
ContractTbl.PrintAfterContract, ContractTbl.WebLinksPay, ContractTbl.PaymentDetailSummary, ContractTbl.HideLogisticsIN, ContractTbl.HideLogisticsOUT, @ExRate as XRateVar,
@Language as LanguageCont, ContractTbl.Versionformat, TITBl.OutDate, 2 as versionnum,
cast(TiTbl.PRIC as numeric(20,3)) AS Pricbef,
(@ExRate * cast(TITbl.[PRIC] as numeric(20,3)) ) as [PRICTest],
'zzz' as testfield, ContractTbl.[PAID] as PAIDNet, ContractTbl.ParentContract, TITbl.LineNumber, ContractTbl.DirectPayRefNo
 FROM (
SELECT TI.[CNTR], TI.OutDate, TI.[Comments], TI.[DailyAmount], TI.[DDT], TI.[Desc], iif(ITF.[Department]=0 or ITF.[Department] Is Null,CAT.[DefaultDepartment],ITF.[Department]) AS Department,
CAT.Name as CategoryName, CAT.DefaultSort , TI.[DiscountAmount], TI.[DiscountPercent], TI.[DmgWvr], TI.[DTM], TI.[HRSC], TI.[ItemPercentage] as IPTransItems, TI.[MinimumAmount],
TI.[MonthlyAmount], TI.[PRIC], TI.[QTY], TI.[ContractLink], TI.[SubrentQuantity], TI.[RainHours], TI.[ReadingIn], TI.[ReadingOut], TI.[RetailPrice], TI.[Sort], TI.[SUBF],
iif(ITF.[TYPE]='N','SS',TI.[TXTY]) AS TXTY, TI.[WeeklyAmount], TI.[ITEM], ITF.[CaseQty], ITF.[DescriptionLong], ITF.[DMG] as DMGITEM, ITF.[Group], ITF.[INST], ITF.[Key], ITF.[Location],
ITF.[MANF], ITF.[MODN], ITF.[Msg], ITF.[Name], TI.[Nontaxable], ITF.[NoPrintOnContract], ITF.[NUM], ITF.[PartNumber], ITF.[HideOnWebsite], ITF.[PER1], ITF.[PER2], ITF.[PER3], ITF.[PER4],
ITF.[PER5], ITF.[PER6], ITF.[PER7], ITF.[PER8], ITF.[PER9], ITF.[PER10], ITF.[PriceLevelA], ITF.[PriceLevelB], ITF.[PriceLevelC], ITF.[Rate1], ITF.[RATE2], ITF.[RATE3], ITF.[RATE4],
ITF.[RATE5], ITF.[RATE6], ITF.[RATE7], ITF.[RATE8], ITF.[RATE9], ITF.[RATE10], ITF.[Header], ITF.[RentalCase], ITF.[ReplacementCost], ITF.[SELL], ITF.[SerialNumber], ITF.[SetupTime],
ITF.[Type], ITF.[UserDefined1], ITF.[UserDefined2], ITF.[Weight], ITF.[VendorNumber1], ITF.[ItemPercentage] as Percentage, ITF.[Category] AS Category, ITF.[Qty] as ItemQty,
ITF.[QuantityOnOrder], 'Confirmed' AS GroupType, RETransItem.RateEngineID AS TIEngineID, RETransItem.BillForSaturday AS TIBillSat, RETransItem.BillForSunday AS TIBillSun,
WarningMessage.[Message], Dept.DepartmentName, ItemComments.Specs, ItemComments.PrintOut, ItemComments.[Notes] AS ItemCommentNotes, ItemType.TypeDescrip, ItemType.[Type] as ItemType,
VendorFile.VendorName, Div.DivisionName, Div.DivisionNumber, ItemHeader.[KEY] AS HeaderKey, ItemHeader.[Name] as HeaderName, ItemHeader.[Type] as HeaderType,
ItemHeader.PartNumber AS HeaderPartNumber,  ItemHeader.[NUM] as HeaderNUM, ItemHeader.MANF as HeaderMANF, ItemHeader.MODN as HeaderMODN, ItemHeader.UserDefined1 AS HeaderUserDefined1,
ItemHeader.UserDefined2 AS HeaderUserDefined2, ItemHeader.SerialNumber as HeaderSerialNumber, ItemHeader.DescriptionLong AS HeaderDescriptionLong, ItemHeader.RentalCase AS HeaderRentalCase,
ItemComments_1.Specs AS Comments1Specs, ItemComments_1.PrintOut AS Comments1PrintOut, ItemComments_1.[Notes] as Comments1Notes, TI.LogisticsIN, TI.LogisticsOUT,
TI.LineNumber
 FROM  TransactionItems TI
INNER JOIN ItemFile ITF ON TI.[ITEM] = ITF.[NUM]
 LEFT JOIN RateEngine RETransItem ON TI.RateEngineID = RETransItem.RateEngineID
 LEFT JOIN WarningMessage ON ITF.[Msg] = WarningMessage.Number
 LEFT JOIN ItemDepartment Dept ON ITF.Department = Dept.Department
 LEFT JOIN ItemComments ON ITF.[NUM] = ItemComments.NUM
 LEFT JOIN ItemType ON ITF.[Type] = ItemType.[Type]
 LEFT JOIN VendorFile ON ITF.VendorNumber1 = VendorFile.VendorNumber
INNER JOIN ItemCategory CAT ON ITF.Category = CAT.Category
 LEFT JOIN ItemDivision Div ON CAT.DivisionNumber = Div.DivisionNumber
 LEFT JOIN ItemFile ItemHeader ON ITF.Header = ItemHeader.[Key]
 LEFT JOIN ItemComments ItemComments_1 ON ItemHeader.NUM = ItemComments_1.NUM
WHERE TI.[CNTR] in (@ContractNo)
  AND (TI.[QTY] <> 0 or (TI.[PRIC]-TI.[DiscountAmount]) <> 0)



UNION

SELECT TI.[CNTR],TIOP.OutDate, TIOP.[Comments], TIOP.[DailyAmount], TI.[DDT], TIOP.[Desc], iif(ITF.[Department]=0 or ITF.[Department] Is Null,CAT.[DefaultDepartment],
ITF.[Department]) AS Department, CAT.Name as CategoryName, CAT.DefaultSort   , TIOP.[DiscountAmount], TIOP.[DiscountPercent], TIOP.[DmgWvr], TIOP.[DTM], TIOP.[HRSC],
TIOP.[ItemPercentage] as IPTransItems, TIOP.[MinimumAmount], TIOP.[MonthlyAmount], TIOP.[PRIC], TIOP.[QTY], TIOP.[ContractLink], TIOP.[SubrentQuantity], TIOP.[RainHours],
TIOP.[ReadingIn], TIOP.[ReadingOut], TIOP.[RetailPrice], TIOP.[Sort], TIOP.[SUBF], iif(ITF.[TYPE]='N','SS',TIOP.[TXTY]) AS TXTY, TIOP.[WeeklyAmount], TIOP.[ITEM], ITF.[CaseQty],
ITF.[DescriptionLong], ITF.[DMG] as DMGITEM, ITF.[Group], ITF.[INST], ITF.[Key], ITF.[Location], ITF.[MANF], ITF.[MODN], ITF.[Msg], ITF.[Name], TIOP.[Nontaxable], ITF.[NoPrintOnContract],
ITF.[NUM], ITF.[PartNumber], ITF.[HideOnWebsite], ITF.[PER1], ITF.[PER2], ITF.[PER3], ITF.[PER4], ITF.[PER5], ITF.[PER6], ITF.[PER7], ITF.[PER8], ITF.[PER9], ITF.[PER10], ITF.[PriceLevelA],
ITF.[PriceLevelB], ITF.[PriceLevelC], ITF.[Rate1], ITF.[RATE2], ITF.[RATE3], ITF.[RATE4], ITF.[RATE5], ITF.[RATE6], ITF.[RATE7], ITF.[RATE8], ITF.[RATE9], ITF.[RATE10], ITF.[Header],
ITF.[RentalCase], ITF.[ReplacementCost], ITF.[SELL], ITF.[SerialNumber], ITF.[SetupTime], ITF.[Type], ITF.[UserDefined1], ITF.[UserDefined2], ITF.[Weight], ITF.[VendorNumber1],
ITF.[ItemPercentage] AS Percentage, ITF.[Category] AS Category, ITF.[Qty] AS ItemQty, ITF.[QuantityOnOrder], 'Optional' AS GroupType, RETransItem.RateEngineID AS TIEngineID,
RETransItem.BillForSaturday AS TIBillSat, RETransItem.BillForSunday AS TIBillSun, WarningMessage.[Message], Dept.DepartmentName, ItemComments.Specs, ItemComments.PrintOut,
ItemComments.[Notes] AS ItemCommentNotes, ItemType.TypeDescrip, ItemType.Type as ItemType, VendorFile.VendorName, Div.DivisionName, Div.DivisionNumber,  ItemHeader.[KEY] AS HeaderKey,
ItemHeader.[Name] as HeaderName, ItemHeader.[Type] as HeaderType, ItemHeader.PartNumber AS HeaderPartNumber, ItemHeader.[NUM] as HeaderNUM, ItemHeader.MANF as HeaderMANF,
ItemHeader.MODN as HeaderMODN, ItemHeader.UserDefined1 AS HeaderUserDefined1, ItemHeader.UserDefined2 AS HeaderUserDefined2, ItemHeader.SerialNumber as HeaderSerialNumber,
ItemHeader.DescriptionLong AS HeaderDescriptionLong, ItemHeader.RentalCase AS HeaderRentalCase, ItemComments_1.Specs AS Comments1Specs, ItemComments_1.PrintOut AS Comments1PrintOut,
ItemComments_1.[Notes] as Comments1Notes, TI.LogisticsIN, TI.LogisticsOUT,TI.LineNumber
 FROM  TransactionItems TI
 LEFT JOIN TransactionItems TIOP ON TI.[ContractLink] = TIOP.[CNTR]
 LEFT JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
 LEFT JOIN ItemFile ITF ON TIOP.[ITEM] = ITF.[NUM]
 LEFT JOIN RateEngine RETransItem ON TI.RateEngineID = RETransItem.RateEngineID
 LEFT JOIN WarningMessage ON ITF.[Msg] = WarningMessage.Number
 LEFT JOIN ItemDepartment Dept ON ITF.Department = Dept.Department
 LEFT JOIN ItemComments ON ITF.[NUM] = ItemComments.[NUM]
 LEFT JOIN ItemType ON ITF.[Type] = ItemType.[Type]
 LEFT JOIN VendorFile ON ITF.VendorNumber1 = VendorFile.VendorNumber
 LEFT JOIN ItemCategory CAT ON ITF.Category = CAT.Category
 LEFT JOIN ItemDivision Div ON CAT.DivisionNumber = Div.DivisionNumber
 LEFT JOIN ItemFile ItemHeader ON ITF.Header = ItemHeader.[Key]
 LEFT JOIN ItemComments ItemComments_1 ON ItemHeader.NUM = ItemComments_1.NUM
WHERE TI.[CNTR] IN (@ContractNo)
  AND (TI.[QTY] <> 0 or (TI.[PRIC]-TI.[DiscountAmount]) <> 0)
  AND LTrim(TI.[ContractLink] + ' ') <> ''
  AND Left(TI.[ContractLink]  + ' ',1) Not In ('s','r','t')
  AND TIOP.[CNTR] Is Not Null
  AND Left(T.[STAT],1) IN ('R'          ,'Q')
  AND Left(T.[CNTR] + ' ',1) Not In ('s','r','t','l')


  ) AS TITbl

RIGHT JOIN (
       SELECT T.[CNTR] as TCNTR, T.[CKN], T.[CLDT], T.[CMDT], T.[Completed], T.[Billed], T.[CONT], T.[Contact], T.[ContactPhone], T.[CUSN], T.[DamageWaiverExempt], T.[ItemPercentageExempt],
T.[DATE], T.SaleDiscount, T.RentDiscount, T.[DeliverToCompany], T.[DeliveryAddress], T.[DeliveryCity], T.[DeliveryDate], T.[DeliveryNotes],
T.[DeliverySetupTime], T.[DeliveryTrip], T.[DeliveryZip], T.[Delvr], T.[DEPP], T.[DEPR], T.[DMG] as DMGTrans,
T.[DPMT], T.[EventEndDate], T.[ItemPercentage] as IPTrans, T.[JBID], T.[JBPO], T.[JOBN], T.[Notes], T.[OrderedBy],
T.[OTHR], T.[PAID], T.[PickedUpBy], T.[Pickup], T.[PickupDate], T.[PickupTrip], T.[PriceLevel], T.[PYMT],
T.[RENT], T.[SALE], T.[SameAddress], T.[STAT], T.[STR], T.[TAX], T.[TIME], T.[TOTL], T.[DeliveryTruckNumber],
 T.[Operation], T.[OPID], T.[PickupTruckNumber], T.[Salesman], T.[TaxCode], T.[Modification],
 T.[Discount] AS PromptPayDisc, T.[NonTaxable] as NTaxTrans, T.[TransactionType], T.[Discount],
  T.[PickupSameAddress], T.[PickupAddress], T.[PickupCity], T.PickupZip, T.[PickupVerifiedAddress],
   T.[PickupFromCompany], T.[DesiredDeposit], T.[PickupContact], T.[PickupContactPhone], CF.[NAME] AS CustName,
CF.[Address], CF.[CITY], CF.[ZIP], CF.[ZIP4], CF.[Address2], CF.[Terms], CF.[Phone], CF.[WORK],
CF.[MOBILE], CF.[FAX], CF.[BillContact], CF.[BillCityState], CF.[BillZip], CF.[BillZip4],
CF.[BillAddress2], CF.[BillAddress1], CF.[Status], CF.[KEY] as CustKey, CF.[CNUM], CF.[CustomerPrintOut],
CF.[Language], (SELECT Max(UserProfile.[NumberStores]) AS StrCount FROM UserProfile) AS StoreCount,
Cntr_Sales.[Name] AS CntrSalesName, Cntr_Sales.[Email] AS CntrSalesEmail, Cntr_Sales.CellPhone AS CntrSalesCell,
Cust_Sales.[Name] AS CustSalesName, Cust_Sales.[Email] AS CustSalesEmail, Cust_Sales.CellPhone AS CustSalesCell,
JobS_Sales.[Name] AS JobSalesName, JobS_Sales.[Email] AS JobSalesEmail, JobS_Sales.CellPhone AS JobSalesCell,
PFA.CountryCode, PFA.StoreFax, PFA.RateEngineID AS PFAEngineID, REParam.BillForSunday AS PFABillSun,
 REParam.BillForSaturday AS PFABillSat, RETrans.RateEngineID AS TEngineID, RETrans.BillForSunday AS TBillSun,
  RETrans.BillForSaturday AS TBillSat, PFA.BusinessNumber, PF.STORE_NAME, PF.STORE_STRT, PF.STORE_CITY,
  PF.STORE_ZIP, PF.STORE_PHONE, PF.STORE_WEB, PF.DEF_RATE_CODE, PF.PRT_OPN_CHG, PF.METER_HRS_DAY, PF.AGE_FLG,
   PF.RemitName, PF.RemitStreet, PF.RemitCityStateZip, PF.RemitPhone, PF.RemitFax, PF.ItemPercentageName,
PF.ItemDefined1, PF.ItemDefined2, PF.ItemPercentOnDmgWvr, PF.CopiesCreditCardReceipt, PF.PORUserNumber,
PF.DamageWaiverName, PF.CollectDepositAsRentSale, PF.RoundOverTimeToNextDay, PF.StoreLanguage,
PF.ClearPrintDue, PF.IntegrateCard, PF.TotalOpenCash, DTrucks.TruckName AS DTruckName,
PTrucks.TruckName AS PTruckName, OperatorID.OPNO, OperatorID.OPNM, OPAS.OPNO AS OPNOAssgn,
OPAS.OPNM AS OPNMAssgn, TOPER.OperationNumber, TOPER.Operationname, TaxTable.TaxDescription,
TaxTable.TaxRent1, TaxTable.TaxSale1, TaxTable.TaxDW1, TaxTable.DisplayBreakoutOnContract,
TaxTable.TaxItemPercentage1, PFB.Brand_Location, PFB.Brand_Name, PFB.Brand_Street, PFB.Brand_City,
PFB.Brand_Zip, PFB.Brand_Phone, PFB.Brand_Fax, PFB.Brand_Web, PFB.Brand_RemitName, PFB.Brand_RemitStreet,
PFB.Brand_RemitCityStateZip, PFB.Brand_RemitPhone, PFB.Brand_RemitFax, ContractTrans.Store,
ContractTrans.TranslatedLegalEase, ContractTrans.BaseLegalEase, ContractTrans.TranslatedCreditCard,
ContractTrans.BaseCreditCard, ContractTrans.TranslatedMarketingPage, ContractTrans.BaseMarketingPage,
CFormat.FormatNumber, CFormat.FHeader, CFormat.FDetail, CFormat.FShadeColor, CFormat.FBarcode,
CFormat.FBillTo, CFormat.FFaxCover, CFormat.FRemitTo, CFormat.CaliforniaSig, CFormat.WithoutAmounts,
CFormat.ShowNoTime, CFormat.DetailColumn1, CFormat.DetailColumn2, CFormat.DetailColumn3,
CFormat.DetailColumn4, CFormat.DetailColumn5, CFormat.DetailColumn6, CFormat.DetailColumn7,
CFormat.DetailColumnS1, CFormat.DetailColumnS2, CFormat.DetailColumnS3, CFormat.DetailColumnS4,
CFormat.DetailColumnS5, CFormat.DetailColumnS6, CFormat.DetailColumnS7, CFormat.PrintSpecs,
CFormat.ItemPrintOut, CFormat.PaymentDetail, CFormat.PrintOperName, CFormat.ContDueDate, CFormat.ShowMods,
 CFormat.ShowSig, CFormat.PrintItemRate, CFormat.PrintDiscDetail, CFormat.PrintContComments,
  CFormat.ShowContractFooter, CFormat.DeliveryComments, CFormat.ShowAllItems, CFormat.DeliveryAtTop,
   CFormat.SetupTime as FormatSetUp, CFormat.PrintTotalsSection, CFormat.ShowRetailPricing,
CFormat.PrintLegalEase, CFormat.PrintItemPicture, CFormat.PrintDeliveryTruck,
CFormat.PrintCCAuthorization, CFormat.PrintMarketingPage, CFormat.Footer, CFormat.Groupby,
CFormat.SubGroup, CFormat.WebLinksHeader, CFormat.WebLinksItems, CFormat.DiscountedRates,
CFormat.PrintAfterContract, CFormat.WebLinksPay, CFormat.PaymentDetailSummary,
CFormat.HideLogisticsIN, CFormat.HideLogisticsOUT, T.PickupNotes, Cformat.VersionFormat,
iif(T.ParentContract is null or T.ParentContract = '',T.[CNTR],T.ParentContract) as ParentContract,
CF.DirectPayRefNo
 FROM Transactions AS T
INNER JOIN CustomerFile AS CF ON T.[CUSN] = CF.[CNUM]
  INNER JOIN ParameterFileAdditional PFA ON T.STR = PFA.Store
INNER JOIN RateEngine REParam ON PFA.RateEngineID = REParam.RateEngineID
 LEFT JOIN CustomerJobSite AS Jobsite ON T.JobSite = Jobsite.Number
 LEFT JOIN Salesman AS Cntr_Sales ON T.Salesman = Cntr_Sales.Number
 LEFT JOIN Salesman AS Cust_Sales ON CF.Salesman = Cust_Sales.Number
 LEFT JOIN Salesman AS JobS_Sales ON Jobsite.Salesman = JobS_Sales.Number
 LEFT JOIN RateEngine RETrans ON T.RateEngineID = RETrans.RateEngineID
 LEFT JOIN ParameterFile PF ON T.STR = PF.Store
 LEFT JOIN DeliveryTrucks DTrucks ON T.DeliveryTruckNumber = DTrucks.TruckNumber
 LEFT JOIN OperatorID ON T.OPID = OperatorID.OPNO LEFT JOIN OperatorID OPAS ON T.OperatorAssigned = OPAS.OPNO
 LEFT JOIN TransactionOperation TOPER ON T.Operation = TOPER.OperationNumber
 LEFT JOIN TaxTable ON T.Taxcode = TaxTable.Taxcode
 LEFT JOIN DeliveryTrucks PTrucks ON T.PickupTruckNumber = PTrucks.TruckNumber
 LEFT JOIN ParameterFileBrand PFB ON T.TransactionType = PFB.Brand_Location
 LEFT JOIN (
SELECT [Contract].Store, TR.LegalEase AS TranslatedLegalEase,
[Contract].LegalEase AS BaseLegalEase,
TR.CreditCardAuthorization AS TranslatedCreditCard ,[Contract].
CreditCardAuthorization AS BaseCreditCard, TR.MarketingPage AS TranslatedMarketingPage,
[Contract].MarketingPage AS BaseMarketingPage
  FROM [Contract]
 LEFT JOIN (
SELECT Contract_Tr.Store, Contract_Tr.LegalEase,
Contract_Tr.CreditCardAuthorization , Contract_Tr.MarketingPage
  FROM Contract_Tr
  LEFT JOIN TranslationNames ON Contract_Tr.Languagecode = TranslationNames.LanguageCode
                                  WHERE TranslationNames.Translations IS NULL
OR TranslationNames.Translations = @Language
) AS TR ON [Contract].Store = TR.Store
) AS ContractTrans ON T.[STR] = ContractTrans.Store
 LEFT JOIN (
SELECT ContractFormatTbl.*
  FROM (SELECT MainTbl.*
  FROM (
SELECT TOP 1 Main.[Type], Main.FormatNumber, Main.FHeader, Main.FDetail, Main.FShadeColor, Main.FBarcode, Main.FBillTo, Main.FFaxCover,
 Main.FRemitTo, Main.CaliforniaSig, Main.WithoutAmounts, Main.ShowNoTime, Main.DetailColumn1, Main.DetailColumn2, Main.DetailColumn3,
 Main.DetailColumn4, Main.DetailColumn5, Main.DetailColumn6, Main.DetailColumn7, Main.DetailColumnS1, Main.DetailColumnS2, Main.DetailColumnS3,
 Main.DetailColumnS4, Main.DetailColumnS5, Main.DetailColumnS6, Main.DetailColumnS7, Main.PrintSpecs, Main.ItemPrintOut, Main.PaymentDetail,
 Main.PrintOperName, Main.ContDueDate, Main.ShowMods, Main.ShowSig, Main.PrintItemRate, Main.PrintDiscDetail, Main.PrintContComments,
 Main.ShowContractFooter, Main.DeliveryComments, Main.ShowAllItems, Main.DeliveryAtTop, Main.SetupTime, Main.PrintTotalsSection,
 Main.ShowRetailPricing, Main.PrintLegalEase, Main.PrintItemPicture, Main.PrintDeliveryTruck, Main.PrintCCAuthorization, Main.PrintMarketingPage,
 Main.Footer, Main.Groupby, Main.SubGroup, Main.WebLinksHeader, Main.WebLinksItems, Main.DiscountedRates, Main.PrintAfterContract, Main.WebLinksPay,
 Main.PaymentDetailSummary, Main.HideLogisticsIN, Main.HideLogisticsOUT, main.VersionFormat
  FROM (
SELECT 'C' AS [Type], ContractFormat.Number AS FormatNumber, ContractFormat.Header as FHeader, ContractFormat.Detail AS FDetail,
ContractFormat.ShadeColor as FShadeColor, ContractFormat.Barcode AS FBarcode, ContractFormat.BillTo as FBillTo,
ContractFormat.FaxCover AS FFaxCover, ContractFormat.RemitTo AS FRemitTo, ContractFormat.CaliforniaSig, ContractFormat.WithoutAmounts,
ContractFormat.ShowNoTime, ContractFormat.DetailColumn1, ContractFormat.DetailColumn2, ContractFormat.DetailColumn3, ContractFormat.DetailColumn4,
ContractFormat.DetailColumn5, ContractFormat.DetailColumn6, ContractFormat.DetailColumn7, ContractFormat.DetailColumnS1,
ContractFormat.DetailColumnS2, ContractFormat.DetailColumnS3, ContractFormat.DetailColumnS4, ContractFormat.DetailColumnS5,
ContractFormat.DetailColumnS6, ContractFormat.DetailColumnS7, ContractFormat.PrintSpecs, ContractFormat.ItemPrintOut, ContractFormat.PaymentDetail,
ContractFormat.PrintOperName, ContractFormat.ContDueDate, ContractFormat.ShowMods, ContractFormat.ShowSig, ContractFormat.PrintItemRate,
ContractFormat.PrintDiscDetail, ContractFormat.PrintContComments, ContractFormat.ShowContractFooter, ContractFormat.DeliveryComments,
ContractFormat.ShowAllItems, ContractFormat.DeliveryAtTop, ContractFormat.SetupTime, ContractFormat.PrintTotalsSection,
ContractFormat.ShowRetailPricing, ContractFormat.PrintLegalEase, ContractFormat.PrintItemPicture, ContractFormat.PrintDeliveryTruck,
ContractFormat.PrintCCAuthorization, ContractFormat.PrintMarketingPage, ContractFormat.Footer, ContractFormat.Groupby, ContractFormat.SubGroup,
ContractFormat.WebLinksHeader, ContractFormat.WebLinksItems, ContractFormat.DiscountedRates, ContractFormat.PrintAfterContract,
ContractFormat.WebLinksPay, ContractFormat.PaymentDetailSummary, ContractFormat.HideLogisticsIN, ContractFormat.HideLogisticsOUT,
ContractFormat.Versionformat
  FROM ContractFormat
 WHERE ContractFormat.[Number] = @ContractFormatNumber

UNION

(SELECT TOP 1 'C' AS [Type], ContractFormat.Number AS FormatNumber, ContractFormat.Header as FHeader, ContractFormat.Detail AS FDetail,
 ContractFormat.ShadeColor as FShadeColor, ContractFormat.Barcode AS FBarcode, ContractFormat.BillTo as FBillTo,
 ContractFormat.FaxCover AS FFaxCover, ContractFormat.RemitTo AS FRemitTo, ContractFormat.CaliforniaSig, ContractFormat.WithoutAmounts,
 ContractFormat.ShowNoTime, ContractFormat.DetailColumn1, ContractFormat.DetailColumn2, ContractFormat.DetailColumn3,
 ContractFormat.DetailColumn4, ContractFormat.DetailColumn5, ContractFormat.DetailColumn6, ContractFormat.DetailColumn7,
 ContractFormat.DetailColumnS1, ContractFormat.DetailColumnS2, ContractFormat.DetailColumnS3, ContractFormat.DetailColumnS4,
 ContractFormat.DetailColumnS5, ContractFormat.DetailColumnS6, ContractFormat.DetailColumnS7, ContractFormat.PrintSpecs,
 ContractFormat.ItemPrintOut, ContractFormat.PaymentDetail, ContractFormat.PrintOperName, ContractFormat.ContDueDate,
 ContractFormat.ShowMods, ContractFormat.ShowSig, ContractFormat.PrintItemRate, ContractFormat.PrintDiscDetail,
 ContractFormat.PrintContComments, ContractFormat.ShowContractFooter, ContractFormat.DeliveryComments, ContractFormat.ShowAllItems,
 ContractFormat.DeliveryAtTop, ContractFormat.SetupTime, ContractFormat.PrintTotalsSection, ContractFormat.ShowRetailPricing,
 ContractFormat.PrintLegalEase, ContractFormat.PrintItemPicture, ContractFormat.PrintDeliveryTruck, ContractFormat.PrintCCAuthorization,
 ContractFormat.PrintMarketingPage, ContractFormat.Footer, ContractFormat.Groupby, ContractFormat.SubGroup, ContractFormat.WebLinksHeader,
 ContractFormat.WebLinksItems, ContractFormat.DiscountedRates, ContractFormat.PrintAfterContract, ContractFormat.WebLinksPay,
 ContractFormat.PaymentDetailSummary, ContractFormat.HideLogisticsIN, ContractFormat.HideLogisticsOUT, ContractFormat.Versionformat
FROM ContractFormat
  ORDER BY ContractFormat.[Number] ASC
)
) AS Main ORDER BY Main.[FormatNumber] DESC
       ) AS MainTbl

 UNION

SELECT MainTbl.*
  FROM (
SELECT TOP 1 Main.[Type], Main.FormatNumber, Main.FHeader, Main.FDetail, Main.FShadeColor, Main.FBarcode, Main.FBillTo, Main.FFaxCover, Main.FRemitTo,
 Main.CaliforniaSig, Main.WithoutAmounts, Main.ShowNoTime, Main.DetailColumn1, Main.DetailColumn2, Main.DetailColumn3, Main.DetailColumn4,
 Main.DetailColumn5, Main.DetailColumn6, Main.DetailColumn7, Main.DetailColumnS1, Main.DetailColumnS2, Main.DetailColumnS3, Main.DetailColumnS4,
 Main.DetailColumnS5, Main.DetailColumnS6, Main.DetailColumnS7, Main.PrintSpecs, Main.ItemPrintOut, Main.PaymentDetail, Main.PrintOperName,
 Main.ContDueDate, Main.ShowMods, Main.ShowSig, Main.PrintItemRate, Main.PrintDiscDetail, Main.PrintContComments, Main.ShowContractFooter,
 Main.DeliveryComments, Main.ShowAllItems, Main.DeliveryAtTop, Main.SetupTime, Main.PrintTotalsSection, Main.ShowRetailPricing, Main.PrintLegalEase,
 Main.PrintItemPicture, Main.PrintDeliveryTruck, Main.PrintCCAuthorization, Main.PrintMarketingPage, Main.Footer, Main.Groupby, Main.SubGroup,
 Main.WebLinksHeader, Main.WebLinksItems, Main.DiscountedRates, Main.PrintAfterContract, Main.WebLinksPay, Main.PaymentDetailSummary,
 Main.HideLogisticsIN, Main.HideLogisticsOUT, Main.VersionFormat
  FROM (
SELECT 'W' AS [Type], ContractFormat.Number AS FormatNumber, ContractFormat.Header as FHeader, ContractFormat.Detail AS FDetail,
ContractFormat.ShadeColor as FShadeColor, ContractFormat.Barcode AS FBarcode, ContractFormat.BillTo as FBillTo,
ContractFormat.FaxCover AS FFaxCover, ContractFormat.RemitTo AS FRemitTo, ContractFormat.CaliforniaSig, ContractFormat.WithoutAmounts,
ContractFormat.ShowNoTime, ContractFormat.DetailColumn1, ContractFormat.DetailColumn2, ContractFormat.DetailColumn3, ContractFormat.DetailColumn4,
ContractFormat.DetailColumn5, ContractFormat.DetailColumn6, ContractFormat.DetailColumn7, ContractFormat.DetailColumnS1,
ContractFormat.DetailColumnS2, ContractFormat.DetailColumnS3, ContractFormat.DetailColumnS4, ContractFormat.DetailColumnS5,
ContractFormat.DetailColumnS6, ContractFormat.DetailColumnS7, ContractFormat.PrintSpecs, ContractFormat.ItemPrintOut, ContractFormat.PaymentDetail,
ContractFormat.PrintOperName, ContractFormat.ContDueDate, ContractFormat.ShowMods, ContractFormat.ShowSig, ContractFormat.PrintItemRate,
ContractFormat.PrintDiscDetail, ContractFormat.PrintContComments, ContractFormat.ShowContractFooter, ContractFormat.DeliveryComments,
ContractFormat.ShowAllItems, ContractFormat.DeliveryAtTop, ContractFormat.SetupTime, ContractFormat.PrintTotalsSection,
ContractFormat.ShowRetailPricing, ContractFormat.PrintLegalEase, ContractFormat.PrintItemPicture, ContractFormat.PrintDeliveryTruck,
ContractFormat.PrintCCAuthorization, ContractFormat.PrintMarketingPage, ContractFormat.Footer, ContractFormat.Groupby, ContractFormat.SubGroup,
ContractFormat.WebLinksHeader, ContractFormat.WebLinksItems, ContractFormat.DiscountedRates, ContractFormat.PrintAfterContract,
ContractFormat.WebLinksPay, ContractFormat.PaymentDetailSummary, ContractFormat.HideLogisticsIN, ContractFormat.HideLogisticsOUT,
ContractFormat.VersionFormat
  FROM WorkOrderFormat AS ContractFormat
 WHERE ContractFormat.[Number] = @ContractFormatNumber

UNION

   (SELECT TOP 1 'W' AS [Type], ContractFormat.Number AS FormatNumber, ContractFormat.Header as FHeader, ContractFormat.Detail AS FDetail,
 ContractFormat.ShadeColor as FShadeColor, ContractFormat.Barcode AS FBarcode, ContractFormat.BillTo as FBillTo,
 ContractFormat.FaxCover AS FFaxCover, ContractFormat.RemitTo AS FRemitTo, ContractFormat.CaliforniaSig, ContractFormat.WithoutAmounts,
 ContractFormat.ShowNoTime, ContractFormat.DetailColumn1, ContractFormat.DetailColumn2, ContractFormat.DetailColumn3,
 ContractFormat.DetailColumn4, ContractFormat.DetailColumn5, ContractFormat.DetailColumn6, ContractFormat.DetailColumn7,
 ContractFormat.DetailColumnS1, ContractFormat.DetailColumnS2, ContractFormat.DetailColumnS3, ContractFormat.DetailColumnS4,
 ContractFormat.DetailColumnS5, ContractFormat.DetailColumnS6, ContractFormat.DetailColumnS7, ContractFormat.PrintSpecs,
 ContractFormat.ItemPrintOut, ContractFormat.PaymentDetail, ContractFormat.PrintOperName, ContractFormat.ContDueDate, ContractFormat.ShowMods,
 ContractFormat.ShowSig, ContractFormat.PrintItemRate, ContractFormat.PrintDiscDetail, ContractFormat.PrintContComments,
 ContractFormat.ShowContractFooter, ContractFormat.DeliveryComments, ContractFormat.ShowAllItems, ContractFormat.DeliveryAtTop,
 ContractFormat.SetupTime, ContractFormat.PrintTotalsSection, ContractFormat.ShowRetailPricing, ContractFormat.PrintLegalEase,
 ContractFormat.PrintItemPicture, ContractFormat.PrintDeliveryTruck, ContractFormat.PrintCCAuthorization, ContractFormat.PrintMarketingPage,
 ContractFormat.Footer, ContractFormat.Groupby, ContractFormat.SubGroup, ContractFormat.WebLinksHeader, ContractFormat.WebLinksItems,
 ContractFormat.DiscountedRates, ContractFormat.PrintAfterContract, ContractFormat.WebLinksPay, ContractFormat.PaymentDetailSummary,
 Contractformat.HideLogisticsIN, Contractformat.HideLogisticsOUT, contractformat.Versionformat
  FROM WorkOrderFormat AS ContractFormat
 ORDER BY ContractFormat.[Number] ASC
)
) AS Main ORDER BY Main.[FormatNumber] DESC
) AS MainTbl
) AS ContractFormatTbl
) AS CFormat ON iif(left(T.[CNTR],1) = 'w' and @ContractFormatNumber <= 20 ,'W','C') = CFormat.[Type]
     WHERE T.[CNTR] IN (@ContractNo)

   
  ) AS ContractTbl ON TITbl.[CNTR] = ContractTbl.TCNTR

 LEFT JOIN (
SELECT TL.[NUM], TL.[Name], TL.[INST], TL.[DescriptionLong], TL.[Group], TL.[UserDefined1], TL.[UserDefined2]
 FROM TranslationNames  
LEFT JOIN ItemFile_Tr TL on TranslationNames.LanguageCode = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
   OR TranslationNames.Translations = @Language
  ) AS ItemTL ON TITbl.Item = ItemTL.Num
 
 LEFT JOIN (
SELECT TL.[NUM] as HeaderNum, TL.[Name] as HeaderName, TL.[DescriptionLong] as HeaderDescriptionLong, TL.[UserDefined1] as HeaderUserDefined1,
TL.[UserDefined2] as HeaderUserDefined2
 FROM TranslationNames LEFT JOIN ItemFile_Tr TL ON TranslationNames.LanguageCode  = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
   OR TranslationNames.Translations = @Language
  ) AS HeaderTL ON TITbl.HeaderNum = HeaderTL.HeaderNum

LEFT JOIN (
SELECT TL.[Name] AS CategoryName, TL.[Category]
FROM TranslationNames LEFT JOIN ItemCategory_Tr TL ON TranslationNames.LanguageCode = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
OR TranslationNames.Translations = @Language
) AS CatTL ON TITbl.[Category] = CatTL.[Category]
 
LEFT JOIN (
SELECT TL.DepartmentName, TL.[Department]
FROM TranslationNames
LEFT JOIN ItemDepartment_Tr TL ON TranslationNames.LanguageCode = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
OR TranslationNames.Translations = @Language
) AS DeptTL ON TITbl.[Department] = DeptTL.[Department]
 
LEFT JOIN (
SELECT TL.DivisionName, TL.DivisionNumber
FROM TranslationNames
LEFT JOIN ItemDivision_Tr TL ON TranslationNames.LanguageCode  = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
OR TranslationNames.Translations = @Language
) AS DivTL ON TITbl.DivisionNumber = DivTL.DivisionNumber
 
LEFT JOIN (
SELECT TL.[Num], TL.Specs, TL.PrintOut, TL.[Notes] as ItemCommentNotes
FROM TranslationNames
LEFT JOIN ItemComments_Tr TL ON TranslationNames.LanguageCode  = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
OR TranslationNames.Translations = @Language
) AS ItemCommTL ON TITbl.[Num] = ItemCommTL.[Num]
 
LEFT JOIN (
SELECT TL.TypeDescrip, TL.[Type] AS ItemType
FROM TranslationNames LEFT JOIN ItemType_Tr TL ON TranslationNames.LanguageCode = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
OR TranslationNames.Translations = @Language
) AS ItemTypeTL ON TITbl.[Type] = ItemTypeTL.[ItemType]
 
LEFT JOIN (
SELECT TL.[Store], TL.STORE_NAME, TL.STORE_STRT, TL.RemitName, TL.RemitStreet, TL.ItemPercentageName, TL.ItemDefined1, TL.ItemDefined2, TL.DamageWaiverName
FROM TranslationNames
LEFT JOIN ParameterFile_Tr TL ON TranslationNames.LanguageCode = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
OR TranslationNames.Translations = @Language
) AS ParmTL ON ContractTbl.STR = ParmTL.[Store]
 
LEFT JOIN (
SELECT TL.OperationNumber, TL.OperationName
FROM TranslationNames
LEFT JOIN TransactionOperation_Tr TL ON TranslationNames.LanguageCode = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
OR TranslationNames.Translations = @Language
) AS TOPERTL ON ContractTbl.[Operation] = TOPERTL.OperationNumber
 
LEFT JOIN (
SELECT TL.[Message], TL.[Number]
FROM TranslationNames LEFT JOIN WarningMessage_Tr TL ON TranslationNames.LanguageCode = TL.Languagecode
WHERE TranslationNames.Translations IS NULL OR TranslationNames.Translations = @Language
) AS WarnTL ON TITbl.[Msg] = WarnTL.[Number]
 
LEFT JOIN (
SELECT TL.TruckName as DTruckName, TL.TruckNumber as DTruckNumber
FROM TranslationNames
LEFT JOIN DeliveryTrucks_Tr TL on TranslationNames.LanguageCode = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
OR TranslationNames.Translations = @Language
) AS DTruckTL ON ContractTbl.DeliveryTruckNumber = DTruckTL.DTruckNumber
 
LEFT JOIN (
SELECT TL.TruckName as PTruckName, TL.TruckNumber as PTruckNumber
FROM TranslationNames
LEFT JOIN DeliveryTrucks_Tr TL on TranslationNames.LanguageCode  = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
OR TranslationNames.Translations = @Language
) AS PTruckTL ON ContractTbl.PickupTruckNumber = PTruckTL.PTruckNumber
 
LEFT JOIN (
SELECT TL.[Num] as CommentsNum, TL.Specs as Comments1Specs, TL.PrintOut as Comments1PrintOut, TL.[Notes] AS Comments1Notes
FROM TranslationNames LEFT JOIN ItemComments_Tr TL on TranslationNames.LanguageCode = TL.Languagecode
WHERE TranslationNames.Translations IS NULL OR TranslationNames.Translations = @Language
) AS Comm1TL ON TITbl.HeaderNum = Comm1TL.CommentsNum
 
LEFT JOIN (
SELECT TL.CNUM, TL.CustomerPrintout  
FROM TranslationNames
LEFT JOIN CustomerFile_Tr TL ON TranslationNames.LanguageCode  = TL.Languagecode
WHERE TranslationNames.Translations IS NULL
OR TranslationNames.Translations = @Language
) AS CustTL ON ContractTbl.CNUM = CustTL.CNUM
 
  END
go

