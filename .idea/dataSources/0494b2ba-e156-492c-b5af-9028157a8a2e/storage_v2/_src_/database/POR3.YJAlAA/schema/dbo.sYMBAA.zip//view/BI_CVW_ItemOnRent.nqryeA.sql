-- SQL Deploy  3/29/2018 8:38 AM
CREATE VIEW [dbo].[BI_CVW_ItemOnRent]
 
AS
SELECT Transactions.[Str] AS Store,ItemCategory.[Name] as [Category], Sum(TransactionItems.QTY*ItemFile.PURP) AS [Value on Rent],Sum(TransactionItems.QTY) AS [Quantity on Rent]
FROM ItemCategory 
INNER JOIN (Transactions 
INNER JOIN (ItemFile 
INNER JOIN TransactionItems ON ItemFile.NUM = TransactionItems.ITEM) ON Transactions.CNTR = TransactionItems.CNTR) ON ItemCategory.Category = ItemFile.Category
WHERE Transactions.STAT Like 'O%' AND (TransactionItems.TXTY Like 'R' Or TransactionItems.TXTY Like 'RH') AND ItemFile.Purp > 0
GROUP BY Transactions.[Str],ItemCategory.[Name]

go

