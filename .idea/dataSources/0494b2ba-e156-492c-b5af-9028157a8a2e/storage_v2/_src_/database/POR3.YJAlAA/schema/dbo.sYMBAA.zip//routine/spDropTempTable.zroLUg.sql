
CREATE PROCEDURE DBO.spDropTempTable
(
	@sTableName			VARCHAR(500)
)

AS

/*****************************************************************************************/
--	POR.DBO.spDropTempTable
--		Drops a temporary working table created by the client.  Always in POR
--
--	PARAMETERS: @sTableName  - The name of a working table built by the client in POR
--
--	HISTORY:	10/23/2014	JY	CREATED	--
--
--
/*****************************************************************************************/

BEGIN

	DECLARE @ssql	VARCHAR(600)

	IF (object_id('POR.dbo.' + @stablename) > 0)
	BEGIN
		set @ssql = 'DROP TABLE POR.dbo.' + @stablename
		exec(@ssql)
	END
	ELSE
	BEGIN
		IF (object_id(@stablename) > 0)
		BEGIN
			set @ssql = 'DROP TABLE ' + @stablename
			exec(@ssql)
		END
	END

END

go

