
CREATE PROCEDURE [dbo].[spAT_GetJournalEntriesForExport]
--WITH ENCRYPTION
AS
SET NOCOUNT ON

DECLARE @bMultiDepot Bit
--SET @bMultiDepot = CASE WHEN (SELECT COUNT(*) FROM dbo.TH_DEPOTS WHERE DPT_CURRENT_FLAG = 1) > 1
--                        THEN 1
--                        ELSE 0
--                   END

SELECT 
 GLd.Id															AS SRC_ID
,GL.Id															AS HDR_ID
,'POR JE ' + Cast(GL.Id As Varchar(9))							AS REFERENCE
,gl.TransDate													AS POST_DATE
,'POR Journal Entries'											AS DETAILS_HDR
,'POR Journal Entry ' + CAST(GLd.Store AS Varchar(9))			AS DETAILS_ITEM
,CASE WHEN GLd.TransAmount < 0
		THEN Gld.AccountNumber ELSE '' END					AS CRD_NOMINAL_CODE
,''															AS CRD_NOMINAL_NAME
,CASE WHEN GLd.TransAmount >= 0
		THEN Gld.AccountNumber ELSE '' END					AS DBT_NOMINAL_CODE
,''															AS DBT_NOMINAL_NAME
,ABS(gld.TransAmount)											AS AMOUNT
,GLd.Store														AS DEPT_CODE
FROM AccountingAPIQueueGL GL
INNER JOIN AccountingAPIQueueGLDetail GLd ON GLd.AccountingAPIQueueGLId = GL.Id
WHERE GL.DateApproved IS NOT NULL
  AND GL.DatePosted IS NULL
  AND GL.DateCancelled IS NULL
  AND GL.NoExport = 0
  AND GLd.NoExport = 0
  AND GLd.TransAmount <> 0
  AND GL.RetryCount <= 10
  AND GL.Batch > 0
--  AND GL.TransCodeId IN (4,30,60,15) -- GLTransAdd, DepositAdd, DisbursementAdd

RETURN

go

grant execute on spAT_GetJournalEntriesForExport to PORUser
go

