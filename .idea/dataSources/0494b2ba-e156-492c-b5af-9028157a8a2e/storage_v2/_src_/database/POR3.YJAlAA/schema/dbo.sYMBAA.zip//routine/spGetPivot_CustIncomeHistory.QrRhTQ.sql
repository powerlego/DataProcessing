
CREATE PROCEDURE DBO.spGetPivot_CustIncomeHistory
(
	@sQuery			VARCHAR(5000),
	@sFieldName		VARCHAR(100),
	@sType			VARCHAR(5)

)

AS

/*************************************************************************/
--	POR.DBO.spGetPivot_CustIncomeHistory
--		Returns a table with totals summarized by month, pivoted on year
--
--	PARAMETERS: @sQuery     - The base query is formed in the client
--				@sFieldName - Specifies column being summarized 
--							     ([TotlAmt], [SaleAmt], [RentAmt])
--				@sType		- Summary function ('SUM', 'COUNT')
--
--	HISTORY:	08/14/2014	JY	CREATED									 
--				11/21/2015  JY  Add CNTR to initial Income Summary load
--				11/15/2016  JY  Camel case for output column names
--
/*************************************************************************/

BEGIN
	SET NOCOUNT ON

	DECLARE @SSQL VARCHAR(1500)
	DECLARE @scolumns AS VARCHAR(MAX)

	CREATE TABLE #TMP_INCOMESUMMARY
	([MONTH]		INTEGER,
	 [YEAR]			INTEGER,
	 [RENTAMT]		MONEY,
	 [SALEAMT]		MONEY,
	 [TOTLAMT]		MONEY,
	 [CNTR]			NVARCHAR(20)
	)

	-- Get Income summary data using query from client
	INSERT INTO #TMP_INCOMESUMMARY		
	exec(@sQuery)


	CREATE TABLE #TMP_TRANSSUMMARY
	(	[MONTH]			INTEGER,
		[YEAR]			INTEGER,
		[AMOUNT]		INTEGER
	)

	IF (@sType = 'SUM')
	BEGIN
		ALTER TABLE #TMP_TRANSSUMMARY ALTER COLUMN [Amount] MONEY
	END

				-- Get transaction summary (COUNT)
	SET @SSQL = 'INSERT INTO #TMP_TRANSSUMMARY ' +
				'SELECT [Month], [Year], ' +
				@sType + '(' + @sFieldName + ') AS Amount ' +
				' From #TMP_INCOMESUMMARY ' +
				' WHERE ISNULL(' + @sFieldName + ',0) != 0 ' +
				' GROUP BY [Month], [Year] ' 

	--SELECT @SSQL
	exec(@SSQL)

	select @scolumns = substring((Select DISTINCT ',' + QUOTENAME([year]) FROM #TMP_TRANSSUMMARY order by ',' + QUOTENAME([year]) desc FOR XML PATH ('')),2, 1000) 

	SELECT [MONTH], SUM(AMOUNT) AS MONTH_AMT
	  INTO #TMP_MONTH_TOTAL
	  FROM #TMP_TRANSSUMMARY
	GROUP BY [MONTH]
	ORDER BY [MONTH]

	set @SSQL =
	'SELECT *
	INTO #TMP_PIVOT
	FROM #TMP_TRANSSUMMARY
	PIVOT 
	(
	  SUM(amount) 
	  FOR [year] IN( ' + @scolumns + ' )) as Amount'

	  -- add the monthly total column to the pivot table
	set @ssql = @ssql + '; SELECT P.[Month], M.[Month_Amt] AS [Total],' + @scolumns + ' FROM #TMP_PIVOT P JOIN #TMP_MONTH_TOTAL M ON M.[MONTH] = P.[MONTH] ORDER BY P.[MONTH]'
	exec(@ssql)

	drop table #TMP_MONTH_TOTAL
	drop table #TMP_TRANSSUMMARY
	drop table #TMP_INCOMESUMMARY

	SET NOCOUNT OFF

END

go

