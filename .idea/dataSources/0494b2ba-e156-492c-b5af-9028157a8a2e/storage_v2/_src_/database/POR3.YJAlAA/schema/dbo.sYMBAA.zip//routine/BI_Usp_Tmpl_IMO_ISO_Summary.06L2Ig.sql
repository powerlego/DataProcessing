
CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_IMO_ISO_Summary]
	@WidgetDataFilter KeyValuePair READONLY 
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE	@StoreNo VarChar(3) = null;
	SELECT @StoreNo = SUBSTRING([Value], 1, 20) FROM @WidgetDataFilter WHERE [Key] = 'StoreNo';

	--TODO alter
    SELECT  Maint.[Description], Maint.[COUNT] AS 'Quantity', Maint.[OEC], Maint.[PercentOEC]
	FROM (
			SELECT 'IMO' as [Description], 
					SUM(IMO) as [COUNT],
					SUM(IIF(IMO > 0, OEC, 0)) AS [OEC], 
					((SUM(IIF(IMO > 0, OEC, 0)) / SUM(OEC))*100) AS [PercentOEC]

			FROM dbo.BI_VW_Items_SerializedFleet s
			WHERE (@StoreNo IS NULL OR @StoreNo = '000' OR s.CurrentStore = @StoreNo)

			UNION

			SELECT  'ISO' as [Description], 
					SUM(ISO) as [COUNT],
					SUM(IIF(ISO > 0, OEC, 0)) AS [OEC], 
					((SUM(IIF(ISO > 0, OEC, 0)) / SUM(OEC))*100) AS [PercentOEC]

			FROM dbo.BI_VW_Items_SerializedFleet s
			WHERE (@StoreNo IS NULL OR @StoreNo = '000' OR s.CurrentStore = @StoreNo)

	) Maint
END

go

