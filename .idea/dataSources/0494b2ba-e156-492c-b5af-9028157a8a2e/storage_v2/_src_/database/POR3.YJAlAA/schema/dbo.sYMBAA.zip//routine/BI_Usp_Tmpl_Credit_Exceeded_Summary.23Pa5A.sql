

CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_Credit_Exceeded_Summary]
	@WidgetDataFilter KeyValuePair READONLY
AS
BEGIN

	SELECT COUNT(RangeCNT.CNUM) AS [CountCustomers], RangeCnt.[Range] as Interval  
	FROM (
		-- TODO Change to select from Credit Exceeded Stored proc
			SELECT IIF(Main.CNUM IS NULL, 'None', Main.CNUM) as [CNUM], 
					Main.NAME AS [Name],
					Main.CreditLimit AS [CreditGranted],
					Main.CurrentBalance AS [CreditUsed],
					Main.OverLimit, 
					CONVERT(varchar(50),Main.PercentInt) +'%' AS [PercentUsed],
					(SELECT CASE 
							WHEN (Main.PercentInt > 0 and Main.PercentInt <= 10) THEN 'Within 10%'
							WHEN (Main.PercentInt > 10 and Main.PercentInt <= 20) THEN 'Within 20%'
							WHEN (Main.PercentInt > 20 and Main.PercentInt <= 50) THEN 'Within 50%'
							WHEN (Main.PercentInt > 50) THEN 'Over 50%'
							Else '0%'
						END) AS [Range],
						(SELECT CASE 
							WHEN  (Main.PercentInt > 0 and Main.PercentInt <= 10) THEN 1
							WHEN  (Main.PercentInt > 10 and Main.PercentInt <= 20) THEN 2
							WHEN (Main.PercentInt > 20 and Main.PercentInt <= 50) THEN 3
							WHEN (Main.PercentInt > 50) THEN 4
							ELSE 0
						END) AS [RowOrder]

			FROM(
				SELECT Details.CNUM, Details.NAME, Details.CreditLimit, Details.CurrentBalance, Details.OverLimit,
						(CAST(Details.OverLimit as money) / CAST(Details.CreditLimit as money)*100) AS [PercentInt]
				FROM (
					SELECT	cust.CNUM,
							cust.NAME, 
							cust.CreditLimit ,
							cust.CurrentBalance,
							IIF(cust.CurrentBalance > cust.CreditLimit,(cust.CurrentBalance - cust.CreditLimit),0) AS OverLimit 
					FROM CustomerFile cust
					WHERE cust.CreditLimit > 0 AND cust.[Status] = 'E' AND cust.CurrentBalance > 0 
				) AS Details
			) AS Main
			WHERE Main.OverLimit > 0
	) AS RangeCNT
	GROUP BY Rangecnt.[Range], RangeCnt.[RowOrder] 
	ORDER BY RangeCnt.[RowOrder] DESC

END



go

