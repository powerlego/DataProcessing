
CREATE PROCEDURE DBO.spGetPivot_ItemIncomeHistory
(
	@sSelectQuery		VARCHAR(5000),
	@sType				VARCHAR(10),
	@bShowPerUnit		TINYINT = 0,
	@bInSalesTypes		TINYINT = 0
)

AS

/*************************************************************************/
--	POR.DBO.spGetPivot_ItemIncomeHistory
--		Returns a table with totals summarized by month, pivoted on year
--
--	PARAMETERS: @sSelectQuery  - The base query is formed in the client
--				@sType		   - Summary function ('TOTAL', 'UNIT')
--				@bShowPerUnit  - Value of check box on client, used in UNIT section
--				@bInSalesTypes - Is the item one of the sale types, used in UNIT section
--
--	HISTORY:	10/22/2014	JY	CREATED									 
--				11/15/2016  JY  Camel case for output column names
--				03/07/2018  JY  @bInSalesTypes not being handled correctly
--
/*************************************************************************/

BEGIN
SET NOCOUNT ON

DECLARE @sSQL VARCHAR(1500)
DECLARE @sItemSelect VARCHAR(1500)
DECLARE @sColumns AS VARCHAR(MAX)

CREATE TABLE #TMP_INCOME
(
	[Month]			INTEGER,
	[Year]			INTEGER,
	[Income]		MONEY,
	[Times]			INTEGER,
	[Quantity]		INTEGER
)

CREATE TABLE #TMP_ROLLUP
(
	[Month]			INTEGER,
	[Year]			INTEGER,
	[Total Income]	MONEY
)

CREATE TABLE #TMP_ROLLUP2
(
	[Month]			INTEGER,
	[Total Income]	MONEY
)

-- Copy of original client statement
-- "TRANSFORM Sum([Income]) AS [The Value] SELECT [Month], Sum([Income]) AS [Total Income] From (" & SelectQuery & ") GROUP BY [Month] 
--  ORDER BY [Year] DESC PIVOT [Year];"

-- Ex. @sSelectQuery -- 'SELECT Month([Date]) AS [Month], Year([Date]) AS [Year], [Income], [Times], [Quantity] 
--						  FROM ItemFile 
--                       INNER JOIN ItemIncome ON ItemFile.NUM = ItemIncome.Num 
--                       WHERE (ItemFile.Header)= ''EXCAV''
INSERT INTO #TMP_INCOME
EXEC(@sSelectQuery)

--SELECT * FROM #tMP_INCOME

-- Rollup total amount of transactions
INSERT INTO #TMP_ROLLUP
SELECT [MONTH],[YEAR], SUM(INCOME) AS [Total Income]
  FROM #TMP_INCOME
GROUP BY [YEAR], [MONTH]
ORDER BY [YEAR], [MONTH]

-- Get total by month for the total column
INSERT INTO #TMP_ROLLUP2
SELECT [Month], SUM([Total Income]) AS [Total Income]
  FROM #TMP_ROLLUP
GROUP BY [Month]
ORDER BY [Month]

-- Get a list of years for column names
select @sColumns = substring((Select DISTINCT ',' + QUOTENAME([YEAR]) FROM #TMP_ROLLUP ORDER BY ',' + QUOTENAME([YEAR]) DESC FOR XML PATH ('')),2, 1000) 

--SELECT @sColumns
IF (@sType = 'TOTAL')
BEGIN
	set @SSQL =
	'SELECT *
	INTO #TMP_PIVOT1
	FROM #TMP_ROLLUP
	PIVOT 
	(
	  SUM([Total Income]) 
	  FOR [Year] IN( ' + @sColumns + ' )) as [Total Income]; ' 

	-- add the monthly total column to the pivot table
	set @ssql = @ssql + 'SELECT P.[Month], T.[Total Income], ' + @sColumns + ' FROM #TMP_PIVOT1 P JOIN #TMP_ROLLUP2 T ON P.[MONTH] = T.[MONTH]'

	execute(@ssql)
END
ELSE
BEGIN
	CREATE TABLE #TMP_ROLLUP3
	(
		[Month]		INTEGER,
		[Year]		INTEGER,
		[Total]		MONEY
	)

	INSERT INTO #TMP_ROLLUP3
	SELECT [Month],[Year], 
		CASE 	WHEN (@bShowPerUnit = 1 AND @bInSalesTypes = 1) THEN Round(( Sum([INCOME]) / IIf(Sum([Times])=0,1,Sum([Times])) ),2)
				WHEN (@bShowPerUnit = 1 AND @bInSalesTypes = 0) THEN Round( ( Sum([INCOME]) / IIf(Sum([Quantity])=0,1,Sum([Quantity])) ),2) 
				ELSE Sum([Times]) END AS [Total]
			FROM #TMP_INCOME
		GROUP BY [YEAR], [MONTH]
		ORDER BY [YEAR], [MONTH]
 
-- SELECT * FROM #TMP_ROLLUP3

	set @SSQL =
	'SELECT *
	INTO #TMP_PIVOT2
	FROM #TMP_ROLLUP3
	PIVOT 
	(
	  SUM([Total]) 
	  FOR [Year] IN( ' + @sColumns + ' )) as [Total]; '

	-- add the monthly total column to the pivot table
	set @ssql = @ssql + 'SELECT P.MONTH AS [Month], T.[Total Income], ' + @sColumns + ' FROM #TMP_PIVOT2 P JOIN #TMP_ROLLUP2 T ON P.[MONTH] = T.[MONTH]'
	
	execute(@ssql)
	DROP TABLE #TMP_ROLLUP3
END

DROP TABLE #TMP_INCOME
DROP TABLE #TMP_ROLLUP
DROP TABLE #TMP_ROLLUP2



SET NOCOUNT OFF

END

go

