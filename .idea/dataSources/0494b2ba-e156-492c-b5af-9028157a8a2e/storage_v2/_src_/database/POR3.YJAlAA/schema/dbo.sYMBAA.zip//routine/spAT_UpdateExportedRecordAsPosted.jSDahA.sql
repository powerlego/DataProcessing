
CREATE PROCEDURE [dbo].[spAT_UpdateExportedRecordAsPosted](
 @pilAxpId int 
,@pisType varchar(4)
,@pilObjId int
,@pisAccNo varchar(20)
,@posErrorMsg varchar(512) OUTPUT -- any user / server error
) 
--WITH ENCRYPTION 
AS
--
--
SET NOCOUNT ON
SET @posErrorMsg = NULL
DECLARE @lErrorNo Int

IF @pisType = 'CUST'
BEGIN
  UPDATE dbo.AccountingAPIQueueCustomer
  SET    DatePosted = GetDate()
  WHERE  Id = @pilObjId

END

IF @pisType = 'SUPP'
BEGIN
  UPDATE dbo.AccountingAPIQueueVendor
  SET    DatePosted = GetDate()
  WHERE  AccountingAPIQueueVendorId = @pilObjId

END

--IF @pisType = 'IVB'
--BEGIN
--  UPDATE dbo.TH_HIRE_INV_BATCHES
--  SET    IVB_POSTED = 1
--        ,IVB_POSTING_ID = @pilAxpId
--  WHERE  IVB_BATCH_NUMBER = @pilObjId

--  EXEC @lErrorNo = dbo.splbTestError @@ERROR, 'spAxpAddEntry\400', @posErrorMsg output
--  IF @lErrorNo != 0 RETURN @lErrorNo
--END

IF (@pisType = 'IVC' Or @pisType = 'CTX' Or @pisType = 'PMT')
BEGIN
  UPDATE dbo.AccountingAPIQueueTR
  SET    DatePosted = GetDate()
  WHERE  Id = @pilObjId

END

IF @pisType = 'PIV'
BEGIN
  UPDATE dbo.AccountingAPIQueuePO
  SET    DatePosted = GetDate()
  WHERE  AccountingAPIQueuePOId = @pilObjId

END

IF @pisType = 'FAP'
BEGIN
  UPDATE dbo.AccountingAPIQueueGL
  SET    DatePosted = GetDate()
  FROM   dbo.AccountingAPIQueueGLDetail 
  WHERE  AccountingAPIQueueGLDetail.Id = @pilObjId
    AND  AccountingAPIQueueGL.Id = AccountingAPIQueueGLDetail.AccountingAPIQueueGLId

END

RETURN
go

grant execute on spAT_UpdateExportedRecordAsPosted to PORUser
go

