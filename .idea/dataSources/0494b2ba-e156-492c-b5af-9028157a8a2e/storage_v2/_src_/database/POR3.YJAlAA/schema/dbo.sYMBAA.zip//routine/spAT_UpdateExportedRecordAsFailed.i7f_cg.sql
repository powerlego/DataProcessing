
CREATE PROCEDURE [dbo].[spAT_UpdateExportedRecordAsFailed](
 @pilAxpId int 
,@pisType varchar(4)
,@pilObjId int
,@pisErrorMessage varchar(1000)
,@pisAccNo varchar(20)
,@posErrorMsg varchar(512) OUTPUT -- any user / server error
) 
--WITH ENCRYPTION 
AS
--
--
SET NOCOUNT ON
SET @posErrorMsg = NULL
DECLARE @lErrorNo Int

-- Customer queue
IF @pisType = 'CUST'
BEGIN
  UPDATE dbo.AccountingAPIQueueCustomer
	SET DateError = GetDate()
		,ErrorMsg = @pisErrorMessage
		,RetryCount = RetryCount + 1
		,DateChanged = GETDATE()
	WHERE  Id = @pilObjId

  --EXEC @lErrorNo = dbo.splbTestError @@ERROR, 'spAxpAddEntry\200', @posErrorMsg output
  --IF @lErrorNo != 0 RETURN @lErrorNo
END

-- Vendor queue
IF @pisType = 'SUPP'
BEGIN
  UPDATE dbo.AccountingAPIQueueVendor
	SET DateError = GetDate()
		,ErrorMsg = @pisErrorMessage
		,RetryCount = RetryCount + 1
		,DateChanged = GETDATE()
  WHERE  AccountingAPIQueueVendorId = @pilObjId

END

-- TR Queue - Invoice, Payment, Credit
IF (@pisType = 'IVC' OR @pisType = 'CTX' OR @pisType = 'PMT')
BEGIN
  UPDATE dbo.AccountingAPIQueueTR
	SET DateError = GetDate()
		,ErrorMsg = @pisErrorMessage
		,RetryCount = RetryCount + 1
		,DateChanged = GETDATE()
  WHERE  Id = @pilObjId

END

-- PO Queue
IF @pisType = 'PIV'
BEGIN
  UPDATE dbo.AccountingAPIQueuePO
	SET DateError = GetDate()
		,ErrorMsg = @pisErrorMessage
		,RetryCount = RetryCount + 1
		,DateChanged = GETDATE()
  WHERE  AccountingAPIQueuePOId = @pilObjId

END

-- GL Queue
IF @pisType = 'FAP'
BEGIN

	UPDATE AccountingAPIQueueGL 
	SET DateError = GetDate()
		,ErrorMsg = @pisErrorMessage
		,RetryCount = RetryCount + 1
		,DateChanged = GETDATE()
	From AccountingAPIQueueGL A 
	Inner Join AccountingAPIQueueGLDetail B ON  A.Id = B.AccountingAPIQueueGLId
	Where B.Id = @pilObjId

END

RETURN
go

grant execute on spAT_UpdateExportedRecordAsFailed to PORUser
go

