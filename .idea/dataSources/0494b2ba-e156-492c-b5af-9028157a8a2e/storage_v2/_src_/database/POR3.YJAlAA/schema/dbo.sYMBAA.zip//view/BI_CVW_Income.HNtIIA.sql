-- SQL Deploy  3/29/2018 8:38 AM
CREATE VIEW [dbo].[BI_CVW_Income]
 	AS
SELECT CustomerFile.[CNUM] as [CustNum], CustomerFile.[Name], CustomerFile.Address, CustomerFile.City, CustomerFile.Zip, 
DateFromParts(Year([Date]), Month([Date]), 1) As [Posted], Sum([RentTX]+[RentNT]) AS Rent, 
Sum([SaleTX]+[SaleNT]) AS Sale, Sum([AssetTX]+[AssetNT]) AS Asset, Sum([DWTx]+[DWNT]) AS DmgWvr, 
Sum(RentTx + SaleTx + DwTx + AssetTx + RentNT + SaleNT + DwNT + AssetNT + Other + Tax + ItemPercentageTax + ItemPercentageTax + ItemPercentageNonTax) As Income,TotalsContractsAccrual.Store
FROM TotalsContractsAccrual 
INNER JOIN CustomerFile ON TotalsContractsAccrual.Cusn = CustomerFile.CNUM
GROUP BY CustomerFile.[CNUM], CustomerFile.NAME, CustomerFile.Address, CustomerFile.CITY, CustomerFile.ZIP, [Date],TotalsContractsAccrual.Store;

go

