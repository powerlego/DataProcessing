-- SQL Deploy  3/29/2018 8:38 AM
CREATE PROCEDURE [dbo].[BI_Usp_CloneDashboard]
@OperatorNo int,
@ProfileId int = 2, 
@DashboardId int = 1 
AS
BEGIN
SET NOCOUNT ON;
DECLARE @OldDashboardId int = @DashboardId;
DECLARE @NewDashboardId int;
 
 
 
INSERT INTO dbo.BI_Dashboards(UserProfileId, 
OperatorId, DashboardTypeId, DashboardTitle, 
DashboardOrder, StartDateFilter, EndDateFilter,
StoreFilter, OverrideChildSettings, CreatedBy, 
ChangedBy, ChangeNote)
SELECT @ProfileId as [UserProfileId], 
@OperatorNo as [OperatorId], 
Dashboard.[DashboardTypeId],
Dashboard.[DashboardTitle],
Dashboard.[DashboardOrder],
Dashboard.[StartDateFilter],
Dashboard.[EndDateFilter],
Dashboard.[StoreFilter],
Dashboard.[OverrideChildSettings], 
@OperatorNo as [CreatedBy],
@OperatorNo as [ChangedBy], 
'Application: Elite Launchpad; Dashboard Clone' as [ChangeNote] 
FROM 
(SELECT	[DashboardTypeId]
,[DashboardTitle]
,[DashboardOrder]
,[StartDateFilter]
,[EndDateFilter]
,[StoreFilter]
,[OverrideChildSettings]
FROM dbo.BI_Dashboards 
WHERE ID = @OldDashboardId) As Dashboard;
 
 
 
SET @NewDashboardId = SCOPE_IDENTITY();
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
SELECT @NewDashboardId;
END
go

