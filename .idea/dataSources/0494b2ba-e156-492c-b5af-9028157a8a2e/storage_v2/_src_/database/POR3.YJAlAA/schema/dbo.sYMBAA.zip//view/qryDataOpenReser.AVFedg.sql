CREATE View qryDataOpenReser AS 

SELECT T.CNTR AS Contract, T.STR AS Store, convert(varchar(25),T.[Date],101) AS OutDate, CF.Name AS CustName, iif(left(T.STAT,1) = 'O','Open','Reservation') AS Status, 
       T.Totl AS Total, iif(T.DELVR<>0,convert(varchar(25),DeliveryDate,101),'') AS DeliveryDate, 
	   iif(T.Pickup<>0,convert(varchar(25),PickupDate,101),'') AS PickupDate, T.JOBN AS ContractInfo, T.AutoLicense, 
	   Max(TI.HRSC) AS Hours, T.Notes AS ContractComments
FROM Transactions T 
     INNER JOIN TransactionItems TI ON T.CNTR = TI.CNTR
	 INNER JOIN CustomerFile CF ON T.CUSN = CF.CNUM
WHERE left(T.STAT,1) In ('O','R')
GROUP BY T.CNTR, T.STR, T.[DATE], CF.NAME, iif(left(T.STAT,1) = 'O','Open','Reservation'), T.TOTL, 
         iif(T.DELVR<>0,convert(varchar(25),DeliveryDate,101),''), iif(T.Pickup<>0,convert(varchar(25),PickupDate,101),''), 
		 T.JOBN, T.AutoLicense, T.Notes
go

