
-- Customer Status (Type)
--D	Cash	
--E	On Account	
--H	Cash Only	

CREATE VIEW [dbo].[vwAT_ContractsPendingExport] 
--WITH ENCRYPTION 
AS
SELECT 
 tr.TransDate										as IVC_INVOICE_DATE
,tr.Id												as IVC_INVOICE_NUMBER
--, CASE tr.TransCodeId
--		WHEN 15 THEN LTRIM(RTRIM(cfc.[NAME]))
--		ELSE LTRIM(RTRIM(cft.[NAME]))  END			AS CST_NAME
,LTRIM(RTRIM(cft.[NAME]))							AS CST_NAME
,dbo.fnAT_InvoiceSourceCode(tr.ContractNumber)	AS IVC_INVOICE_SOURCE
,CASE WHEN Tr.TransCodeId = 7 THEN 'ACCOUNT'
	  WHEN Tr.TransCodeId = 15 THEN 'CASH'
	  WHEN Tr.TransCodeId IN (40,43) THEN 'CREDIT'
	  Else 'CONTRACT' END							AS IVC_INVOICE_TYPE
,1													AS IVC_CASH_REQUIRES_POSTING_FLAG
--,LTRIM(RTRIM(tr.CustomerNumber))					AS IVC_CUSTOMER_NUMBER
,RTRIM(LTRIM(ac.AccountingLink))					AS IVC_CUSTOMER_NUMBER
,Cast(tr.Store As Int)								as IVC_DEPOT_ID
,1													as IVC_NONBATCH_POSTING_ID
,0													as IVC_CASH_PAID_FLAG
,tr.ContractNumber									as IVC_USER_INVOICE_NUMBER
,1													as IVC_INVOICE_WHEN
,0													as DPT_BUS_AREA_ID
FROM AccountingAPIQueueTR tr
INNER JOIN AccountNumbers A ON A.Store = tr.Store
LEFT OUTER JOIN CustomerFile cft ON cft.CNUM = tr.CustomerNumber
LEFT OUTER JOIN AccountingCustomer ac ON ac.id = cft.AccountingCustomerId
--LEFT OUTER JOIN ExportFormat X ON X.ExportFormatId = A.ExportFormat
--LEFT OUTER JOIN CustomerFile cfc ON cfc.CNUM = x.GenericCashCustomerNumber
--LEFT OUTER JOIN AccountingCustomer acx ON acx.id = cfc.AccountingCustomerId

WHERE tr.DateApproved IS NOT NULL
  AND tr.DatePosted IS NULL
  AND tr.DateCancelled IS NULL
  AND tr.RetryCount <= 10
  AND tr.TransCodeId in (7,15,40,43)  -- Account or Cash Contract
  AND tr.Direction = 1

go

grant select on vwAT_ContractsPendingExport to PORUser
go

