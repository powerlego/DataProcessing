--------------------------------------------------------------
CREATE VIEW [dbo].[BI_VW_Income_TotalsSummary]
 
AS
SELECT 
		S.[Date], 
		DATEPART(YY, S.[Date]) as [Year],
		DATEPART(QQ, S.[Date]) as [Quarter],
		DATEPART(MM, S.[Date]) as [Month],
		DATENAME(MM, S.[Date]) as [Month Name],
		S.Store, 
		S.Batch, 
		S.BankDeposits, 
		S.CreditCards, 
		S.DebitCards, 
		S.[AR Cash], 
		S.[AR Account], 
		S.SuspenseFund, 
		S.SalesInventory, 
		S.CapitalizedRentalInventory, 
		S.NonCapitalizedRentalInventory, 
		S.ReservationValueMonth,
		S.ReservationValueQuarter, 
		S.ReservationValueYear, 
		S.ReservationValueAll 
  FROM (Select	a.[Date], 
				a.Store, 
				a.Batch, 
				a.BankDeposits, 
				a.CreditCards, 
				a.DebitCards, 
				(a.CashAmounts-a.CashPayments-a.CashCredits) AS [AR Cash], 
				(a.AccountAmounts-a.AccountPayments-a.AccountCredits) AS [AR Account], 
				a.SuspenseFund, 
				a.SalesInventory, 
				a.CapitalizedRentalInventory, 
				a.NonCapitalizedRentalInventory, 
				a.ReservationValueMonth,
				a.ReservationValueQuarter, 
				a.ReservationValueYear, 
				a.ReservationValueAll 
			FROM TotalsSummary a
			INNER JOIN
			(SELECT MAX(CONVERT(date, b.[Date], 126)) as [Date], b.Store
				from TotalsSummary b 
				group by DATEPART(yy, b.[Date]), DATEPART(mm, b.[Date]), Store) Dates
			ON CONVERT(date, a.[Date], 126) = Dates.Date and a.Store = Dates.Store) S
go

