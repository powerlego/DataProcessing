-- SQL Deploy  3/29/2018 8:38 AM
CREATE VIEW [dbo].[BI_CVW_CRMCallLog]
 
AS
SELECT CAST(GETDATE() AS DATE) AS DateStamp, 
DATEPART(HOUR, GETDATE()) AS [Hour], 
DATEPART(WEEKDAY, GETDATE()) AS [DayOfWeek], 
DATEPART(MONTH, GETDATE()) AS [Month],  
DATEPART(Year, GETDATE()) AS [Year], 
CallLog.CNUM AS CustomerNo, 
CustomerFile.NAME AS CustomerName, 
CustomerFile.CITY AS CustomerCity, 
CustomerFile.ZIP AS CustomerZip, 
 
OperatorId.OPNM AS Operator, 
Salesman.Name AS SalesRep, 
GroupFile.GroupName AS EmployeeGroup, 
CallLogType.TypeName AS CallType, 
CallLog.CallDuration, 
CallLog.Number AS LogNumber
FROM (CustomerFile 
RIGHT JOIN ((GroupFile 
RIGHT JOIN (OperatorId 
RIGHT JOIN CallLog ON OperatorId.OPNO = CallLog.Opr) ON GroupFile.GroupNumber = OperatorId.GroupNumber) 
 
LEFT JOIN CallLogType ON CallLog.Type = CallLogType.TypeNumber) ON CustomerFile.CNUM = CallLog.CNUM) 
LEFT JOIN Salesman ON OperatorId.OPNO = Salesman.OperatorNo
WHERE DATEPART(Year, GETDATE())>=DATEPART(Year, GETDATE()-4)

go

