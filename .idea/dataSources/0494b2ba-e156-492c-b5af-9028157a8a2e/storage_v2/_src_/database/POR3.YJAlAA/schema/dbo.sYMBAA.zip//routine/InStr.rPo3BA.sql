
-- =============================================
-- Author:		JA
-- Create date: 
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[InStr] 
(
	-- Add the parameters for the function here
	@SearchIn NVARCHAR,
	@SearchFor NVARCHAR
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result int

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = CHARINDEX(@SearchFor, @SearchIn)

	-- Return the result of the function
	RETURN @Result

END
go

