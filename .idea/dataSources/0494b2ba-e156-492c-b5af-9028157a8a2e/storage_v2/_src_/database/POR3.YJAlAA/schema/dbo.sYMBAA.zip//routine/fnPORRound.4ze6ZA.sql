
/*****************************************************************************************/
--	POR.DBO.fnPORRound
--
--	PARAMETERS: none
--
--	HISTORY:	09/12/2019	CM	(3840) CREATED	
--				09/27/2019  DJ  (3940) REVISED

/*****************************************************************************************/

CREATE FUNCTION [dbo].[fnPORRound]
(
	@Money numeric(20,3)

)
RETURNS numeric(20,3)
AS
BEGIN
	DECLARE @round numeric(20,3)

	SELECT @round = CASE WHEN 5 = (ROUND(@Money*POWER( 10,2+1),0,1) - (ROUND(@Money*POWER( 10,2) ,0,1) * 10))
							AND 0 = cast((ROUND(@Money *POWER(10,2),0,1) - (ROUND(@Money * POWER( 10,2 -1 ),0,1)* 10)) AS INTEGER) % 2
						 THEN ROUND(@Money,2,1) ELSE ROUND(@Money,2,0) 
					END
	RETURN @round
END
go

