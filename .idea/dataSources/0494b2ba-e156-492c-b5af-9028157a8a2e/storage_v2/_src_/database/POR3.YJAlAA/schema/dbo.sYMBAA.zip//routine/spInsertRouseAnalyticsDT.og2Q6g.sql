
CREATE PROCEDURE [dbo].[spInsertRouseAnalyticsDT]
    @TableToInsert RouseAnalyticsDatatable readonly,
	@TruncateTable bit
AS
BEGIN
	IF (@Truncatetable = 1)
		Truncate Table [dbo].RouseAnalytics;

    insert into [dbo].RouseAnalytics select * from @TableToInsert 
END
go

