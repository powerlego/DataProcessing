-- SQL Deploy  3/29/2018 8:38 AM
CREATE VIEW BI_VW_Transactions
 
AS
SELECT DISTINCT 
Transactions.[CNTR] as [Trans.Contract No]
, [STR] as [Trans.Store No]
, [CUSN] as [Trans.Customer No]
, [STAT] as [Trans.Status]
 
 
, [DATE] as [Trans.Contract Date]
, [TIME] as [Trans.Contract Time]
, [EventEndDate] as [Trans.Event End Date]
, [CMDT] As [Trans.Last Modified Date]
, [CLDT] As [Trans.Close Date]
, [Billed] As [Trans.Billed Date]
, [Completed] As [Trans.Completed Date]
 
, [Rent] As [Trans.Rent Amt]
, [Sale] As [Trans.Sale Amt]
, [Tax] As [Trans.Tax Amt]
, [Dmg] As [Trans.Dmg Wvr Amt]
, [TOTL] As [Trans.Total]
, [PAID] As [Trans.Total Paid]
, [TOTL]-[PAID] AS [Trans.Total Owed]
, [PYMT] As [Trans.Pymt Method]
, [DEPP] As [Trans.Deposit Paid Amt]
, [DPMT] As [Trans.Deposit Pymt Method]
 
, [Contact] As [Trans.Contact]
, Transactions.[ContactPhone] As [Trans.Contact Phone]
, [OrderedBy] As [Trans.OrderedBy]
 
 
, (IIF([Delvr] = 1, 'YES', 'NO')) as [Trans.Delivery Contract]
, (IIF([DeliveryConfirmed] = 1, 'YES','NO')) as [Trans.Delivered]
, [DeliveryDatePromised] As [Trans.Promised Delivery Date]
, [DeliveryDate] As [Trans.Actual Delivery Date]
, [DeliveryTruckNumber]  As [Trans.Delivery Truck No]
, [DeliveryTrip] As [Trans.Delivery Trip No]
, [DeliverToCompany] As [Trans.DeliveredTo]
, [DeliveryAddress] As [Trans.Delivery Address]
, [DeliveryCity] As [Trans.Delivery City]
, [DeliveryZip] As [Trans.Delivery ZipCode]
 
, (IIF([Pickup] = 1, 'YES', 'NO')) as [Trans.Pickup Contract]
, (IIF([PickupConfirmed] = 1, 'YES', 'NO')) as [Trans.Pickup Confirmed]
, [PickupDatePromised] As [Trans.Promised Pickup Date]
, [PickupDate] As [Trans.Actual Pickup Date]
, [PickupTruckNumber] As [Trans.Pickup Truck No]
, [PickupTrip] As [Trans.Pickup Trip No]
, [PickedUpBy] As [Trans.PickedUpBy]
 
, [JBPO] as [Trans.PO No]
, [JBID] as [Trans.Job Id]
, Transactions.[TransactionType] As [Trans.Type] 
, TransactionType.TypeName As [Trans.Type Desc]
 
 
 
, [ItemPercentage]
, [Modification]
, [Operation] As [Trans.Operation]
, TransactionOperation.[OperationName] As [Trans.Operation Desc]
 
, [CustomerFile].[Key]
, CustomerFile.[Name] as [Trans.Customer Name]
, [CustomerFile].[Address] as [Trans.Customer Address]
, CustomerFile.[City] as [Trans.Customer City]
, CustomerFile.[Zip] as [Trans.Customer ZipCode]
, CustomerFile.[Phone] as [Trans.Customer Phone]
, CustomerFile.[Salesman] as [Trans.Customer Salesman]
, Salesman.[Number] As [Salesman]
, Salesman.[Name] As [Trans.Salesman Name]
 
, [JobSite] as [Trans.Jobsite] 
, CustomerJobSite.[Description] as [Trans.Jobsite Desc]
, CustomerJobSite.[SiteCity] as [Trans.Jobsite City]
, CustomerJobSite.[Salesman] as [Trans.Jobsite Salesman]
, 0 as [History]  
FROM (((Salesman 
RIGHT JOIN 
(CustomerFile 
RIGHT JOIN Transactions 
ON CustomerFile.CNUM = Transactions.CUSN) 
ON Salesman.Number = Transactions.Salesman) 
LEFT JOIN CustomerJobSite  
ON Transactions.JobSite = CustomerJobSite.Number) 
LEFT JOIN TransactionOperation 
ON Transactions.Operation = TransactionOperation.OperationNumber) 
LEFT JOIN TransactionType 
ON Transactions.TransactionType = TransactionType.TypeNumber  
UNION  
SELECT DISTINCT 
TransHistory.[CNTR] as [Trans.Contract No]
, [STR] as [Trans.Store No]
, [CUSN] as [Trans.Customer No]
, [STAT] as [Trans.Status]
 
 
, [DATE] as [Trans.Contract Date]
, [TIME] as [Trans.Contract Time]
, [EventEndDate] as [Trans.Event End Date]
, [CMDT] As [Trans.Last Modified Date]
, [CLDT] As [Trans.Close Date]
, [Billed] As [Trans.Billed Date]
, [Completed] As [Trans.Completed Date]
 
, [Rent] As [Trans.Rent Amt]
, [Sale] As [Trans.Sale Amt]
, [Tax] As [Trans.Tax Amt]
, [Dmg] As [Trans.Dmg Wvr Amt]
, [TOTL] As [Trans.Total]
, [PAID] As [Trans.Total Paid]
, [TOTL]-[PAID] AS [Trans.Total Owed]
, [PYMT] As [Trans.Pymt Method]
, [DEPP] As [Trans.Deposit Paid Amt]
, [DPMT] As [Trans.Deposit Pymt Method]
 
, [Contact] As [Trans.Contact]
, TransHistory.[ContactPhone] As [Trans.Contact Phone]
, [OrderedBy] As [Trans.OrderedBy]
 
 
, (IIF([Delvr] = 1, 'YES', 'NO')) as [Trans.Delivery Contract]
, (IIF([DeliveryConfirmed] = 1, 'YES','NO')) as [Trans.Delivered]
, [DeliveryDatePromised] As [Trans.Promised Delivery Date]
, [DeliveryDate] As [Trans.Actual Delivery Date]
, [DeliveryTruckNumber]  As [Trans.Delivery Truck No]
, [DeliveryTrip] As [Trans.Delivery Trip No]
, [DeliverToCompany] As [Trans.DeliveredTo]
, [DeliveryAddress] As [Trans.Delivery Address]
, [DeliveryCity] As [Trans.Delivery City]
, [DeliveryZip] As [Trans.Delivery ZipCode]
 
, (IIF([Pickup] = 1, 'YES', 'NO')) as [Trans.Pickup Contract]
, (IIF([PickupConfirmed] = 1, 'YES', 'NO')) as [Trans.Pickup Confirmed]
, [PickupDatePromised] As [Trans.Promised Pickup Date]
, [PickupDate] As [Trans.Actual Pickup Date]
, [PickupTruckNumber] As [Trans.Pickup Truck No]
, [PickupTrip] As [Trans.Pickup Trip No]
, [PickedUpBy] As [Trans.PickedUpBy]
 
, [JBPO] as [Trans.PO No]
, [JBID] as [Trans.Job Id]
, TransHistory.[TransactionType] As [Trans.Type] 
, TransactionType.TypeName As [Trans.Type Desc]
 
 
 
, [ItemPercentage]
, [Modification]
, [Operation] As [Trans.Operation]
, TransactionOperation.[OperationName] As [Trans.Operation Desc]
 
, [CustomerFile].[Key]
, CustomerFile.[Name] as [Trans.Customer Name]
, [CustomerFile].[Address] as [Trans.Customer Address]
, CustomerFile.[City] as [Trans.Customer City]
, CustomerFile.[Zip] as [Trans.Customer ZipCode]
, CustomerFile.[Phone] as [Trans.Customer Phone]
, CustomerFile.[Salesman] as [Trans.Customer Salesman]
, Salesman.[Number] As [Salesman]
, Salesman.[Name] As [Trans.Salesman Name]
 
, [JobSite] as [Trans.Jobsite] 
, CustomerJobSite.[Description] as [Trans.Jobsite Desc]
, CustomerJobSite.[SiteCity] as [Trans.Jobsite City]
, CustomerJobSite.[Salesman] as [Trans.Jobsite Salesman]
, 1 as [History]  
FROM (((Salesman 
RIGHT JOIN 
(CustomerFile 
RIGHT JOIN TransHistory 
ON CustomerFile.CNUM = TransHistory.CUSN) 
ON Salesman.Number = TransHistory.Salesman) 
LEFT JOIN CustomerJobSite  
ON TransHistory.JobSite = CustomerJobSite.Number) 
LEFT JOIN TransactionOperation 
ON TransHistory.Operation = TransactionOperation.OperationNumber) 
LEFT JOIN TransactionType 
ON TransHistory.TransactionType = TransactionType.TypeNumber



go

