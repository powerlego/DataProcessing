
CREATE PROCEDURE [dbo].[spAT_QueueExternalPayment]
(
 @pisContractNumber VarChar(12)
,@pisCustomerKey VarChar(12)
,@picPmtAmount Decimal(12,2)
,@pidPmtDate DateTime
,@pilPmtDetailId Int
,@pilPmtSplitId Int
,@pisPmtHeaderId VarChar(255)
,@pilStoreId Int
,@pilSourceTypeId Int
,@pisSourceRef VarChar(12)
,@pisPaymentMethod VarChar(12)
,@pilBatchId Int
,@pinExchangeRate decimal(8,4)
,@pisMemo VarChar(255)
,@pisAccountSystem VarChar(255)
,@polId Int OUTPUT -- new pk
,@posErrorMsg varchar(512) OUTPUT -- any user / server error
,@posCustomerNumber VarChar(12) OUTPUT
) 
-- WITH ENCRYPTION
AS
SET NOCOUNT ON
DECLARE @lErrorNo int
DECLARE @Store varchar(3)
DECLARE @TransCodeId int = 0
DECLARE @PmtTxidAlreadyPosted int = 0
DECLARE @PmtTxidAlreadyQueued_Inbound int = 0
DECLARE @PmtTxidAlreadyQueued_Outbound int = 0
DECLARE @AccountingLink VarChar(255) = ''
DECLARE @CustomerCNUM VarChar(255) = ''


IF (@pilSourceTypeId = 2 Or @pilSourceTypeId = 42)
BEGIN
	SET @TransCodeId = 42 -- Credit Applied
	SET @pisMemo = 'Credit applied from ' + @pisSourceRef
END
ELSE
BEGIN
	SET @TransCodeId = 10 -- Payment Applied
END

	Set @AccountingLink = RTRIM(LTRIM(ISNULL(@pisPmtHeaderId,''))) + '_' + RTRIM(LTRIM(ISNULL(@pilPmtSplitId,''))) + '_' + RTRIM(LTRIM(ISNULL(@pilPmtDetailId,'')))

	-- Don't allow the same payment/credit to be posted to the same contract number more than once
	SET @PmtTxidAlreadyPosted = (SELECT COUNT(Payment) 
								   FROM PaymentDetail 
								  WHERE AccountingLink = @AccountingLink 
								    AND [Contract] = @pisContractNumber)

	-- Don't allow the same payment/credit to be queued for the same contract number more than once
	SET @PmtTxidAlreadyQueued_Inbound = (SELECT COUNT(Id) 
										   FROM AccountingAPIQueueTr 
										  WHERE TransCodeId = @TransCodeId 
										    AND Direction = 0 
											AND AccountingLink = @AccountingLink 
											AND ExternalId = @pilPmtDetailId
											AND DateCancelled IS NULL)

	SET @PmtTxidAlreadyQueued_Outbound = (SELECT COUNT(Id) 
											FROM AccountingAPIQueueTr 
										   WHERE (TransCodeId = @TransCodeId OR TransCodeId in (10,13)) 
										     AND Direction = 1 
											 AND ExternalId = @pisPmtHeaderId
											 AND DateCancelled IS NULL)

SET @polId = -1

If (@PmtTxidAlreadyPosted = 0 And @PmtTxidAlreadyQueued_Inbound = 0 And @PmtTxidAlreadyQueued_Outbound = 0)
BEGIN
	SET @Store = REPLICATE('0',3-LEN(RTRIM(Cast(@pilStoreId as varchar(3))))) + RTRIM(Cast(@pilStoreId as varchar(3)))

	SET @CustomerCNUM = (Select Transactions.CUSN
							From Transactions
							WHERE Transactions.CNTR = @pisContractNumber)

	SET @CustomerCNUM = ISNULL(@CustomerCNUM,'')

	Insert Into AccountingAPIQueueTR
		(ExportFormatId,Batch,Store,ContractNumber,CustomerNumber,TransCodeId,TransDate,TransAmount,	
		 TotalAmount,PaidAmount,RentAmount,SaleAmount,TaxAmount,DamageWaiverAmount,OtherAmount,	
		 TransMemo,	TransClass,	AccountNumber,	OffsetAccountNumber,	ExternalInvoiceId,	CustomerPONumber,	
		 ExchangeRate, Direction,	GLTransactionGroupId,	DateQueued,	DateApproved,	
		 DatePosted,DateCancelled,DateError,ErrorCode,ErrorMsg,RetryCount,CreatedBy,DateCreated,ChangedBy,DateChanged,
		 ChangeNote,NoExport,KeyValue,DateExported,AccountingLink,ExternalId)
	Values
		(1015,	@pilBatchId, @Store,@pisContractNumber,@CustomerCNUM,@TransCodeId,@pidPmtDate,@picPmtAmount,
		 0.00,0.00,0.00,0.00,0.00,0.00,0.00,
		 @pisMemo,NULL,'','',NULL,NULL,
		 @pinExchangeRate,0,0,GetDate(),GetDate(),
		 NULL,NULL,NULL,NULL,NULL,0,0,GetDate(),0,GetDate(),
		 'spTHA19QueueExternalPayment',1,@pisSourceRef,NULL,@AccountingLink,@pilPmtDetailId)

	SET @polId = (Select scope_identity())
	SET @posCustomerNumber = @CustomerCNUM

	if (@pisSourceRef = 'CutOver')
	BEGIN
		Update AccountingAPIQueueTr
		   Set DatePosted = GetDate()
		 Where Id = @polId
	END
	ELSE
	BEGIN
		DECLARE @Valid Int = 0
		SET @Valid = (Select Count(CNTR) From Transactions Where CNTR = @pisContractNumber And CUSN = @CustomerCNUM)
		IF (ISNULL(@Valid,0) = 0)
		BEGIN
			Update AccountingAPIQueueTr
			   Set DateCancelled = GetDate()
			 Where Id = @polId
		END
	END
END

RETURN


go

grant execute on spAT_QueueExternalPayment to PORUser
go

