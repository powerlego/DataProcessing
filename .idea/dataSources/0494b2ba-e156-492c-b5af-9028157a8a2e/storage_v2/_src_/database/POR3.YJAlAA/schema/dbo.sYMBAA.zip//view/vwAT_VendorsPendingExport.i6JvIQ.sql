
CREATE VIEW [dbo].[vwAT_VendorsPendingExport] 
--WITH ENCRYPTION 
AS
SELECT
 vq.AccountingAPIQueueVendorId		AS SUP_ID
,rtrim(ltrim(vq.VendorNumber))		AS SUP_ACCOUNT_NUMBER
,vq.VendorName						AS SUP_NAME
,ISNULL(tx.AccountingLink,'')		AS SUP_TAX_CODE
,''									AS SUP_VAT_NUMBER
,ISNULL(vf.Contact1Email,'')		AS SUP_EMAIL_ID
,ISNULL(vf.WebAddress,'')			AS SUP_WEB_SITE_URL
,ISNULL(vq.VendorAddress1,'')		AS ADR_LINE1
,ISNULL(vq.VendorAddress2,'')		AS ADR_LINE2
,''									AS ADR_LINE3
,ISNULL(vq.VendorCityState,'')		AS ADR_TOWN
,''									AS ADR_COUNTY
,ISNULL(vq.VendorZip,'')			AS ADR_POSTCODE
,ISNULL(vq.VendorPhone,'')			AS ADR_TELEPHONE
,ISNULL(vq.VendorFax,'')			AS ADR_FAX
,''									AS COU_ACCOUNTS_COUNTRY_CODE
,''									AS COU_NAME
,ISNULL(ce.AccountingLink,'')	AS CUR_ACCOUNTS_CURRENCY_CODE
,CAST(NULL AS Varchar(60))			AS ACCOUNTS_CODE_1
,CAST(NULL AS Varchar(60))			AS ACCOUNTS_CODE_2
,ISNULL(vq.VendorContact1,'')		AS ContactName
,0									AS BUS_AREA_ID
FROM AccountingAPIQueueVendor vq
INNER JOIN VendorFile vf ON vf.VendorNumber = vq.VendorNumber
LEFT OUTER JOIN CurrencyExchange ce ON ce.CurrencyNumber = vf.CurrencyNumber
LEFT OUTER JOIN [dbo].[TaxTable] AS tx ON tx.TaxCode = vf.TaxCode
WHERE vq.DateApproved IS NOT NULL
  AND vq.DatePosted IS NULL
  AND vq.DateCancelled IS NULL
  AND vq.RetryCount <= 10

go

grant select on vwAT_VendorsPendingExport to PORUser
go

