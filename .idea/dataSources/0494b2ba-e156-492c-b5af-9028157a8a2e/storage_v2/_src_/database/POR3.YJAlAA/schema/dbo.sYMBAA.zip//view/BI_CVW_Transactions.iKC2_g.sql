-- SQL Deploy  3/29/2018 8:38 AM
CREATE VIEW [dbo].[BI_CVW_Transactions]
 
AS
SELECT 
T.[CNTR] AS [Contract No]
,T.[STR] AS [Store No]
,T.[CUSN] AS [Customer No]
,T.[STAT] as [Stat]
,CASE
WHEN T.STAT like 'O%' THEN 'Open'
WHEN T.STAT like '%C%'THEN 'Closed'
WHEN T.STAT like 'D%' THEN 'Completed'
WHEN T.STAT like 'W%' THEN 'Work Order'
WHEN T.STAT like 'R%' THEN 'Reservation'
WHEN T.STAT like 'Q%' THEN 'Quote'
WHEN T.STAT like 'A%' THEN 'Adjustment'
WHEN T.STAT like 'F%' THEN 'Finance Charge'
WHEN T.STAT like 'T%' THEN 'Transfered'
WHEN T.STAT ='' THEN 'Completed'
ELSE 'UNKNOWN'
END AS [Status]
,T. [DATE] AS [Contract Date]
,T. [TIME] AS [Contract Time]
,T. [CMDT] AS [Last Modified Date]
,T. [CLDT] AS [Close Date]
,T. [Billed] AS [Billed Date]
,T. [Completed] AS [Completed Date]
,T. [Rent] AS [Rent Amt]
,T. [Sale] AS [Sale Amt]
,T. [Tax] AS [Tax Amt]
,T. [Dmg] AS [Dmg Wvr Amt]
,T. [TOTL] AS [Total]
,T. [PAID] AS [Total Paid]
 
,PM. [PayType] AS [PaymentMethod]
,T. [TOTL]-[PAID] AS [Total Owed]
,T. [DEPP] As [Deposit Paid Amt]
,T. [Contact] As [Contact]
,T. [ContactPhone] As [Contact Phone]
,T. [OrderedBy] As [OrderedBy]
,T. [DeliveryDatePromised] As [Promised Delivery Date]
,T. [DeliveryDate] As [Actual Delivery Date]
,T. [DeliveryTruckNumber]  As [Delivery Truck No]
,T. [DeliveryTrip] As [Delivery Trip No]
,T. [DeliverToCompany] As [DeliveredTo]
,T. [DeliveryAddress] As [Delivery Address]
,T. [DeliveryCity] As [Delivery City]
,T. [DeliveryZip] As [Delivery ZipCode]
,T. [PickupDatePromised] As [Promised Pickup Date]
,T. [PickupDate] As [Actual Pickup Date]
,T. [PickupTruckNumber] As [Pickup Truck No]
,T. [PickupTrip] As [Pickup Trip No]
,T. [PickedUpBy] As [PickedUpBy]
,T. [JBPO] as [Job PO]
,T. [JBID] as [Job Id]
 
,TT.[TypeName] As [Type]
FROM Transactions T
LEFT JOIN PaymentMethod PM ON T.PYMT=PM.PayMeth
LEFT JOIN TransactionType TT ON T.TransactionType=TT.TypeNumber
UNION
SELECT 
T.[CNTR] AS [Contract No]
,T.[STR] AS [Store No]
,T.[CUSN] AS [Customer No]
,T.[STAT] as [Stat]
,CASE
WHEN T.STAT like 'O%' THEN 'Open'
WHEN T.STAT like 'C%' THEN 'Closed'
WHEN T.STAT like 'D%' THEN 'Completed'
WHEN T.STAT like 'W%' THEN 'Work Order'
WHEN T.STAT like 'R%' THEN 'Reservation'
WHEN T.STAT like 'Q%' THEN 'Quote'
WHEN T.STAT like 'A%' THEN 'Adjustment'
WHEN T.STAT like 'F%' THEN 'Finance Charge'
WHEN T.STAT ='' THEN 'Completed'
ELSE 'UNKNOWN'
END AS [Status]
,T. [DATE] AS [Contract Date]
,T. [TIME] AS [Contract Time]
,T. [CMDT] AS [Last Modified Date]
,T. [CLDT] AS [Close Date]
,T. [Billed] AS [Billed Date]
,T. [Completed] AS [Completed Date]
,T. [Rent] AS [Rent Amt]
,T. [Sale] AS [Sale Amt]
,T. [Tax] AS [Tax Amt]
,T. [Dmg] AS [Dmg Wvr Amt]
,T. [TOTL] AS [Total]
,T. [PAID] AS [Total Paid]
 
,PM. [PayType] AS [PaymentMethod]
,T. [TOTL]-[PAID] AS [Total Owed]
,T. [DEPP] As [Deposit Paid Amt]
,T. [Contact] As [Contact]
,T. [ContactPhone] As [Contact Phone]
,T. [OrderedBy] As [OrderedBy]
,T. [DeliveryDatePromised] As [Promised Delivery Date]
,T. [DeliveryDate] As [Actual Delivery Date]
,T. [DeliveryTruckNumber]  As [Delivery Truck No]
,T. [DeliveryTrip] As [Delivery Trip No]
,T. [DeliverToCompany] As [DeliveredTo]
,T. [DeliveryAddress] As [Delivery Address]
,T. [DeliveryCity] As [Delivery City]
,T. [DeliveryZip] As [Delivery ZipCode]
,T. [PickupDatePromised] As [Promised Pickup Date]
,T. [PickupDate] As [Actual Pickup Date]
,T. [PickupTruckNumber] As [Pickup Truck No]
,T. [PickupTrip] As [Pickup Trip No]
,T. [PickedUpBy] As [PickedUpBy]
,T. [JBPO] as [Job PO]
,T. [JBID] as [Job Id]
 
,TT.[TypeName] As [Type]
FROM TransHistory T
LEFT JOIN PaymentMethod PM ON T.PYMT=PM.PayMeth
LEFT JOIN TransactionType TT ON T.TransactionType=TT.TypeNumber

go

