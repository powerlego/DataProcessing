
CREATE PROCEDURE [dbo].[spAT_UpdateExternalPaymentAsPosted](
 @pilId Int
,@pisAccountingLink varchar(255)
,@posErrorMsg varchar(512) output
) 
-- WITH ENCRYPTION
AS
SET NOCOUNT ON
DECLARE @lErrorNo int, @PaymentNumber int = 0
SET @posErrorMsg = NULL

-- Make sure there's a payment detail row for the accounting link
SET @PaymentNumber = (SELECT TOP 1 Payment FROM PaymentDetail WHERE AccountingLink = @pisAccountingLink)

IF (ISNULL(@PaymentNumber,0) > 0)
BEGIN
	UPDATE dbo.AccountingAPIQueueTr
	SET    DatePosted = GetDate()
		  ,DateCancelled = NULL
		  ,DateError = NULL
		  ,ErrorMsg = NULL
		  ,DateChanged = GETDATE()
	WHERE  Id = @pilId
END
ELSE
	SET @posErrorMsg = 'Payment link was not found ' + ISNULL(@pisAccountingLink,'')
	Exec spAT_UpdateExportedRecordAsFailed @pilId, 'PMT', @pilId, @posErrorMsg, NULL, @posErrorMsg
RETURN

go

grant execute on spAT_UpdateExternalPaymentAsPosted to PORUser
go

