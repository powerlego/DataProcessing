
CREATE PROCEDURE DBO.spRebuildLocksTable
(
	@sViewName			VARCHAR(500)
)

AS

/*****************************************************************************************/
--	POR.DBO.spRebuildLocksTable
--		Trucates and reloads Locks table  
--
--	PARAMETERS: none
--
--	HISTORY:	11/19/2014	JY	CREATED	--
--
--
/*****************************************************************************************/

BEGIN

	DECLARE @ssql	VARCHAR(600)

	IF (object_id('POR.DBO.tempLocks') > 0)
	BEGIN
		DROP TABLE POR.DBO.tempLocks
	END

	SELECT *
	  INTO #tmp_Locks
	  FROM LOCKS

	TRUNCATE TABLE LOCKS

	INSERT INTO LOCKS
	SELECT * FROM #tmp_Locks

	DROP TABLE #tmp_Locks

END

go

