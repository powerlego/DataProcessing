-- SQL Deploy  3/29/2018 8:38 AM
CREATE VIEW [dbo].[BI_CVW_Customers]
 
AS
SELECT C.[KEY] as [Key]
,C.[CNUM] as [CNUM]
,C.[NAME] as [Name]
,C.[Address] as [Address]
,C.[Address2] as [Address2]
,C.[CITY] as [City]
,C.[ZIP] as [Zip]
,C.[ZIP4] as [Zip4]
,C.[DriversLicense] as [DriversLicense]
,C.[Birthdate] as [Birthdate]
,C.[Employer] as [Employer]
,C.[AutoLicense] as [Auto License]
,C.[AutoState] as [Auto State]
,C.[Phone] as [Phone]
,C.[WORK] as [Work Phone]
,C.[MOBILE] as [Mobile Phone]
,C.[FAX] as [Fax]
,C.[OpenDate] as [Open Date]
,C.[LastActive] as [Last Active Date]
,C.[LastContract] as [Last Contract]
,C.[CreditLimit] as [Credit Limit]
 
,CASE
WHEN C.STATUS = 'D' THEN 'Cash'
WHEN C.STATUS = 'H' THEN 'Cash Only'
WHEN C.STATUS = 'E' THEN 'Any Method'
ELSE 'UNKNOWN'
END AS [Status Desc]
 
,CASE
WHEN C.[Restrictions] = 'K' THEN 'No Checks,'
WHEN C.[Restrictions] = 'D' THEN 'Waive deposits.� No restrictions.'
WHEN C.[Restrictions] = 'R' THEN 'Pay-on-return, waive deposit, do not collect payment up-front.'
WHEN C.[Restrictions] = 'O' THEN 'Collect payment up front.'
WHEN C.[Restrictions] = 'S' THEN 'Sale customer.� No rent.'
WHEN C.[Restrictions] = 'U' THEN 'Undesirable.� No rent/sale.'
WHEN C.[Restrictions] = 'W' THEN 'Wanted person.� Notify owner or police.� No rent/sale.'
WHEN C.[Restrictions] = 'C' THEN 'Account Closed.'
WHEN C.[Restrictions] = 'H' THEN 'Account put on hold waiting for payment.� Must have the�Manager or Owner�s level password to rent.'
WHEN C.[Restrictions] = '3' THEN 'Can be up to 60 days overdue without requiring password'
WHEN C.[Restrictions] = '6' THEN 'Can be up to 90 days overdue without requiring password'
WHEN C.[Restrictions] = '9' THEN 'Can be up to 120 days overdue without requiring password'
WHEN C.[Restrictions] = 'N' THEN 'Can be any days overdue without requiring password'
ELSE 'None - Collect normal deposits.� No restrictions.'
END AS [Restriction Desc]
,C.[CreditCard] as [CreditCard]
,C.[IncomeYear]  as [YTD Payments]
,C.[IncomeLife] as [LTD Payments]
,C.[IncomeLastYear] as [Last Year Payments]
,C.[NumberContracts] as [No of Contracts]
,C.[TaxCode] as [TaxCode]
,C.[Discount] as [Discount]
,ISNULL(DT.Disc_Desc,'') as [Discount Desc]
,ISNULL(DT.Rent_Disc,'0') as [Rental Discount %]
,ISNULL(DT.Sale_Disc,'0') as [Sales Discount %]
 
,ISNULL(CT.[Description],'') as [Type Desc]
,C.[QtyOut] as [Qty Out]
,C.[LastPayAmount] as [LastPayAmt]
,C.[LastPayDate] as [LastPayDate]
,C.[HighBalance] as [HighBalance]
,C.[CurrentBalance] as [CurrentBalance]
,C.[Email]  as [Email]
 
,ISNULL(S.Name,'') as [Salesman Name]
,ISNULL(S.Email,'') as [Salesman Email]
,ISNULL(S.CellPhone,'') as [Salesman Phone]
,ISNULL(S.Inactive,'') as [Salesman Inactive]
,C.[DLExpire] as [DL Expire]
,C.[BillContact] as [Billing Contact]
,C.[BillPhone] as [Billing Phone]
,C.[BillAddress1] as [Billing Address1]
,C.[BillAddress2] as [Billing Address2]
,C.[BillCityState] as [Billing CityState]
,C.[BillZip] as [Billing Zip]
,C.[BillZip4] as [Billing Zip4]
,C.[TaxId] as [TaxID]
,C.[TaxExemptNumber] as [TaxExemptNo]
,C.[TaxExemptExpire] as [TaxExemptExpire]
,C.[InsuranceNumber] as [InsuranceNo]
,C.[InsuranceExpire] as [InsuranceExpDate]
,C.[Terms] as [Terms]
,C.[FinanceChargeDays] as [FinanceChargeDays]
,C.[PriceLevel] as [PriceLevel]
,C.[AgeDate] as [ContractAgeDate]
 
, ISNULL(CH.HeardName, '') as [HeardName]
FROM [dbo].[CustomerFile] C
LEFT JOIN [dbo].[CustomerType] CT ON C.Type = CT.Type
LEFT JOIN [dbo].[Salesman] S ON C.Salesman = S.Number
LEFT JOIN [dbo].[DiscountTable] DT ON C.Discount = DT.CODE
LEFT JOIN [dbo].[CustomerHeard] CH ON C.HeardAboutUs = CH.HeardNumber

go

