
CREATE TRIGGER TR_Transactions_AfterInsert_SyncClassId ON [Transactions]
AFTER INSERT 
AS  
IF (ROWCOUNT_BIG() = 0)
RETURN;
BEGIN  
	
	SET NOCOUNT ON; -- SET NOCOUNT ON added to prevent extra result sets from interfering

	DECLARE @NewValue int
	DECLARE @CurrentValue int
	DECLARE @Contract nvarchar(10) 
	
	BEGIN TRY
		SELECT @Contract = [inserted].[cntr] From [inserted]--Get the record in question
		SELECT @CurrentValue = [inserted].[classid] From [inserted]--Get the current value in question

		--Define what the class is, All fully numeric or q contracts are 0, everything else has a value
		SELECT @NewValue =  CASE 
				 WHEN IsNumeric(RIGHT([inserted].[cntr],1))=0 THEN 1
				 WHEN LEFT([inserted].[cntr],1) = 'r' AND CustomerFile.[Key] IS NULL THEN 2
				 WHEN CustomerFile.[Key] like 'REPAIRS-MAINT%' THEN 3
				 WHEN  CustomerFile.[Key] like 'REPAIRS-SERV%' THEN 4
				 WHEN  LEFT([inserted].[cntr],1) = 'r' THEN 2
				 WHEN  LEFT([inserted].[cntr],1) = 'w' THEN 5
				 WHEN  LEFT([inserted].[cntr],1) = 't' AND CustomerFile.[Key] IS NULL  THEN 6
				 WHEN  LEFT([inserted].[cntr],1) = 't' AND IsNumeric(LEFT(CustomerFile.[Key],1))=1 THEN 7
				 WHEN  LEFT([inserted].[cntr],1) = 't' THEN 6
				 WHEN  LEFT([inserted].[cntr],1) = 'L' THEN 8
				 WHEN  LEFT([inserted].[cntr],1) = 's' THEN 9
				 WHEN  LEFT([inserted].[cntr],1) = 'f' THEN 10
				 WHEN  LEFT([inserted].[cntr],1) = 'c' THEN 11
				 ELSE 0 
				 END 
				 FROM [inserted] LEFT JOIN CustomerFile On [inserted].cusn = CustomerFile.cnum 

			IF (@CurrentValue = @NewValue) 
				SET NOCOUNT OFF; -- Clear our override
			ELSE
				UPDATE [Transactions]
				SET ClassId = @NewValue
				Where [Transactions].Cntr = @Contract; --fix the column value
	END TRY
	BEGIN CATCH
		SET NOCOUNT OFF;-- Clear our override
	END CATCH;
END;
go

