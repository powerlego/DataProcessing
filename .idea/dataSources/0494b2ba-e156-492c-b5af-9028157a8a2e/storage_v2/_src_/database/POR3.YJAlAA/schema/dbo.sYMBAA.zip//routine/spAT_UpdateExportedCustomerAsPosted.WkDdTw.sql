
CREATE PROCEDURE [dbo].[spAT_UpdateExportedCustomerAsPosted](
 @pilAxpId int 
,@pisType varchar(4)
,@pilObjId int
,@pilBusAreaId Int
,@posErrorMsg varchar(512) OUTPUT -- any user / server error
) 
--WITH ENCRYPTION 
AS

SET NOCOUNT ON
SET @posErrorMsg = NULL
DECLARE @lErrorNo Int

IF @pisType = 'CUST'
BEGIN
 

   DECLARE @bUpdateCust Bit,
		   @AccountingCustomerId Int,
		   @CustomerNumber VarChar(12),
		   @AccountingLink VarChar(25),
		   @CustomerKey	VarChar(25)

  UPDATE dbo.AccountingAPIQueueCustomer
     SET DatePosted = GetDate(),
		 DateChanged = GetDate()
   WHERE id = @pilObjId

   SELECT @AccountingCustomerId = ISNULL(cf.AccountingCustomerId,0),
		  @CustomerNumber = RTRIM(LTRIM(cf.CNUM)),
		  @CustomerKey = Rtrim(Ltrim(cf.[Key]))
	 FROM CustomerFile cf
	INNER JOIN AccountingAPIQueueCustomer aqc on aqc.CustomerNumber = cf.CNUM
	WHERE aqc.Id = @pilObjId

   IF (@AccountingCustomerId = 0)
   BEGIN
		INSERT INTO AccountingCustomer (AccountingLink, [Disabled])
							  VALUES (@CustomerNumber, 0)

		SELECT @AccountingCustomerId = SCOPE_IDENTITY()
		SELECT @AccountingLink = @CustomerNumber

		UPDATE CustomerFile
		   SET AccountingCustomerId = @AccountingCustomerId
		  FROM AccountingAPIQueueCustomer 
		 WHERE AccountingAPIQueueCustomer.CustomerNumber = CustomerFile.CNUM
		   AND AccountingAPIQueueCustomer.id = @pilObjId

   END
   ELSE
   BEGIN
		SET @AccountingLink = (SELECT ac.AccountingLink
								 FROM AccountingCustomer ac
								INNER JOIN CustomerFile cf on cf.AccountingCustomerId = ac.id
								INNER JOIN AccountingAPIQueueCustomer aqc ON aqc.CustomerNumber = cf.CNUM
								WHERE aqc.id = @pilObjId)
	END

   	UPDATE AccountingAPIQueueCustomer
		SET AccountingLink = @AccountingLink
	    WHERE id = @pilObjId

END

RETURN

go

grant execute on spAT_UpdateExportedCustomerAsPosted to PORUser
go

