
CREATE PROCEDURE [dbo].[TEST_spItemAvailability_Overbooked]

--===============================================================================================
--TODO "TEST...Overbooked"  -- Commented out code - fix output -- MM 12/22/2016
--===============================================================================================

	@WidgetDataFilter KeyValuePair READONLY, -- pass parameters via Table Type Param
	
	@ItemKey				VarChar(20) = Null,
	@StoreTransferCustomer	VarChar(max) = Null,
	@IROonly				Bit = 0,
	@LandingPageOnly		Bit = 1

AS

/*****************************************************************************************/
--	POR.DBO.spItemAvailability
--		Computes Max Qty Out and Min Qty Available for a given date, date range, or spanning all reservations
--		
--
--	PARAMETERS: @ItemKey					(Varchar(20))	Optional	Ex. 'CHAIRBW'
--				@StoreNo				(Varchar( ))	Optional	Ex. '001'; or '001,002,003'; or Null
--				@StoreTransferCustomer		(Varchar( ))	Optional	Ex. '12345'; or Null
--				@StartDate					(DateTime)		Optional	Ex. '01/01/2016'; or Null for current date
--				@EndDate					(DateTime)		Optional	Ex. '01/01/2016'; or Null for current date
--				@IROonly					(Bit)			Optional	Ex. '1, include only items currently on IRO
--				@LandingPageOnly			(Bit)			Optional	Ex. 1, Returns results formatted for the landing page
--				@ItemNo					(Varchar(6))	Optional	Ex. '12345', option to use Item Number rather than Item Key
--
--	HISTORY:	05/03/2016	JY	CREATED	--
--				08/04/2016  JY	Add option to return results formatted for landing page
--				09/14/2016  JY  Add Item Number parameter and add item number to results returned
--
--
--  1) Derive Item selection criteria
--  2) Derive Store selection criteria
--  3) Get reservation data

/*****************************************************************************************/

BEGIN
	Set Nocount On
	
	Declare @StoreNo nvarchar(20) = null;
	Set @StoreNo	= (SELECT	SUBSTRING([Value], 1, 20)	FROM @WidgetDataFilter WHERE [Key] = 'StoreNo');
				
	Declare @ItemNo nvarchar(6) = null; -- //NUM
	Set @ItemNo		= (SELECT	SUBSTRING([Value], 1, 6)	FROM @WidgetDataFilter WHERE [Key] = 'ItemNo');
		
	Declare @StartDate datetime = null;
	Set @StartDate	= (SELECT	CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'StartDate');

	Declare @EndDate datetime = null;
	Set @EndDate	= (SELECT	CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'EndDate');

	Declare @StoreNumber	Varchar(3),
			@QtyOwned		Numeric(13,2),
			@QtyOut			Numeric(13,2),
			@AllStores		TinyInt,
			@Today			DateTime,
			@TodayEOD		DateTime

-- @Today = start of current date
Set @Today = Cast(Substring(Convert(varchar,Getdate(),101),1,10) as DateTime)
-- @TodayEOD = end of current date (11:59.59 PM)
Set @TodayEOD = Cast(Substring(Convert(Varchar,Getdate(),101),1,10) + ' 23:59:59' as DateTime)
			
/**************************************************************/
	-- Valid date range 
/**************************************************************/
	Set @StartDate = IsNull(@StartDate,GetDate())
	Set @EndDate = IsNull(@EndDate,GetDate()+7)

	-- Begin date can't be after End date
	If (@StartDate > @EndDate)
		Set @StartDate = @EndDate

	-- Begin date starts at 00:00:00
	set @StartDate = cast(substring(convert(varchar,@StartDate,101),1,10) as datetime)
	-- End date ends at 23:59:59
	set @EndDate = cast(substring(convert(varchar,@EndDate,101),1,10) + ' 23:59:59' as datetime)

/**************************************************************/
	-- Set targeted stores
/**************************************************************/

	/*
	        ' get the store selection criteria
        Dim StoreWhereClause As String = ""
        ' allow store groups
        If StoreNumber = "000" Or StoreNumber = "0" Or StoreNumber = "" Then
            StoreWhereClause = ""
        ElseIf StoreNumber.IndexOf(","c) >= 0 Then
            StoreWhereClause = " AND ItemFile.CurrentStore IN (" & StoreNumber & ") "
        Else
            StoreWhereClause = " AND ItemFile.CurrentStore = '" & StoreNumber & "'  "
        End If

	*/


	Set @AllStores = 0
	Create Table #tmp_Stores (StoreNumber varchar(3), RateCode Int Null)

	If (CharIndex(',',IsNull(@StoreNo,'')) > 0)
	Begin
		-- Parse store number list
		Insert Into #tmp_Stores (StoreNumber)
			Select * From fnSplitString(@StoreNo,',')
	End
	Else If (isnumeric(@StoreNo) = 1 And Cast(@StoreNo as Integer) > 0)
	Begin
			-- Single Store
			Insert Into #tmp_Stores (StoreNumber)
			Values (Rtrim(Ltrim(@StoreNo)))
	End

	if (@@rowcount = 0)
	Begin
		-- All Stores
		Insert Into #tmp_Stores
		Select Store, 1
		  From ParameterFile

		Set @AllStores = 1

	End

	-- Get the rate code for the stores inserted above
	Update #tmp_Stores
		Set RateCode = IsNull(P.Def_Rate_Code,0)
		From ParameterFile P 
		Where P.Store = #tmp_Stores.StoreNumber

	
/**************************************************************/
	-- Set targeted item list
/**************************************************************/
	Create Table #tmp_Items1 (ItemKey varchar(64), Header varchar(64), ItemType varchar(12), QtyOwned Float, CurrentStore varchar(3), RateCode VarChar(1))
	Create Table #tmp_Items (ItemKey varchar(64), Header varchar(64), ItemType varchar(12), QtyOwned Float, CurrentStore varchar(3), RateCode VarChar(1))
	Create Index tmpItemsKey on #tmp_Items(ItemKey)
	Create Index tmpItemsHeader on #tmp_Items(Header)

   	-- Item Key or Number passed in
	If (IsNull(@ItemKey,'') = '' And Isnull(@ItemNo, '') <> '')
	Begin
		-- Item Number passed in.  Translate that into the Key
		Set @ItemKey = (Select [Key] From ItemFile Where ltrim(rtrim(Num)) = ltrim(rtrim(@ItemNo)))
	End		
	
	--select @itemKey, @ItemNo

	if (IsNull(@ItemKey,'') = '')
	Begin
	    -- All active items
		If (@AllStores = 0)
		Begin
			Insert Into #tmp_Items1 (ItemKey, Header, ItemType, QtyOwned, CurrentStore, RateCode)
				Select [Key], 
					   Case When (IsNull([Header],'') = '') 
							 Then [Key]
							 Else [Header] End As Header,
					   [Type], Qty, CurrentStore, RCod
				  From ItemFile
				  Join #tmp_Stores on ItemFile.CurrentStore = #tmp_Stores.StoreNumber
				 Where ItemFile.Inactive = 0 
				 -- IgnoreAvailablity
	--			   And [Type] Not In ('V','E')
		End
		Else
		Begin
			Insert Into #tmp_Items1 (ItemKey, Header, ItemType, QtyOwned, CurrentStore, RateCode)
				Select [Key], 
					   Case When (IsNull([Header],'') = '') 
							 Then [Key]
							 Else [Header] End As Header,
					   [Type], Qty, CurrentStore, RCod
				  From ItemFile
				 Where ItemFile.Inactive = 0 
				 -- IgnoreAvailablity
	--			   And [Type] Not In ('V','E')
		End
	End
	Else
	Begin
		-- Specific Item based on Key
		If (@AllStores = 0)
		Begin
			Insert Into #tmp_Items1 (ItemKey, Header, ItemType, QtyOwned, CurrentStore, RateCode)
				Select [Key], 
					   Case When (IsNull([Header],'') = '') 
							 Then [Key]
							 Else [Header] End As Header,
					   [Type], Qty, CurrentStore, Rcod
				  From ItemFile
				  Join #tmp_Stores on ItemFile.CurrentStore = #tmp_Stores.StoreNumber
				 Where ([Key] = @ItemKey
		 			or ([Header] = @ItemKey)) --And [Type] Not In ('V','E')))
		End
		Else
		Begin
			Insert Into #tmp_Items1 (ItemKey, Header, ItemType, QtyOwned, CurrentStore, RateCode)
				Select [Key], 
					   Case When (IsNull([Header],'') = '') 
							 Then [Key]
							 Else [Header] End As Header,
					   [Type], Qty, CurrentStore, Rcod
				  From ItemFile
				 Where ([Key] = @ItemKey
		 			or ([Header] = @ItemKey)) --And [Type] Not In ('V','E')))
	    End
	End

	if (@IROonly = 1)
	Begin
		-- Filter item list to only those currently on an IRO
		Insert Into #tmp_Items
			Select * from #tmp_Items1
			 Where ItemKey in (
							   Select Distinct ITF.[key]
								 From (Transactions T
								Inner join transactionitems TI on T.[cntr] = TI.[cntr])
								Inner join itemfile ITF on TI.[item] = ITF.[num]      
								Where Left(T.[cntr],1) ='r' And 
									  Left(T.[stat],1) = 'o' And 
									  TI.[txty] Not In ('rr','rx') And
									  ITF.[key] Not Like 'rep-%'
								Group By ITF.[key], T.[str] 
							  )
			   And Isnull(Header,'') = ''
		   Union
			Select * from #tmp_Items1
			 Where Header in (
							   Select Distinct ITF.[Header]
								 From (Transactions T
								Inner join transactionitems TI on T.[cntr] = TI.[cntr])
								Inner join itemfile ITF on TI.[item] = ITF.[num]      
								Where Left(T.[cntr],1) ='r' And 
									  Left(T.[stat],1) = 'o' And 
									  TI.[txty] Not In ('rr','rx') And
									  ITF.[key] Not Like 'rep-%'
								Group By ITF.[Header], T.[str] 
							  )
			   and Isnull(Header,'') <> ''
	End
	Else
	Begin
		-- Don't filter item list on IRO
		Insert Into #tmp_Items
			Select * from #tmp_Items1
	End

	--select * from #tmp_items1

	-- Summarize QtyOwned
	Create Table #tmp_ItemOwnedSummary (ItemKey varchar(64), QtyOwned Float)
	Create Index tmpItemOwnedKey on #tmp_ItemOwnedSummary(ItemKey)

--    select * from #tmp_stores
--	select * from #tmp_items left join #tmp_stores on #tmp_items.CurrentStore = #tmp_stores.StoreNumber

	Insert Into #tmp_ItemOwnedSummary (ItemKey, QtyOwned)
	Select [Header], Sum(IsNull(QtyOwned,0)) As QtyOwned
	  From #tmp_Items
	 Where ItemType Not in ('V','E')
	 Group By [Header]

--select * from #tmp_items
--select * from #tmp_itemownedsummary

/*
	-- Get Quantity Out at start of date range
	-- QUERY FROM ARASV1.GETQTYOUT

		 "SELECT Sum([TransactionItems.Qty]) AS QtyOut " & _
		  "FROM ItemFile INNER JOIN (Transactions INNER JOIN TransactionItems ON Transactions.CNTR = TransactionItems.CNTR) ON ItemFile.NUM = TransactionItems.ITEM " & _
        WHERE (Transactions.CNTR Not Like '[cq]%') AND (Transactions.STAT Not Like '[C ]%') AND (TransactionItems.Txty <> 'RR') AND (TransactionItems.Txty <> 'RX') AND (TransactionItems.Txty Not Like 'S%')

			                                           IF THE TRAN DATE/DELIVERY DATE IS BEFORE @BEGIN DATE - 1sec
		   AND (" & fnIIF("[Transactions].[Delvr],
					  [Transactions].[DeliveryDate],
					  [Date]") & " <= " & fnDateDelim() & DateTimeHelper.ToString(EndDate) & fnDateDelim() & ")
					  

					  IS ENHANCED DUE DATE ON OR AFTER BEGIN DATE
								IF OPEN AND DUE DATE IS BEFORE TODAY, ADD 6 DAYS TO CURRENT DATE
								IF OPEN AND DUE DATE NOT BEFORE TODAY, ADD CLEANING TIME TO DUE DATE 

		   AND (" & fnIIF("Left([Transactions].[Stat],1) = 'O'," & 
						fnIIF("[TransactionItems].[DDT] < " & fnNow() & "," & 
							fnDateAdd("'d',6,Now") & "," & 
							fnDateAdd("'h',[CleaningDelay]," & fnIIF("[Transactions].[Pickup],[Transactions].[PickupDate],[DDT]") & "") & "") & "," & 
						fnDateAdd("'h',[CleaningDelay]," & fnIIF("[Transactions].[Pickup],[Transactions].[PickupDate],[DDT]") & "") & "") & 
					" >= " & fnDateDelim() & DateTimeHelper.ToString(BegDate) & fnDateDelim() & ") " 
		  & ItemWhereClause
			& StoreWhereClause


		CRITERIA FROM DAVID'S REPORT
			   WHERE Left(T.STAT + ' ',1) Not In ('C',' ') AND 
                I.[Type] Not In ('D','K') AND
                Left(TXTY,1) <> 'S' AND 
                Right(Left(TI.TXTY + '   ',2),1) Not In ('S','A','R','X') AND
                Left(TI.CNTR,1) <> 'q' AND 
                                (
                (T.Delvr <> 0 AND (T.DeliveryDate) < #4/29/2016#+1) OR
                (T.Delvr = 0 AND T.[DATE] <= #4/29/2016#)
                )
*/

/**************************************************************/
	-- Get Transactions which were opened before the date range
	-- and remained open during the date range
/**************************************************************/

		Create Table #tmp_Transactions
			(RowId		Int	Identity(1,1),
			 CNTR		VARCHAR(20),
			 STAT		VARCHAR(4),
			 ITEM		VARCHAR(12),
			 QTY		Float,
			 QtyOwned	Float,
			 [Key]		VARCHAR(64),
			 Header		VARCHAR(64),
			 DateOut	DateTime,
			 DateBack	DateTime,
			 [STR]		VARCHAR(3)
			)

		Create Index tmpTransKey on #tmp_Transactions([Key])
		Create Index tmpTransHeader on #tmp_Transactions(Header)

		-- Get Transactions already open at the start of the date range
		-- ADAPTED QUERY FROM ARASV1.GETQTYOUT (above)

		Insert Into #tmp_Transactions
		Select Transactions.CNTR, Transactions.STAT, TransactionItems.ITEM, TransactionItems.QTY, 
			   ItemFile.Qty as QtyOwned, ItemFile.[Key], ItemFile.Header, 
		         IIF(Transactions.Delvr = 1,
						Transactions.DeliveryDate,
						cast(substring(convert(varchar,[date],101),1,10) + ' ' + substring([time],1,2) + ':' + substring([time],3,2) as datetime)) AS DateOut,  
		         iif(Substring([Transactions].[Stat],1,1) = 'O',
								iif([TransactionItems].[DDT] < @Today,
										dateadd(d,6,@Today),
										dateadd(hh, [CleaningDelay],iif([Transactions].[Pickup]=1,
																			[Transactions].[PickupDate],
																			[DDT]))),
								dateadd(hh,[CleaningDelay],iif([Transactions].[Pickup]=1,
																			[Transactions].[PickupDate],
																			[DDT]))) AS DateBack,
				Transactions.[STR]
				
		  From Transactions 
		  Join TransactionItems  On Transactions.CNTR = TransactionItems.CNTR
		  Join ItemFile  On ItemFile.NUM = TransactionItems.ITEM
		  Join #tmp_Items on #tmp_Items.ItemKey = ItemFile.[Key]
		 Where (Transactions.CNTR Not Like '[cq]%') 
		   And (Transactions.STAT Not Like '[C ]%') 
		   And (TransactionItems.Txty <> 'RR') 
		   And (TransactionItems.Txty <> 'RX') 
		   And (TransactionItems.Txty Not Like 'S%') 
                
			-- Items went out before date range 
			-- (Exclude transactions that went out on @StartDate)
		   And iif([Transactions].[Delvr]=1,
				[Transactions].[DeliveryDate], [Date]) < @StartDate

			-- Items will be available again on or after the start of the date range
		   
		   And iif(Substring([Transactions].[Stat],1,1) = 'O',
								iif([TransactionItems].[DDT] < @Today,
										dateadd(d,6,@Today),
										dateadd(hh, [CleaningDelay],iif([Transactions].[Pickup]=1,
																			[Transactions].[PickupDate],
																			[DDT]))),
								dateadd(hh,[CleaningDelay],iif([Transactions].[Pickup]=1,
																			[Transactions].[PickupDate],
																			[DDT]))) >= @StartDate
		   And ( 
			 		[Transactions].[STR] In (Select StoreNumber from #tmp_Stores)	
						Or ItemFile.CurrentStore In (Select StoreNumber from #tmp_Stores)
				) 
		 Order By #tmp_Items.ItemKey,
					IIF(Transactions.Delvr = 1,
						Transactions.DeliveryDate,
						[Date]), TransactionItems.Qty

		-- Add transactions which were opened during the date range
		-- QUERY FROM ARASV1.CHECKAVAILABLITYNEW
/*
		 "SELECT Transactions.CNTR, Transactions.STAT, TransactionItems.ITEM, TransactionItems.QTY,ItemFile.Qty as QtyOwned, ItemFile.Header, " & 
		         fnIIF("Transactions.Delvr,Transactions.DeliveryDate,[Date]") & " AS DateOut, " & 
		         fnDateAdd("'h',CleaningDelay," & fnIIF("Transactions.Pickup,Transactions.PickupDate,DDT") & "") & " AS DateBack " & _
        "FROM ItemFile 
		 RIGHT JOIN (Transactions 
		 RIGHT JOIN TransactionItems ON Transactions.CNTR = TransactionItems.CNTR) ON ItemFile.NUM = TransactionItems.ITEM " &
       "WHERE (Transactions.CNTR Not Like '[cq]%') 
		   AND (Transactions.STAT Not Like '[C ]%') 
		   AND (TransactionItems.Txty <> 'RR') 
		   AND (TransactionItems.Txty <> 'RX') 
		   AND (TransactionItems.Txty Not Like 'S%') 
		   AND (" & fnIIF("[Transactions].[Delvr],
							[Transactions].[DeliveryDate],
							[Date]") & " > " & fnDateDelim() & DateTimeHelper.ToString(BegDate) & fnDateDelim() & ") 
		   AND (" & fnIIF("[Transactions].[Delvr],
							[Transactions].[DeliveryDate],
							[Date]") & " <= " & fnDateDelim() & DateTimeHelper.ToString(EndDate) & fnDateDelim() & ") " 
		  & ItemWhereClause & StoreWhereClause
*/

		Insert Into #tmp_Transactions
		Select Transactions.CNTR, Transactions.STAT, TransactionItems.ITEM, TransactionItems.QTY, 
			   ItemFile.Qty as QtyOwned, ItemFile.[Key], ItemFile.Header,   
		         IIF(Transactions.Delvr = 1,
						Transactions.DeliveryDate,
						iif(Ltrim(Rtrim(IsNull([Time],'')))='',
							cast(substring(convert(varchar,[date],101),1,10) + ' 00:00' as datetime),
							cast(substring(convert(varchar,[date],101),1,10) + ' ' + substring([time],1,2) + ':' + substring([time],3,2) as datetime))) AS DateOut,
		         DateAdd(hh,CleaningDelay,IIF(Transactions.Pickup = 1,
											  Transactions.PickupDate,
											  iif(Ltrim(Rtrim(IsNull([DTM],'')))='',
												  cast(substring(convert(varchar,[DDT],101),1,10) + ' 00:00' as datetime),
												  cast(substring(convert(varchar,[DDT],101),1,10) + ' ' + substring([DTM],1,2) + ':' + substring([DTM],3,2) as datetime)))) AS DateBack,
			   Transactions.[STR]
		  From Transactions 
		  Join TransactionItems  On Transactions.CNTR = TransactionItems.CNTR
		  Join ItemFile  On ItemFile.NUM = TransactionItems.ITEM
		  Join #tmp_Items on #tmp_Items.ItemKey = ItemFile.[Key]
		 Where (Transactions.CNTR Not Like '[cq]%') 
		   And (Transactions.STAT Not Like '[C ]%') 
		   And (TransactionItems.Txty <> 'RR') 
		   And (TransactionItems.Txty <> 'RX') 
		   And (TransactionItems.Txty Not Like 'S%') 

			-- Items went out during date range
		   And iif([Transactions].[Delvr] = 1,
					[Transactions].[DeliveryDate],
						iif(Ltrim(Rtrim(IsNull([Time],'')))='',
							cast(substring(convert(varchar,[date],101),1,10) + ' 00:00' as datetime),
							cast(substring(convert(varchar,[date],101),1,10) + ' ' + substring([time],1,2) + ':' + substring([time],3,2) as datetime))) Between @StartDate And @EndDate
		   And ( 
			 		[Transactions].[STR] In (Select StoreNumber from #tmp_Stores)	
						Or ItemFile.CurrentStore In (Select StoreNumber from #tmp_Stores)
				) 
		 Order By #tmp_Items.ItemKey,
					IIF(Transactions.Delvr = 1,
						Transactions.DeliveryDate,
						[Date]), TransactionItems.Qty

--Select * FROM #tmp_Transactions order by dateout, dateback

/**************************************************************/
	-- Derive the Max Quantity Out and the Min Available
/**************************************************************/

		-- Transpose the transactions into a running list of Out and In events
		Create Table #tmp_InOut
		(RowId	Int,
		 ItemKey  varchar(64),
		 [Date] DateTime,
		 Qty	  Float,
		 QtyOwned Float
		)

			   /*
					Time sorting logic from David

					if {qryOverbook.Evnt} = '0' then  (1 in, 0 out)
						(
							if left({qryOverbook.CNTR},1) = 'S' then '  Sbrnt'        
							else if party_code = true then ' Open' 
							else {qryOverbook.TIME}
						)

				   if {qryOverbook.Evnt} = '1' then 
					(
						if party_code = true and {qryOverbook.STAT} = 'O' and DateDiff('d',CurrentDate,Date({qryOverbook.DATE})) < -1 then 'Ovrdue'
						else if party_code = true and {qryOverbook.STAT} = 'O' and DateDiff('d',CurrentDate,Date({qryOverbook.DATE})) = -1 then 'Late'
						else if DateDiff('d',CurrentDate,Date({qryOverbook.DATE})) <  0 then 'Ovrdue'
						else if {qryOverbook.DATE} = CurrentDate and iif(trim({@WindowTime})='',{qryOverbook.TIME},{@WindowTime}) < CStr(CurrentTime,'HHmm') then 'Late'
						else if left({qryOverbook.CNTR},1) = 'S' then 'Sbrnt'
						else if trim({@WindowTime}) = '' and {QryOverbook.PUFlag} = false then iif(party_code=true,'Close',{qryOverbook.TIME})
						else iif(party_code=true,'Close',{@WindowTime})
					)
					else 
			
 			 */

		-- Out
		Insert Into #tmp_InOut (RowId, ItemKey, [Date], Qty, QtyOwned)
		Select #tmp_Transactions.RowId,
			   #tmp_Items.[Header],
			   Case When (Substring(#tmp_Transactions.CNTR,1,1) = 'S')
						Then cast(substring(convert(varchar,#tmp_Transactions.DateOut,101),1,10) + ' 00:00.008' as datetime)
			        When (iif(RTrim(Ltrim(IsNull(#tmp_Items.Ratecode,'')))='', #tmp_Stores.RateCode, #tmp_Items.Ratecode) = 3)
						Then cast(substring(convert(varchar,#tmp_Transactions.DateOut,101),1,10) + ' 00:00.005' as datetime)
					Else 
						#tmp_Transactions.DateOut
			   End as [Date], 
			  -#tmp_Transactions.Qty,
			   #tmp_ItemOwnedSummary.QtyOwned
		  From #tmp_Transactions
		  Join #tmp_items on #tmp_items.ItemKey = #tmp_transactions.[Key]
		  Join #tmp_ItemOwnedSummary on #tmp_items.Header = #tmp_ItemOwnedSummary.ItemKey
		  Join #tmp_Stores on #tmp_Stores.StoreNumber = #tmp_transactions.[STR]

		-- In (Back)
		Insert Into #tmp_InOut (RowId, ItemKey, [Date], Qty, QtyOwned)
		Select #tmp_Transactions.RowId,
			   #tmp_Items.[Header],
			   Case When ((iif(RTrim(Ltrim(IsNull(#tmp_Items.Ratecode,'')))='', #tmp_Stores.RateCode, #tmp_Items.Ratecode) = 3)
					 And Substring(#tmp_Transactions.STAT,1,1) = 'O' 
					 And DateDiff(d,@Today,#tmp_Transactions.DateBack) < -1)
						Then cast(substring(convert(varchar,#tmp_Transactions.DateBack,101),1,10) + ' 00:00.013' as datetime) --'Overdue'
					When ((iif(RTrim(Ltrim(IsNull(#tmp_Items.Ratecode,'')))='', #tmp_Stores.RateCode, #tmp_Items.Ratecode) = 3)
					 And Substring(#tmp_Transactions.STAT,1,1) = 'O' 
					 And DateDiff(d,@Today,#tmp_Transactions.DateBack) = -1)
						Then cast(substring(convert(varchar,#tmp_Transactions.DateBack,101),1,10) + ' 00:00.012' as datetime) --'Late'
					When (DateDiff(d,@Today,#tmp_Transactions.DateBack) < 0) 
						Then cast(substring(convert(varchar,#tmp_Transactions.DateBack,101),1,10) + ' 00:00.013' as datetime) --'Overdue'
					When (DateDiff(d,@Today,#tmp_Transactions.DateBack) = 0)
						Then cast(substring(convert(varchar,#tmp_Transactions.DateBack,101),1,10) + ' 00:00.012' as datetime) --'Late'
					When (Substring(#tmp_Transactions.CNTR,1,1) = 'S')
						Then cast(substring(convert(varchar,#tmp_Transactions.DateBack,101),1,10) + ' 00:00.015' as datetime) --'Subrent'
					Else 
						#tmp_Transactions.DateBack
					End as [Date], 
			   #tmp_Transactions.Qty,
			   #tmp_ItemOwnedSummary.QtyOwned
		  From #tmp_Transactions
		  Join #tmp_items on #tmp_items.ItemKey = #tmp_transactions.[Key]
		  Join #tmp_ItemOwnedSummary on #tmp_items.Header = #tmp_ItemOwnedSummary.ItemKey
		  Join #tmp_Stores on #tmp_Stores.StoreNumber = #tmp_transactions.[STR]


--select * from #tmp_InOut order by [Date]

		-- Calculate a running total out and total available
		Create Table #tmp_Available
		(RowId	  Int,
		 ItemKey  Varchar(64),
		 [Date]	  DateTime,
		 Qty	  Float,
		 QtyOwned Float,
		 TotalOut Float,
		 Available Float
		)	

		DECLARE	@RowId		  Int,
				@Date         DATE,
				@Qty		  Float,
				@TotalOut	  Float = 0,
				@Available	  Float = 0,
				@CurrentItemKey	Varchar(64) = ''
 
		DECLARE c CURSOR
			LOCAL STATIC FORWARD_ONLY READ_ONLY
			FOR
			SELECT RowId, [ItemKey], [Date], Qty, QtyOwned
			  FROM #tmp_InOut
			  ORDER BY [ItemKey], [Date];
 
		OPEN c;
 
		FETCH NEXT FROM c INTO @RowId, @ItemKey, @Date, @Qty, @QtyOwned;
 
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF (@CurrentItemKey <> @ItemKey)
			Begin
				Set @TotalOut = 0
				Set @CurrentItemKey = @ItemKey
			End

			SET @TotalOut = @TotalOut - @Qty;
			Set @Available = @QtyOwned - @TotalOut

			INSERT #tmp_Available(RowId, ItemKey, [Date], Qty,  QtyOwned, TotalOut, Available)
				SELECT @RowId, @ItemKey, @Date, @Qty, @QtyOwned, @TotalOut, @Available;
 
			FETCH NEXT FROM c INTO @RowId, @ItemKey, @Date, @Qty, @QtyOwned;
		END
 
		CLOSE c;
		DEALLOCATE c;

--select * from #tmp_available order by [Date]


--select @StartDate, @enddate

if (@LandingPageOnly = 1)
Begin

declare  
@cdt as datetime,
@sql varchar(4000),
@idx as int

	Create table #tmp_Final
	(
	    ItemKey  Varchar(64),
		Date1	datetime,
		Qty1	integer,
		Date2	datetime,
		Qty2	integer,
		Date3	datetime,
		Qty3	integer,
		Date4	datetime,
		Qty4	integer,
		Date5	datetime,
		Qty5	integer,
		Date6	datetime,
		Qty6	integer,
		Date7	datetime,
		Qty7	integer,
	)

	-- Only return items that have an overbooked availability (-)	
	-- during the 7 day date range
	insert into #tmp_final (ItemKey) 
	select distinct itemKey 
	  from #tmp_available 
	 where Available < 0
	   and [Date] between @StartDate and @enddate 

	set @idx = 1
	set @cdt = @StartDate
	while (@idx <= 7)
	begin
		set @sql = 'update #tmp_Final '
		set @sql = @sql + 'Set Date' + ltrim(rtrim(cast(@idx as varchar(3)))) + ' = ' + '''' + convert(varchar(20), @cdt, 101) + '''' 
		set @sql = @sql + ', Qty' + ltrim(rtrim(cast(@idx as varchar(3)))) + ' = 0 '

	--	select @sql
		exec(@sql)

		set @sql = 'update #tmp_Final '
		set @sql = @sql + 'Set Qty' + ltrim(rtrim(cast(@idx as varchar(3)))) + ' = b.Available '
		set @sql = @sql + 'From #tmp_Available b '
		set @sql = @sql + 'Where b.[Date] = ''' + convert(varchar(20), @cdt, 101) + ''' And b.ItemKey = #tmp_final.ItemKey' 

	  --select @sql
		exec(@sql)

		set @idx = @idx + 1
		set @cdt = @cdt + 1
	end

	-- Widget Template Output*****************
	Select A.ItemKey, I.Num as ItemNumber,  A.Qty1 as [Today], A.Qty2 as [Day2],  A.Qty3 as [Day3],  A.Qty4 as [Day4],  A.Qty5 as [Day5],  A.Qty6 as [Day6],  A.Qty7 as [Day7]
	  From #tmp_Final a
 	 Inner Join ItemFile I on I.[Key] = A.ItemKey

	drop table #tmp_final

End
Else
Begin
	if (@IROonly = 0 )
	Begin
		-- Return Availability by DAte
		Select A.ItemKey, I.Num as ItemNumber, A.[Date], A.QtyOwned, Max(A.TotalOut) as QtyOut, Min(A.Available) as QtyAvailable
			From #tmp_Available A
			Inner Join ItemFile I on I.[Key] = A.ItemKey
			where A.[Date] >= @StartDate
			and A.[Date] <= @EndDate
		  Group By ItemKey, [Date], QtyOwned, I.Num
		  Order By ItemKey, [Date]



	End
	Else
	Begin
		-- For IRO analysis, Return only the items that are overbooked during the date range
		Select A.ItemKey, I.Num as ItemNumber, A.QtyOwned, Max(A.TotalOut) as MaximumOut, Min(A.Available) as MinimumAvailable
			From #tmp_Available A
			Inner Join ItemFile I on I.[Key] = A.ItemKey
			where A.[Date] >= @StartDate
			and A.[Date] <= @EndDate
		  Group By ItemKey, QtyOwned, I.Num
		  Having Min(Available) < 0
		  Order By ItemKey
	End
End

	Drop Table #tmp_Stores
	Drop Table #tmp_Items
	Drop Table #tmp_Items1
	Drop Table #tmp_ItemOwnedSummary
	Drop Table #tmp_Transactions
	Drop Table #tmp_InOut
	Drop Table #tmp_Available

	Set Nocount off
END

go

