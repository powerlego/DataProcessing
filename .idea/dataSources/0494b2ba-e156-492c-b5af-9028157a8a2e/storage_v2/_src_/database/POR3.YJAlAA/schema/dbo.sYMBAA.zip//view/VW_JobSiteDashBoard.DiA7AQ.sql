
CREATE VIEW [dbo].[VW_JobSiteDashBoard]
AS

SELECT DISTINCT Transactions.[CNTR], [STR], [CUSN], [STAT], [JOBN],  
       [DATE], [TIME], [EventEndDate], [DeliveryDate], [PickupDate], [CMDT], [Billed],  
       [TOTL], [PAID], [TOTL]-[PAID] AS [OWED], [PYMT], [DEPP], [DPMT], [DeliverToCompany],  
       [SameAddress] , [DeliveryAddress], [DeliveryCity], [DeliveryZip], [Contact],  
       Transactions.[ContactPhone] , [Delvr], [DeliveryConfirmed], [Pickup], [PickupConfirmed],  
       [DeliveryTruckNumber] , [PickupTruckNumber], [DeliveryTrip], [PickupTrip], [PickedUpBy], [OrderedBy],  
       [JBPO], [JBID], [TransactionType], [Operation], [LastLetter], [LetterDate], [MasterBill],  
       [Sale], [Rent], [Tax], [Dmg], [ItemPercentage], [CLDT], [Completed],  [Modification], [JobSite],  
       [CustomerFile].[Key], CustomerFile.[Name], [CustomerFile].[Address], CustomerFile.[City], 
	   CustomerFile.[Zip], CustomerFile.[Phone],  
       Salesman.[Name] As SalesmanName, [OperationName], [TypeName],  
       CustomerJobSite.[Description], CustomerJobSite.[SiteCity], CustomerJobSite.[Salesman] as JobsiteSalesman, 
	   CustomerFile.[Salesman] as CustomerSalesman, 0 as [History]  
  FROM (((Salesman 
          RIGHT JOIN 
             (CustomerFile 
			 RIGHT JOIN Transactions 
		        ON CustomerFile.CNUM = Transactions.CUSN) 
		        ON Salesman.Number = Transactions.Salesman) 
		  LEFT JOIN CustomerJobSite  
            ON Transactions.JobSite = CustomerJobSite.Number) 
          LEFT JOIN TransactionOperation 
		    ON Transactions.Operation = TransactionOperation.OperationNumber) 
  LEFT JOIN TransactionType 
    ON Transactions.TransactionType = TransactionType.TypeNumber  
 UNION  
SELECT DISTINCT TransHistory.[CNTR], [STR], [CUSN], [STAT], [JOBN],  
       [DATE], [TIME], [EventEndDate], [DeliveryDate], [PickupDate], [CMDT], [Billed],  
       [TOTL], [PAID], [TOTL]-[PAID] AS [OWED], [PYMT], [DEPP], [DPMT], [DeliverToCompany],  
       [SameAddress] , [DeliveryAddress], [DeliveryCity], [DeliveryZip], [Contact],  
       TransHistory.[ContactPhone] , [Delvr], [DeliveryConfirmed], [Pickup], [PickupConfirmed],  
       [DeliveryTruckNumber], [PickupTruckNumber], [DeliveryTrip], [PickupTrip], [PickedUpBy], [OrderedBy],  
       [JBPO], [JBID], [TransactionType], [Operation], [LastLetter], [LetterDate], [MasterBill],  
       [Sale], [Rent], [Tax], [Dmg], [ItemPercentage], [CLDT], [Completed],  [Modification], [JobSite],  
       [CustomerFile].[Key], CustomerFile.[Name], [CustomerFile].[Address], CustomerFile.[City], CustomerFile.[Zip], CustomerFile.[Phone],  
       Salesman.[Name] As SalesmanName, [OperationName], [TypeName],  
       CustomerJobSite.[Description], CustomerJobSite.[SiteCity], CustomerJobSite.[Salesman] as JobsiteSalesman, 
	   CustomerFile.[Salesman] as CustomerSalesman, 1 as [History]
  FROM (((Salesman 
          RIGHT JOIN 
            (CustomerFile 
			RIGHT JOIN TransHistory 
		       ON CustomerFile.CNUM = TransHistory.CUSN) 
		       ON Salesman.Number = TransHistory.Salesman) 
		  LEFT JOIN CustomerJobSite  
            ON TransHistory.JobSite = CustomerJobSite.Number) 
          LEFT JOIN TransactionOperation 
		    ON TransHistory.Operation = TransactionOperation.OperationNumber) 
  LEFT JOIN TransactionType 
    ON TransHistory.TransactionType = TransactionType.TypeNumber

go

