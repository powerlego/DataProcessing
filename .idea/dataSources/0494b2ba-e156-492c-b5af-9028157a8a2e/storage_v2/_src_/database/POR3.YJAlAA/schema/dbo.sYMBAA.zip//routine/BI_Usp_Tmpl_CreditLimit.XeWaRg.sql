
CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_CreditLimit] 
	@WidgetDataFilter KeyValuePair READONLY
AS
BEGIN

	SELECT  Perc.CreditUsed AS [CreditUsed] , 
			Perc.CreditGranted AS [CreditGranted],
			CONVERT(varchar(50),CAST(Perc.CreditUsed as money) / CAST(Perc.CreditGranted as money)*100)+'%' as [PercentUsed]
	FROM(
			SELECT 'Credit Analysis' as Type ,SUM(main.owed) as CreditUsed, SUM(CFMain.CreditLimit) as CreditGranted
			FROM(
					SELECT Cf.CNUM, SUM((T.TOTL - T.Paid)) AS Owed
					FROM dbo.Transactions T
					LEFT JOIN dbo.CustomerFile CF ON T.CUSN = CF.CNum			
					WHERE left (T.CNTR,1) NOT IN  ('f','h','l','q','r','s','t')	 
					AND T.PYMT <> 'T' 
					AND (T.Totl-T.Paid) <> 0
					AND Right(Left(T.[STAT] + '  ',2),1) NOT IN ('C') 				
					GROUP BY CF.CNUM 
				) Main
			RIGHT JOIN CustomerFile CFMain 
			ON Main.CNUM = CFMain.CNUM
			WHERE CFMain.CreditLimit <> 0
	) Perc
END
go

