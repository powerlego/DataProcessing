
CREATE VIEW [dbo].[VW_TaskSearch] 
AS

SELECT 
			[TL].[Number],
			[TL].[Store],
			[TL].[Status],
			[TL].[OprCreated],
			[TL].[OprAssigned],
			[TL].[OprCompleted],
			[TL].[GroupAssigned],
			[TL].[DateCreated],
			[TL].[DateDue],
			[TL].[DateRemind],
			[TL].[DateCompleted],
			[TL].[LastNumber],
			[TL].[NotifyWhenComplete],
			[TL].[Frequency],
			[TL].[Description],
			[TL].[ToDoTask],
			[TL].[CompletionNotes],
			[TL].[EditHistory],
			[TL].[Cusn],
			[TL].[CNTR],

			[CF].[NAME] AS [CF_NAME],

			[PF].[STORE_NAME] AS [PF_STORE_NAME],
			[PF_TR].[Languagecode] AS [PF_Languagecode],
			[PF_TR].[STORE_NAME] AS [PF_STORE_NAME_TR],

			[GF].[GroupName] AS [GF_GroupName],
			[GF_TR].[Languagecode] AS [GF_Languagecode],
			[GF_TR].[GroupName] AS [GF_GroupName_TR],

			[OC].[OPNM] AS [OC_OPNM],
			[OC].[HomeStore] AS [OC_HomeStore],
			[OA].[OPNM] AS [OA_OPNM],
			[OA].[HomeStore] AS [OA_HomeStore],
			[OX].[OPNM] AS [OX_OPNM],
			[OX].[HomeStore] AS [OX_HomeStore]

FROM		[TaskList]			AS	[TL]
LEFT JOIN	[CustomerFile]		AS	[CF]		ON	[TL].[Cusn]				=	[CF].[CNUM]
LEFT JOIN	[ParameterFile]		AS	[PF]		ON	[TL].[Store]			=	[PF].[Store]
LEFT JOIN	[ParameterFile_Tr]	AS	[PF_TR]		ON	[TL].[Store]			=	[PF_TR].[Store]			AND	[PF_TR].[Inactive] = 0
LEFT JOIN	[GroupFile]			AS	[GF]		ON	[TL].[GroupAssigned]	=	[GF].[GroupNumber]
LEFT JOIN	[GroupFile_Tr]		AS	[GF_TR]		ON	[TL].[GroupAssigned]	=	[GF_TR].[GroupNumber]	AND	[GF_TR].[Inactive] = 0
LEFT JOIN	[OperatorId]		AS	[OC]		ON	[TL].[OprCreated]		=	[OC].[OPNO]				AND	[OC].[Inactive] = 0
LEFT JOIN	[OperatorId]		AS	[OA]		ON	[TL].[OprAssigned]		=	[OA].[OPNO]				AND	[OA].[Inactive] = 0
LEFT JOIN	[OperatorId]		AS	[OX]		ON	[TL].[OprCompleted]		=	[OX].[OPNO]				AND	[OX].[Inactive] = 0
go

