
CREATE PROCEDURE DBO.spLoadRouseTables

AS

/*****************************************************************************************/
--	POR.DBO.spLoadRouseTables
--		Called from module RouseExport.exe
--
--	PARAMETERS: none
--
--	HISTORY:	11/19/2014	JY	CREATED	--
--				03/04/2016  JY  Disabled ANSI Warnings, Corrected time formats
--				03/08/2016  JY  Change IsBulk and IsKit to return -1 for True
--				06/13/2016  JY  AncillaryFile - Error on City Name with no comma
--				10/04/2016  JY  Fix wildcards on Fuel and Environ
--				03/28/2018  JY  Remove the QTY<>0 constraint for InvoiceDetail
--              05/22/2018  JY  Allow for NULLs in TransactionItems.DDT and DTM
--				09/21/2018  JY  (1226) Add/change columns in EquipmentMaster
--				10/08/2018  JY  (1226) Add Quantity column in EquipmentMaster
--				10/15/2018  JY  (1226) Add LifeToDateMaintenance column in EquipmentMaster
--				03/19/2019  JY  (2392) Add ProductTypeRateFile table
--				06/24/2019  JY  (2989) ProductTypeRateFile - Query changes
--				08/15/2019  JY  (871)  Add columns to EquipmentMasterFile
--				10/30/2020  JY  (9807) Add 4 fields to InvoiceDetailFile
--				01/20/2021  JY  (12409) Change Status & LastTransactionInvoice in EquipmentMaster
/*****************************************************************************************/

BEGIN
    SET NOCOUNT ON
	SET ANSI_WARNINGS OFF
	IF (object_id('TempDB.dbo.RouseStoresMonths') > 0)
        DROP TABLE TempDB.dbo.RouseStoresMonths

	IF (object_id('TempDB.dbo.RouseReasonCodeFile') > 0)
        DROP TABLE TempDB.dbo.RouseReasonCodeFile

	IF (object_id('TempDB.dbo.RouseProductTypeMasterFile') > 0)
        DROP TABLE TempDB.dbo.RouseProductTypeMasterFile

	IF (object_id('TempDB.dbo.RouseInvoiceDetailFile') > 0)
        DROP TABLE TempDB.dbo.RouseInvoiceDetailFile

	IF (object_id('TempDB.dbo.RouseEquipmentMasterFile') > 0)
        DROP TABLE TempDB.dbo.RouseEquipmentMasterFile

	IF (object_id('TempDB.dbo.RouseCredits') > 0)
        DROP TABLE TempDB.dbo.RouseCredits

	IF (object_id('TempDB.dbo.RouseAncillaryFeesA') > 0)
        DROP TABLE TempDB.dbo.RouseAncillaryFeesA

	IF (object_id('TempDB.dbo.RouseBranchFile') > 0)
        DROP TABLE TempDB.dbo.RouseBranchFile

	IF (object_id('TempDB.dbo.RouseProductTypeRateFile') > 0)
        DROP TABLE TempDB.dbo.RouseProductTypeRateFile

		   
				SELECT ParameterFile.Store, Month(TotalsContractsAccrual.Date) AS [Date]
				  INTO TempDB.dbo.RouseStoresMonths
 				  FROM ParameterFile
				 INNER JOIN TotalsContractsAccrual ON ParameterFile.Store = TotalsContractsAccrual.Store
				 GROUP BY ParameterFile.Store, Month(TotalsContractsAccrual.Date)


            SELECT (SELECT Max(VendorFile.AccountNumber) AS AccountNumber
                      FROM VendorFile
                     WHERE VendorFile.VendorName='Rouse Analytics') AS ClientCode,
                   ParameterFile.Store, RouseReasonCodes.*
			  INTO TempDB.dbo.RouseReasonCodeFile
              FROM ParameterFile, RouseReasonCodes

            SELECT (SELECT Max(VendorFile.AccountNumber) AS AccountNumber
                      FROM VendorFile
                     WHERE VendorFile.VendorName='Rouse Analytics') AS ClientCode,
                                ItemCategory.Category AS Category,
                   IIf((RTrim(Itemfile.header)='' Or (itemfile.header IS NULL)), 
							ItemFile.NUM, 
							IIf((itemfile_1.NUM IS NULL),
									'Error in' + ItemFile.NUM, 
									ItemFile_1.NUM)) AS ProductType, 
				   IIf((Rtrim(itemfile.header)='' Or (itemfile.header IS NULL)), 
							ItemFile.Name, 
							IIf((itemfile_1.NUM IS NULL), 
									'Error Missing Header', 
									ItemFile_1.NAME)) AS Description, 
				   IIf((Rtrim(itemfile.header)='' Or (itemfile.header IS NULL)), 
							IIf((ItemFile.BulkItem = 1), 
									-1, 
									0), 
							IIf((ItemFile_1.BulkItem = 1), 
									-1, 
									0)) AS IsBulk, 
				   IIf((Rtrim(itemfile.header)='' Or (itemfile.header IS NULL)), 
							IIf((ItemFile.[TYPE] = 'A'), 
									-1, 
									0), 
							IIf((ItemFile_1.[TYPE] = 'A'), 
									-1, 
									0)) AS IsKit, 
				   ItemCategory.Name AS ProductTypeOption1, 
				   IIf((Rtrim(itemfile.header)='' Or (itemfile.header IS NULL)), 
							Cast(ItemComments.Specs as varchar(Max)), 
							IIf((itemfile_1.NUM IS NULL), 
									'Error', 
									Cast(ItemComments_1.Specs as varchar(Max)))) AS ProductTypeOption2, 
				   IIf((Rtrim(itemfile.header)='' Or (itemfile.header IS NULL)), 
							IIf((ItemFile.Type In ('S','F','M','E')), 
										IIf((Left(itemfile.[key],1)='|'), 
										'Y', 
										IIf((itemfile.name Like '%fuel%'), 
												'Z', ItemFile.Type)), 
												ItemFile.Type),
							IIf((ItemFile_1.NUM IS NULL), 
										'Error', 
										IIf((ItemFile_1.Type In ('S','F','M','E')), 
													IIf((Left(itemfile_1.[key],1) = '|'),
															'Y',
															IIf((itemfile_1.name Like '%fuel%'), 
																	'Z', 
																	ItemFile_1.Type)),
													ItemFile_1.Type))) AS ProductTypeOption3, 
				   ItemCategory.DivisionNumber AS ProductTypeOption4 
			  INTO TempDB.dbo.RouseProductTypeMasterFile 
			  FROM (((ItemCategory 
			 RIGHT JOIN ItemFile ON ItemCategory.Category = ItemFile.Category) 
			  LEFT JOIN ItemFile AS ItemFile_1 ON ItemFile.Header = ItemFile_1.[KEY]) 
			  LEFT JOIN ItemComments ON ItemFile.NUM = ItemComments.NUM) 
			  LEFT JOIN ItemComments AS ItemComments_1 ON ItemFile_1.NUM = ItemComments_1.NUM 
			 WHERE ItemFile.TYPE Not In ('V','E')
             GROUP BY ItemCategory.Category, 
					  IIf((Rtrim(itemfile.header) = '' Or itemfile.header IS NULL),
							ItemFile.NUM,
							IIf((itemfile_1.NUM IS NULL),
								'Error in' + ItemFile.NUM,
								ItemFile_1.NUM)), 
  					  IIf((Rtrim(itemfile.header) = '' Or itemfile.header IS NULL),
								ItemFile.Name,
								IIf((itemfile_1.NUM IS NULL),
										'Error Missing Header',
										ItemFile_1.NAME)), 
					  IIf((Rtrim(itemfile.header)='' Or itemfile.header IS NULL), 
							IIf((ItemFile.BulkItem = 1),
									-1,
									0),
							IIf((ItemFile_1.BulkItem = 1),
									-1,
									0)), 
					  IIf((Rtrim(itemfile.header)='' Or itemfile.header IS NULL),
							IIf((ItemFile.[TYPE]='A'),
									-1,
									0),
							IIf((ItemFile_1.[TYPE]='A'),
									-1,
									0)), 
					  ItemCategory.Name, 
					  IIf((Rtrim(itemfile.header)='' Or (itemfile.header IS NULL)), 
							Cast(ItemComments.Specs as varchar(Max)), 
							IIf((itemfile_1.NUM IS NULL), 
									'Error', 
									Cast(ItemComments_1.Specs as varchar(Max)))), 
					  IIf((Rtrim(itemfile.header)='' Or itemfile.header IS NULL),
							IIf(ItemFile.Type In ('S','F','M','E'),
									IIf(Left(itemfile.[key],1)='|',
											'Y',
											IIf((itemfile.name Like '%fuel%'),
													'Z',
													ItemFile.Type)),
									ItemFile.Type),
							IIf((ItemFile_1.NUM IS NULL),
									'Error',
									IIf(ItemFile_1.Type In ('S','F','M','E'), 
											IIf(Left(itemfile_1.[key],1)='|',
													'Y',
													IIf((itemfile_1.name Like '%fuel%'),
															'Z',
															ItemFile_1.Type)),
											ItemFile_1.Type))), 
					  ItemCategory.DivisionNumber;
					  
             SELECT (SELECT Max(VendorFile.AccountNumber) AS AccountNumber
                       FROM VendorFile WHERE (((VendorFile.VendorName)='Rouse Analytics'))) AS ClientCode, GetDate() AS RecordDate, 
					   qryTransactionItems.CNTR AS ContractNo, 
					   IIf(Left(qryTransactionItems.TXTY,1)='R',
					      'R',
						  IIf(Left(ItemFile.[KEY],1)='|',
						     'D',
							 IIf(ItemFile.Type='L',
							    'L',
								IIf(ItemFile.Type='N',
								   'C',
								   IIf(Left(qryTransactionItems.TXTY,1)='SA',
								      'A',
									  IIf(Left(qryTransactionItems.TXTY,1)='S',
									     IIf(itemfile.type='U',
									        'U',
										    IIf(ItemFile.SELL<0,
										       'C',
											   'S')),
										 NULL)))))) AS TransactionType, 
					  qryTransactionItems.CNTR AS InvoiceNo, 
					  qryTransactionItems.SUBF AS [LineNo], 
					  Null AS TransactionIDOption1, 
					  qryTransactions.STR AS LocationCode, 
					  ItemFile.Category AS Category, 
					  IIf((IsNull(Rtrim(itemfile.header),'') =''), 
					     ItemFile.NUM,
					     IIf((itemfile_1.NUM is Null),
					        'Error in' + ItemFile.NUM,
						    ItemFile_1.NUM)) AS ProductType, 
					  ItemFile.NUM AS EquipmentIDNo, 
					  qryTransactionItems.QTY AS Quantity,
					  qryTransactions.CUSN AS CustomerNo, 
					  IIf((qryTransactionItems.DailyAmount+qryTransactionItems.WeeklyAmount+qryTransactionItems.MonthlyAmount+qryTransactionItems.MinimumAmount)<>0,
					     'S',
						 'B') AS ContractType, 
					  IIf(ItemFile.Type='H',
					     'Hours',
						 IIf(ItemFile.Type='U',
						    'Usage',
							'None')) AS Meter, 
					  qryTransactionItems.ReadingOut AS MeterOut, 
					  qryTransactionItems.ReadingIn AS MeterIn, 
					  ItemFile.RATE10 AS MileageRate, 
					  IIf(Left(qryTransactionItems.TXTY,1)='S',
					     Null, 
						 IIf(qryTransactionItems.MinimumAmount+qryTransactionItems.DailyAmount+qryTransactionItems.WeeklyAmount+qryTransactionItems.MonthlyAmount>0,
						    qryTransactionItems.DailyAmount/24,
							IIf(ItemFile.PER1=0,
							   0,
							   (ItemFile.RATE1/ItemFile.PER1)))) AS HourlyRate, 
					  IIf(Left(qryTransactionItems.TXTY,1)='S',
					     Null,
						 IIf(qryTransactionItems.MinimumAmount+qryTransactionItems.DailyAmount+qryTransactionItems.WeeklyAmount+qryTransactionItems.MonthlyAmount>0,
						    qryTransactionItems.MinimumAmount,
							ItemFile.Rate1)) AS MinimumRate,


					  Case When (Left(qryTransactionItems.TXTY,1)='S') Then Null
						   When (qryTransactionItems.MinimumAmount+qryTransactionItems.DailyAmount+qryTransactionItems.WeeklyAmount+qryTransactionItems.MonthlyAmount>0) Then qryTransactionItems.DailyAmount
						   When (ItemFile.PER1=24) Then ItemFile.Rate1
						   When (ItemFile.PER2=24) Then ItemFile.Rate2
						   When (ItemFile.PER3=24) Then ItemFile.Rate3
						   When (ItemFile.PER4=24) Then ItemFile.Rate4
						   When (ItemFile.PER5=24) Then ItemFile.Rate5
						   When (ItemFile.PER6=24) Then ItemFile.Rate6
						   When (ItemFile.PER7=24) Then ItemFile.Rate7
						   When (ItemFile.PER8=24) Then ItemFile.Rate8
						   When (ItemFile.PER9=24) Then ItemFile.Rate9
						   When (ItemFile.PER10=24) Then ItemFile.Rate10
						   Else 0 End AS DailyRate,
					  Case When (Left(qryTransactionItems.TXTY,1)='S') Then Null
						   When (qryTransactionItems.MinimumAmount+qryTransactionItems.DailyAmount+qryTransactionItems.WeeklyAmount+qryTransactionItems.MonthlyAmount>0) then qryTransactionItems.WeeklyAmount
						   When (ItemFile.PER1=168) Then ItemFile.Rate1
						   When (ItemFile.PER2=168) Then ItemFile.Rate2
						   When (ItemFile.PER3=168) Then ItemFile.Rate3
						   When (ItemFile.PER4=168) Then ItemFile.Rate4
						   When (ItemFile.PER5=168) Then ItemFile.Rate5
						   When (ItemFile.PER6=168) Then ItemFile.Rate6
						   When (ItemFile.PER7=168) Then ItemFile.Rate7
						   When (ItemFile.PER8=168) Then ItemFile.Rate8
						   When (ItemFile.PER9=168) Then ItemFile.Rate9
						   When (ItemFile.PER10=168) Then ItemFile.Rate10
						   Else 0 End AS WeeklyRate,
					  Case When (Left(qryTransactionItems.TXTY,1)='S') Then Null
						   When (qryTransactionItems.MinimumAmount+qryTransactionItems.DailyAmount+qryTransactionItems.WeeklyAmount+qryTransactionItems.MonthlyAmount>0) then qryTransactionItems.MonthlyAmount
						   When (ItemFile.PER1 In (672,744)) Then ItemFile.Rate1
						   When (ItemFile.PER2 In (672,744)) Then ItemFile.Rate2
						   When (ItemFile.PER3 In (672,744)) Then ItemFile.Rate3
						   When (ItemFile.PER4 In (672,744)) Then ItemFile.Rate4
						   When (ItemFile.PER5 In (672,744)) Then ItemFile.Rate5
						   When (ItemFile.PER6 In (672,744)) Then ItemFile.Rate6
						   When (ItemFile.PER7 In (672,744)) Then ItemFile.Rate7
						   When (ItemFile.PER8 In (672,744)) Then ItemFile.Rate8
						   When (ItemFile.PER9 In (672,744)) Then ItemFile.Rate9
						   When (ItemFile.PER10 In (672,744)) Then ItemFile.Rate10
						   Else 0 End AS MonthlyRate,

					  qryTransactions.[DATE] AS DateOut, 
					  qryTransactions.[TIME] AS TimeOut, 
					  IIf(Left(qryTransactionItems.TXTY,1)='S',
					     Null,
						 IsNull(qryTransactionItems.[DDT],qryTransactions.[Date])) AS DateIn, 
					  IIf(Left(qryTransactionItems.TXTY,1)='S',
					     Null,
						 Iif(IsNull(qryTransactionItems.DTM,'') = '', qryTransactions.[TIME], qryTransactionItems.DTM)) AS TimeIn, 
					  IIf(Left(qryTransactions.STAT,1) In ('C',' '),
					     qryTransactions.CLDT,
						 Null) AS InvoiceDate, 
					  Null AS InvoiceTime, 
					  IIf(Left(qryTransactionItems.TXTY,1)='S',
					     Null,
						 ItemFile.PER1) AS HoursForMin, 
					  qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount AS RentalAmount, 
					  IIf(qryTransactions.DamageWaiverExempt=0,
					     (qryTransactionItems.PRIC*(qryTransactionItems.DmgWvr*0.01)),
						 0) AS LDWCharge, 
					  qryTransactions.TOTL AS TotalAmount, 
					  IIf(Left(qryTransactionItems.TXTY,1)='S',
					     Null,
						 IsNull(qryTransactionItems.[DDT],qryTransactions.[Date])) AS ReturnDate,
					  IIf(Left(qryTransactionItems.TXTY,1)='S',
					     Null,
						 Iif(IsNull(qryTransactionItems.DTM,'') = '', qryTransactions.[TIME], qryTransactionItems.DTM)) AS ReturnTime, 
					  Cast(IIf(isnull(qryTransactionItems.HRSC,0)=0,
					          0,
						      DateDiff(hh,
								Cast(Convert(varchar,qryTransactions.[DATE],101) + ' ' + Format(Cast(qryTransactions.[TIME] as Integer), IIf(cast(qryTransactions.[TIME] as Integer)>1199,'##:00PM','00:00AM')) as DateTime),
							    Cast(Convert(varchar,IsNull(qryTransactionItems.[DDT],qryTransactions.[Date]),101) + ' ' + Format(Cast(Iif(IsNull(qryTransactionItems.DTM,'') = '', qryTransactions.[TIME], qryTransactionItems.DTM) as Integer), IIf(cast(Iif(IsNull(qryTransactionItems.DTM,'') = '', qryTransactions.[TIME], qryTransactionItems.DTM) as Integer)>1199,'##:00PM','00:00AM')) as DateTime))/24) as Int) AS DaysRent, 
					  IIf(Substring(qryTransactionItems.TXTY,1,1)='R',
					      cast((IIf((IsNull(qryTransactionItems.HRSC,0)=0),
						           0,
								   DateDiff(hh,
								     Cast(Convert(varchar,qryTransactions.[DATE],101) + ' ' + Format(Cast(qryTransactions.[TIME] as Integer),IIf(cast(qryTransactions.[Time] as Integer)>1199,'##:00PM','00:00AM')) as DateTime),
									 Cast(Convert(varchar,IsNull(qryTransactionItems.[DDT],qryTransactions.[Date]),101) + ' ' + Format(Cast(Iif(IsNull(qryTransactionItems.DTM,'') = '', qryTransactions.[TIME], qryTransactionItems.DTM) as Integer),IIf(Cast(Iif(IsNull(qryTransactionItems.DTM,'') = '', qryTransactions.[TIME], qryTransactionItems.DTM) as Integer)>1199,'##:00PM','00:00AM')) as DateTime))/24))
								-(Cast(DateDiff(hh,
								        Cast(Convert(varchar,qryTransactions.[DATE],101) + ' ' + Format(Cast(qryTransactions.[TIME] as Integer),IIf(Cast(qryTransactions.[Time] as Integer)>1199,'##:00PM','00:00AM')) as DateTime),
										Cast(Convert(varchar,IsNull(qryTransactionItems.[DDT],qryTransactions.[Date]),101) + ' ' + Format(Cast(Iif(IsNull(qryTransactionItems.DTM,'') = '', qryTransactions.[TIME], qryTransactionItems.DTM) as Integer), IIf(Cast(Iif(IsNull(qryTransactionItems.DTM,'') = '', qryTransactions.[TIME], qryTransactionItems.DTM) as Integer)>1199,'##:00PM','00:00AM')) as DateTime)) as Int)/24) as Int)*24,
						   0) AS HoursRent, 
					  Null AS EmployeeClose, 
					  qryTransactions.Salesman AS SalesREpIDNo, 
					  Null AS RateUsed, 
					  qryTransactions.DATE AS CycleBillFrom, 
					  IIf(Left(qryTransactionItems.TXTY,1)='S',
					     qryTransactions.CLDT,
						 IsNull(qryTransactionItems.[DDT],qryTransactions.[Date])) AS CycleBillTo, 
					  cast(qryTransactionItems.RainHours/24 as Int) AS CreditDays, 
					  cast((qryTransactionItems.RainHours/24)-cast((qryTransactionItems.RainHours/24) as Int)*24 as Int) AS CreditHours, 
					  Null AS CreditReason, 
					  IIf(qryTransactions.CONT='',
						 1,
						 Cast((DateDiff(d,
							qryTransactions.CMDT,
							IIf(Left(qryTransactionItems.TXTY,1)='S',
							   qryTransactions.CLDT,
							   IsNull(qryTransactionItems.[DDT],qryTransactions.[Date]))+1)/28)+0.999999 as Int)) AS CycleBillNo, 
					  IIf(ItemFile.TYPE<>'H',
						 0,
						 IIf(isnull(qryTransactionItems.HRSC,0)=0,
							0,
							DateDiff(hh,
							  Cast(Convert(varchar,qryTransactions.[DATE],101) + ' ' + Format(Cast(qryTransactions.[Time] as Integer),IIf(Cast(qryTransactions.[Time] as Integer)>1199,'##:00PM','00:00AM')) as DateTime),
							  Cast(Convert(varchar,IsNull(qryTransactionItems.[DDT],qryTransactions.[Date]),101) + ' ' + Format(Cast(Iif(IsNull(qryTransactionItems.DTM,'') = '', qryTransactions.[TIME], qryTransactionItems.DTM) as Integer),IIf(Cast(Iif(IsNull(qryTransactionItems.DTM,'') = '', qryTransactions.[TIME], qryTransactionItems.DTM) as Integer)>1199,'##:00PM','00:00AM')) as DateTime)))-qryTransactionItems.HRSC)*-1 AS ExcessMileageCharge, 
					  Null AS ShiftDiff, 
					  qryTransactions.DeliveryZip AS JobSiteZip, 
					  qryTransactionItems.HRSC AS InvoiceOption1, 
					  qryTransactionItems.DiscountAmount AS InvoiceOption2, 
					  qryTransactionItems.DiscountPercent AS InvoiceOption3, 
					  Salesman.Name AS InvoiceOption4, 
					  CustomerFile.NAME AS InvoiceOption5, 
					  iif(left(qryTransactionItems.CNTR,1)='s',
						 (qryTransactionItems.SubrentQuantity*-1),
						 qryTransactionItems.SubrentQuantity) AS InvoiceOption6, 
					  cast(qryTransactionItems.DmgWvr as decimal) AS InvoiceOption7,
					  cast(qryTransactionItems.ItemPercentage as decimal) AS InvoiceOption8, 
					  Null AS InvoiceOption9, 
					  Null AS InvoiceOption10, 
					  IIf(Left(qryTransactionItems.TXTY,1)='S',
						 Null,
						 ItemFile.Rate1) AS MinimumBookRate,
					  Case When (Left(qryTransactionItems.TXTY,1)='S') Then Null
						   When (ItemFile.PER1=24) Then ItemFile.Rate1
						   When (ItemFile.PER2=24) Then ItemFile.Rate2
						   When (ItemFile.PER3=24) Then ItemFile.Rate3
						   When (ItemFile.PER4=24) Then ItemFile.Rate4
						   When (ItemFile.PER5=24) Then ItemFile.Rate5
						   When (ItemFile.PER6=24) Then ItemFile.Rate6
						   When (ItemFile.PER7=24) Then ItemFile.Rate7
						   When (ItemFile.PER8=24) Then ItemFile.Rate8
						   When (ItemFile.PER9=24) Then ItemFile.Rate9
						   When (ItemFile.PER10=24) Then ItemFile.Rate10
						   Else 0 End AS DailyBookRate,
					  Case When (Left(qryTransactionItems.TXTY,1)='S') Then Null
						   When (ItemFile.PER1=168) Then ItemFile.Rate1
						   When (ItemFile.PER2=168) Then ItemFile.Rate2
						   When (ItemFile.PER3=168) Then ItemFile.Rate3
						   When (ItemFile.PER4=168) Then ItemFile.Rate4
						   When (ItemFile.PER5=168) Then ItemFile.Rate5
						   When (ItemFile.PER6=168) Then ItemFile.Rate6
						   When (ItemFile.PER7=168) Then ItemFile.Rate7
						   When (ItemFile.PER8=168) Then ItemFile.Rate8
						   When (ItemFile.PER9=168) Then ItemFile.Rate9
						   When (ItemFile.PER10=168) Then ItemFile.Rate10
						   Else 0 End AS WeeklyBookRate,
					  Case When (Left(qryTransactionItems.TXTY,1)='S') Then Null
						   When (ItemFile.PER1 In (672,744)) Then ItemFile.Rate1
						   When (ItemFile.PER2 In (672,744)) Then ItemFile.Rate2
						   When (ItemFile.PER3 In (672,744)) Then ItemFile.Rate3
						   When (ItemFile.PER4 In (672,744)) Then ItemFile.Rate4
						   When (ItemFile.PER5 In (672,744)) Then ItemFile.Rate5
						   When (ItemFile.PER6 In (672,744)) Then ItemFile.Rate6
						   When (ItemFile.PER7 In (672,744)) Then ItemFile.Rate7
						   When (ItemFile.PER8 In (672,744)) Then ItemFile.Rate8
						   When (ItemFile.PER9 In (672,744)) Then ItemFile.Rate9
						   When (ItemFile.PER10 In (672,744)) Then ItemFile.Rate10
						   Else 0 End AS MonthlyBookRate,
					  ItemFile.[KEY] AS KeyIdNo, 
					  qryTransactionItems.Comments AS TransLineComments,
					  iif(MinimumAmount+DailyAmount+WeeklyAmount+MonthlyAmount=0,0,1) As IsContractPricing, 
					  iif(ItemFile.PER1=0,0,(ItemFile.RATE1/ItemFile.PER1)) AS HourlyBookRate 

              INTO TempDB.dbo.RouseInvoiceDetailFile 
			  FROM ((((qryTransactionItems 
			  LEFT JOIN qryTransactions ON qryTransactionItems.CNTR = qryTransactions.CNTR)
              LEFT JOIN ItemFile ON qryTransactionItems.ITEM = ItemFile.NUM) 
			  LEFT JOIN ItemFile AS ItemFile_1 ON ItemFile.Header = ItemFile_1.[KEY]) 
			  LEFT JOIN Salesman ON qryTransactions.Salesman = Salesman.Number) 
			  LEFT JOIN CustomerFile ON qryTransactions.CUSN = CustomerFile.CNUM 
			 WHERE IIf(substring(qryTransactions.STAT,1,1) In ('C',' '),
			            qryTransactions.CLDT,
						Null) Between DateAdd(d,-Day(getDate())+1,DateAdd(m,-6,getDate())) And getDate() 
			   AND Left(qryTransactionItems.CNTR,1) Not In ('f','h','l','r','t','w') 
			   AND qryTransactions.STAT Not In (' C') 
			 ORDER BY qryTransactionItems.CNTR, 
					  qryTransactionItems.SUBF;

            SELECT (SELECT Max(VendorFile.AccountNumber) AS AccountNumber FROM VendorFile WHERE (((VendorFile.VendorName)='Rouse Analytics'))) AS ClientCode, 
			        ItemFile.NUM AS EquipmentIDNo, 
					IIf(ItemFile.Type In ('S','F','M','E'),
					   IIf(Substring(itemfile.[key],1,1)='|',
					      'Y',
						  IIf(itemfile.name Like '%fuel%',
						     'Z',
							 ItemFile.Type)),
					   ItemFile.Type) AS EquipmentType, 
			  ItemCategory.Category AS Category, 
			  IIf(Rtrim(IsNull([itemfile].[header],''))='',
			     [ItemFile].[NUM],
				 IIf(([itemfile_1].[NUM] Is Null),
				    'Error in' + [ItemFile].[NUM],
				    [ItemFile_1].[NUM])) AS ProductType, 
			  ItemFile.CurrentStore AS LocationCode, 
			  ItemFile.HomeStore AS LocationOption1, 
			  ItemFile.CurrentStore AS LocationOption2, 
			  ItemFile.PURD AS AcquisitionDate, 
			  ItemFile.PURD AS DatePutInRental, 
			  ItemFile.MANF AS Make, 
			  SUBSTRING(IIf([ItemFile].[MODN]='',
			     Cast([ItemComments].[Specs] as Varchar(Max)),
				 [ItemFile].[MODN]),1,255)  AS Model, 
			  ItemFile.SerialNumber AS SerialNo, 
			  ItemFile.ModelYear AS ModelYear,
              [ItemFile].[PURP]+[ItemFile].[ExtraCharges] AS Cost, 
			  ItemFile.CURV AS CostOption1, 
			  Null AS CostOpton2, 
			  ItemFile.ReplacementCost AS CostOption3, 
			  IIf([ItemFile].[QYOT]=0, 'A',
				IIf(XFER.TContract Is Not Null, 'I',
				  IIF(Substring([ItemFile].[CNTR],1,1)='R','R',
				    IIF(Trans.TXTY = 'RH','H','O')))) AS Status, 
			  Null AS StatusOption1, 
			  ItemFile.LDATE AS LastTransacitonDate, 
			  IIf(XFER.TContract Is Not Null, XFER.TContract, ItemFile.CNTR) AS LastTransactionInvoice,  
			  GetDate() AS RecordDate, 
			  IsNull(ItemEngine.Repowered,0) AS RefurbFlag, 
			  ItemEngine.DateRepowered AS RefurbDate, 
			  Null AS ParentIDNo, 
			  ItemFile.SOLD AS EquipmentOption1, 
			  Null AS EquipmentOption2, 
			  Null AS EquipmentOption3, 
			  Null AS EquipmentOption4, 
			  ItemFile.[KEY] AS EquipmentOption5, 
			  ItemFile.[INC3] AS EquipmentOption6,
			  ItemFile.[QTY] As Quantity,
			  ItemFile.[Inactive] As IsNotActive,
			  [ItemFile].[REPC2]  As LifeToDateMaintenance,
			  [ItemFile].[MTIN] As MeterReading,
			  [ItemFile].[CURV] As NetBookValue,
			  [ItemFile].[SOLD] As SoldDate,
			  [ItemFile].[SAMT] As SoldPrice,
			  Null As SoldCustomerName,
			  Null As SoldCustomerNumber,
			  IIF([ItemsForSale].[NUM] Is Null, 0, 1) As ForSaleFlag,
			  [ItemFile].[SELL] As AskingPrice
		 INTO TempDB.dbo.RouseEquipmentMasterFile
		 FROM (((((ItemCategory 
        RIGHT JOIN ItemFile ON ItemCategory.Category = ItemFile.Category) 
         LEFT JOIN ItemFile AS ItemFile_1 ON ItemFile.Header = ItemFile_1.[KEY]) 
         LEFT JOIN ItemEngine ON ItemFile.NUM = ItemEngine.Num)
         LEFT JOIN ItemComments ON ItemFile.NUM = ItemComments.NUM)
         LEFT JOIN ItemsForSale ON ItemFile.NUM = ItemsForSale.NUM)
         LEFT JOIN (
                    SELECT TI.Item, Max(TI.TXTY) AS TXTY
                            FROM TransactionItems TI
                           INNER JOIN Transactions T ON T.CNTR = TI.CNTR
                            WHERE left(T.STAT,1) = 'O' AND left(TXTY,1) = 'R'
                            GROUP BY TI.Item) AS Trans ON ItemFile.Num = Trans.Item
		 LEFT JOIN (
					Select TI.Item, max(TI.CNTR) AS TContract
					  From TransactionItems TI 
					 Inner Join Transactions T ON TI.CNTR = T.CNTR
					 Where TI.TXTY = 'R' and T.[Status] = 'O' and left(TI.CNTR,1) = 't' 
					 Group By TI.Item) AS XFER ON ItemFile.NUM = XFER.Item
		WHERE (((ItemFile.TYPE) Not In ('K','P','I'))) 
	    ORDER BY IIf(ItemFile.Type In ('S','F','M','E'),
		            IIf(Left(itemfile.[key],1)='|',
					   'Y',
					   IIf(itemfile.name Like '%fuel%',
					      'Z',
						  ItemFile.Type)),
				    ItemFile.Type);

            SELECT (SELECT Max(VendorFile.AccountNumber) AS AccountNumber FROM VendorFile WHERE (((VendorFile.VendorName)='Rouse Analytics'))) AS ClientCode, 
			        qryTransactions.STR AS Store, 
					Month(qryTransactions.CLDT) AS [Date], 
					Sum((IIf(Substring(qryTransactionItems.CNTR,1,1)<>'s', 
							IIf(Left(qryTransactionItems.ContractLink,1)<>'s',
							   IIf(Left(qryTransactionItems.TXTY,1)='R',
							      IIf(ItemFile.Type In ('T','H','U','V','A''L','D'),
							 	     (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
									 0),
					 			  0),
				 			   0),
						    0))) AS CoreRentalRevenue, 
					Sum((IIf(Left(qryTransactionItems.CNTR,1)<>'s',
					        IIf(SubString(qryTransactionItems.ContractLink,1,1)='s',
							   (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
							   0),
					        0))) AS ReRentRevenue, 
					Sum((IIf(Left(qryTransactionItems.CNTR,1)='s',
					        (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
							0))) AS ReRentCost, 
					Sum((IIf(Left(qryTransactionItems.CNTR,1)<>'s',
							IIf(qryTransactions.DamageWaiverExempt=0,
							   IIf(ItemFile.Type In ('T','H','U','V','A''L','D'),
							   (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount)*(qryTransactionItems.DmgWvr*0.01),0),0),0))) AS LDWRevenue, 
					Sum((IIf(Left(qryTransactionItems.CNTR,1)<>'s', 
						    IIf(qryTransactionItems.ItemPercentage <>0,
							   IIf(ParameterFile.ItemPercentageName Like '%enviro%',
							      IIf(ItemFile.Name Like '%enviro%',
								     (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount)+((qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount)*(qryTransactionItems.ItemPercentage*0.01)),
									 (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount)*(qryTransactionItems.ItemPercentage*0.01)),
								  IIf(ItemFile.Name Like '%enviro%',
								     (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
									 0)),
							   IIf(ItemFile.Name Like '%enviro%',
							      (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
								  0)),
							0))) AS EnviromentalFees,
					Sum((IIf(Substring(qryTransactionItems.CNTR,1,1)<>'s',
						    IIf(Substring(ItemFile.[Key],1,1)='|',
							   (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
							   0),
							0))) AS DeliveryPickupRevenue, 
					Sum((IIf(Substring(qryTransactionItems.CNTR,1,1)<>'s',
							IIf(ItemFile.Name Like '%fuel%',
								(qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
								0),
							0))) AS FuelCharges 
			  INTO TempDB.dbo.RouseCredits
			  FROM ((qryTransactionItems 
			 INNER JOIN qryTransactions ON qryTransactionItems.CNTR = qryTransactions.CNTR) 
			 INNER JOIN ItemFile ON qryTransactionItems.ITEM = ItemFile.NUM) 
			 INNER JOIN ParameterFile ON qryTransactions.STR = ParameterFile.Store 
			 WHERE (((qryTransactions.CLDT) Between DateAdd(d,-Day(GetDate())+1,DateAdd(m,-6,GetDate())) And GetDate()) 
			   AND ((qryTransactionItems.PRIC)<0) 
			   AND ((qryTransactionItems.CNTR) Not In ('f','l','q','r','t','w'))) 
			 GROUP BY qryTransactions.STR, 
					  Month(qryTransactions.CLDT) 
			 ORDER BY qryTransactions.STR, 
			          Month(qryTransactions.CLDT);

            SELECT (SELECT Max(VendorFile.AccountNumber) AS AccountNumber FROM VendorFile WHERE (((VendorFile.VendorName)='Rouse Analytics'))) AS ClientCode, 
			qryTransactions.STR AS Store, 
			Month(qryTransactions.CLDT) AS [Date], 
			Sum(IIf(Substring(qryTransactionItems.CNTR,1,1)<>'s',
			       IIf(Substring(qryTransactionItems.ContractLink,1,1)<>'s',
				      IIf(Substring(qryTransactionItems.TXTY,1,1)='R',
					     IIf(ItemFile.Type In ('T','H','U','V','A''L','D'),
					        (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
						    0),
					     0),
					  0),
				   0)) AS CoreRentalRevenue, 
			Sum(IIf(Substring(qryTransactionItems.CNTR,1,1)<>'s',
			       IIf(Substring(qryTransactionItems.ContractLink,1,1)='s',
				      (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
					  0),
				   0)) AS ReRentRevenue, 
			Sum(IIf(Substring(qryTransactionItems.CNTR,1,1)='s',
			   (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
			   0)) AS ReRentCost,
            Sum(IIf(Substring(qryTransactionItems.CNTR,1,1)<>'s',
			       IIf(qryTransactions.DamageWaiverExempt=0,
				      (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount)*(qryTransactionItems.DmgWvr*0.01),
					  0),
				   0)) AS LDWRevenue, 
		    Sum(IIf(Substring(qryTransactionItems.CNTR,1,1)<>'s',
				   IIf(qryTransactionItems.ItemPercentage<>0, 
					  IIf(ParameterFile.ItemPercentageName Like '%enviro%',
					     IIf(ItemFile.Name Like '%enviro%',
					        (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount)+((qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount)*(qryTransactionItems.ItemPercentage*0.01)),
						    (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount)*(qryTransactionItems.ItemPercentage*0.01)),
					     IIf(ItemFile.Name Like '%enviro%',
						    (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
							0)),
					  IIf(ItemFile.Name Like '%enviro%',
					     (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
						 0)),
				   0)) AS EnviromentalFees,
               Sum(IIf(Substring(qryTransactionItems.CNTR,1,1)<>'s',
				      IIf(Substring(ItemFile.[Key],1,1)='|',
					     (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
					     0),
					  0)) AS DeliveryPickupRevenue, 
			   Sum(IIf(Substring(qryTransactionItems.CNTR,1,1)<>'s',
			          IIf(ItemFile.Name Like '%fuel%',
					     (qryTransactionItems.PRIC-qryTransactionItems.DiscountAmount),
					     0),
					  0)) AS FuelCharges  
		 INTO TempDB.dbo.RouseAncillaryFeesA
		 FROM ((qryTransactionItems 
		INNER JOIN qryTransactions ON qryTransactionItems.CNTR = qryTransactions.CNTR)
		INNER JOIN ItemFile ON qryTransactionItems.ITEM = ItemFile.NUM) 
		INNER JOIN ParameterFile ON qryTransactions.STR = ParameterFile.Store 
		WHERE (((qryTransactions.CLDT) Between DateAdd(d,-Day(GetDate())+1,DateAdd(m,-6,GetDate())) And GetDate()) 
		  AND ((qryTransactionItems.PRIC)>0) 
		  AND ((qryTransactionItems.CNTR) Not In ('f','l','q','r','t','w'))) 
	    GROUP BY qryTransactions.STR, 
		         Month(qryTransactions.CLDT) 
	    ORDER BY qryTransactions.STR, 
		         Month(qryTransactions.CLDT);

        SELECT (SELECT Max(VendorFile.AccountNumber) AS AccountNumber FROM VendorFile WHERE (((VendorFile.VendorName)='Rouse Analytics'))) AS ClientCode, 
		       ParameterFile.Store AS LocationCode, 
			   GetDate() AS DateProduced, 
			   [RouseStoresMonths].[Date] AS MonthData, 
			   cast(Null as varchar) AS ClientLocationGroup1, 
			   cast(Null as varchar) AS ClientLocationGroup2, 
			   ParameterFile.STORE_STRT AS Address, 
			   RTRIM(LTRIM(
			   IIf(CharIndex(',',ParameterFile.STORE_CITY)>1,
			     Substring(ParameterFile.STORE_CITY,1, CharIndex(',',ParameterFile.STORE_CITY)-1),
				 Parameterfile.STORE_CITY))) as City,
			   Substring(RTRIM(ParameterFile.STORE_CITY), Len(ParameterFile.STORE_CITY)-1, 2) AS State,
			   ParameterFile.STORE_ZIP AS ZipCode, 
			   Sum([RouseAncillaryFeesA].CoreRentalRevenue) AS CoreRentalRevenue,
               Sum([RouseCredits].CoreRentalRevenue) AS CreditCoreRentalRevenue, 
			   cast(Null as varchar) AS Discounts, 
			   Sum([RouseAncillaryFeesA].ReRentRevenue) AS ReRentRevenue, 
			   Sum([RouseCredits].ReRentRevenue) AS CreditReRentRevenue, 
			   Sum([RouseAncillaryFeesA].ReRentCost) AS ReREntCost, 
			   cast(Null as varchar) AS AncillaryFees, 
			   Sum([RouseAncillaryFeesA].LDWRevenue) AS LDWRevenue, 
			   Sum([RouseCredits].LDWRevenue) AS CreditLDWRevenue, 
			   Sum([RouseAncillaryFeesA].EnviromentalFees) AS EnviromenalFees, 
			   Sum([RouseCredits].EnviromentalFees) AS CreditEnviromentalFees, 
			   Sum([RouseAncillaryFeesA].DeliveryPickupRevenue) AS DeliveryPickupRevenue, 
			   Sum([RouseCredits].DeliveryPickupRevenue) AS CreditDeliveryPickupRevenue, 
			   Sum([RouseAncillaryFeesA].FuelCharges) AS FuelCharges, 
			   Sum([RouseCredits].FuelCharges) AS CreditFuelCharges, 
			   cast(Null as varchar) AS LocationOption1, 
			   cast(Null as varchar) AS LocationOption2 
		  INTO TempDB.dbo.RouseBranchFile 
		  FROM ((ParameterFile 
		  LEFT JOIN TempDB.dbo.RouseStoresMonths ON ParameterFile.Store = [RouseStoresMonths].Store) 
		  LEFT JOIN TempDB.dbo.RouseCredits ON ([RouseStoresMonths].Store = [RouseCredits].Store) AND ([RouseStoresMonths].[Date] = [RouseCredits].[Date])) 
		  LEFT JOIN TempDB.dbo.RouseAncillaryFeesA ON ([RouseStoresMonths].Date = [RouseAncillaryFeesA].Date) AND ([RouseStoresMonths].Store = [RouseAncillaryFeesA].Store) 
		  GROUP BY ParameterFile.Store, 
				   [RouseStoresMonths].[Date], 
				   --Null, 
				   --Null, 
				   ParameterFile.STORE_STRT,
				   ParameterFile.STORE_CITY, --Not in Original
			  -- IIf(CharIndex(',',ParameterFile.STORE_CITY)>1,
			  --   Substring(ParameterFile.STORE_CITY,1, CharIndex(',',ParameterFile.STORE_CITY)-1),
				 --Parameterfile.STORE_CITY),
				 --  IIf(Charindex(',  ',ParameterFile.STORE_CITY)>1,
				 --     Substring(ParameterFile.STORE_CITY,Charindex(',',ParameterFile.STORE_CITY)+3,Len(ParameterFile.STORE_CITY)),
					--  IIf(Charindex(', ',ParameterFile.STORE_CITY)>1,
					--     Substring(ParameterFile.STORE_CITY,Charindex(',',ParameterFile.STORE_CITY)+2,Len(ParameterFile.STORE_CITY)),
					--     IIf(Charindex(', ',ParameterFile.STORE_CITY)>1,
					--	    Substring(ParameterFile.STORE_CITY,Charindex(',',ParameterFile.STORE_CITY)+3,Len(ParameterFile.STORE_CITY)),
					--		'Error'))),
				   ParameterFile.STORE_ZIP;

-- ProductTypeRateFile
-- 1) Special rates on Item
SELECT (SELECT Max(VendorFile.AccountNumber) AS AccountNumber 
          FROM VendorFile 
         WHERE (((VendorFile.VendorName)='Rouse Analytics'))) AS ClientCode, 
	   ItemRates.[Store] AS LocationCode,
	   ItemFile.[NUM] AS ProductType,
	   ItemRates.MinimumAmount AS MinimumBookRate,
	   ItemRates.[DailyAmount] AS DailyBookRate, 
	   ItemRates.[WeeklyAmount] AS WeeklyBookRate,
	   ItemRates.[MonthlyAmount] AS MonthlyBookRate,
	   NULL AS MonthlyFloorRate,
	   NULL AS WeeklyFloorRate, 
	   NULL AS DailyFloorRate
  INTO TempDB.dbo.RouseProductTypeRateFile 
  FROM ItemFile 
 INNER JOIN (SELECT ItemRates.[Rate], ItemRates.[NUM], ItemRates.[MinimumAmount], ItemRates.[DailyAmount], ItemRates.[WeeklyAmount], ItemRates.[MonthlyAmount], ItemRates.[Store] 
               FROM ItemRates 
  			  WHERE ItemRates.[StartDate] <= cast(getdate() as date) 
			    AND ItemRates.[EndDate] >= cast(getdate() as date)
			    AND ItemRates.[Store] Is Not Null 
			    AND ItemRates.[Store] Not In ('')) AS ItemRates ON ItemFile.[NUM] = ItemRates.[NUM]
-- 06/24/2019  JY  (2989) 
-- WHERE ItemFile.[TYPE] In ('T','H','U','A','L') 
  WHERE (ItemFile.[TYPE] In ('T','H','U','A','L') AND (rtrim(ltrim(ItemFile.Header)) = '' or ItemFile.Header Is Null)) 
	 OR (ItemFile.[TYPE] In ('V'))

UNION

-- 06/24/2019  JY  (2989) Remove rates on Header
-- 2) Special rates on Header
--SELECT (SELECT Max(VendorFile.AccountNumber) AS AccountNumber 
--FROM VendorFile 
-- WHERE (((VendorFile.VendorName)='Rouse Analytics'))) AS ClientCode, 
--ItemRates_H.[Store] AS LocationCode,

--ItemFile.[NUM] AS ProductType,
--ItemRates_H.MinimumAmount AS MinimumBookRate,
-- ItemRates_H.[DailyAmount] AS DailyBookRate, 
--ItemRates_H.[WeeklyAmount] AS WeeklyBookRate,
--ItemRates_H.[MonthlyAmount] AS MonthlyBookRate,
--NULL AS MonthlyFloorRate,
--NULL AS WeeklyFloorRate, 
--NULL AS DailyFloorRate
  
--FROM ItemFile 
--INNER JOIN ItemFile ItemFile_H ON ItemFile.Header = ItemFile_H.[KEY]
--INNER JOIN (SELECT ItemRates.[Rate], ItemRates.[NUM], ItemRates.[MinimumAmount], ItemRates.[DailyAmount], ItemRates.[WeeklyAmount], ItemRates.[MonthlyAmount], ItemRates.[Store] 
--FROM ItemRates 
--WHERE ItemRates.[StartDate] <= GetDate() 
--AND ItemRates.[EndDate] >= GetDate() 
--AND ItemRates.[Store] Is Not Null 
--AND ItemRates.[Store] Not In ('','000')) AS ItemRates_H ON ItemFile_H.NUM = ItemRates_H.NUM
--LEFT JOIN (SELECT ItemRates.[Rate], ItemRates.[Num] 
--FROM ItemRates 
--WHERE ItemRates.[StartDate] <= cast(getdate() as date) 
--AND ItemRates.[EndDate] >= cast(getdate() as date)
--AND ItemRates.[Store] Is Not Null 
--AND ItemRates.[Store] Not In ('')) AS ItemRates ON ItemFile.[NUM] = ItemRates.[NUM]
-- WHERE ItemFile.[TYPE] In ('T','H','U','A','L') 
-- and ItemRates.Rate is Null
--UNION
-- 3) Add regular rates on Item
SELECT (SELECT Max(VendorFile.AccountNumber) AS AccountNumber 
		  FROM VendorFile 
		 WHERE (((VendorFile.VendorName)='Rouse Analytics'))) AS ClientCode, 
		 '000' AS LocationCode,
	   ItemFile.[NUM] AS ProductType,
	   CASE 
			WHEN ItemFile.[Per1]<24 THEN ItemFile.[Rate1]
	   ELSE 0
			END AS MinimumBookRate,
	   CASE
			WHEN ItemFile.[Per1]=24 THEN ItemFile.[Rate1] 
			WHEN ItemFile.[Per2]=24 THEN ItemFile.[RATE2] 
			WHEN ItemFile.[Per3]=24 THEN ItemFile.[RATE3] 
			WHEN ItemFile.[Per4]=24 THEN ItemFile.[RATE4] 
			WHEN ItemFile.[PER5]=24 THEN ItemFile.[RATE5] 
			WHEN ItemFile.[Per6]=24 THEN ItemFile.[Rate6] 
			WHEN ItemFile.[Per7]=24 THEN ItemFile.[Rate7] 
			WHEN ItemFile.[Per8]=24 THEN ItemFile.[RATE8] 
			WHEN ItemFile.[Per9]=24 THEN ItemFile.[Rate9] 
			WHEN ItemFile.[Per10]=24 THEN ItemFile.[Rate10] 
	   ELSE 0
			END AS DailyBookRate, 
	   CASE
			WHEN ItemFile.[Per1]=168 THEN ItemFile.[Rate1] 
			WHEN ItemFile.[Per2]=168 THEN ItemFile.[RATE2] 
			WHEN ItemFile.[Per3]=168 THEN ItemFile.[RATE3] 
			WHEN ItemFile.[Per4]=168 THEN ItemFile.[RATE4] 
			WHEN ItemFile.[PER5]=168 THEN ItemFile.[RATE5] 
			WHEN ItemFile.[Per6]=168 THEN ItemFile.[Rate6] 
			WHEN ItemFile.[Per7]=168 THEN ItemFile.[Rate7] 
			WHEN ItemFile.[Per8]=168 THEN ItemFile.[RATE8] 
			WHEN ItemFile.[Per9]=168 THEN ItemFile.[Rate9] 
			WHEN ItemFile.[Per10]=168 THEN ItemFile.[Rate10] 
	   ELSE 0
			END AS WeeklyBookRate,
	   CASE
			WHEN ItemFile.[Per1] In (672,744) THEN ItemFile.[Rate1] 
			WHEN ItemFile.[Per2] In (672,744) THEN ItemFile.[RATE2] 
			WHEN ItemFile.[Per3] In (672,744) THEN ItemFile.[RATE3] 
			WHEN ItemFile.[Per4] In (672,744) THEN ItemFile.[RATE4] 
			WHEN ItemFile.[PER5] In (672,744) THEN ItemFile.[RATE5] 
			WHEN ItemFile.[Per6] In (672,744) THEN ItemFile.[Rate6] 
			WHEN ItemFile.[Per7] In (672,744) THEN ItemFile.[Rate7] 
			WHEN ItemFile.[Per8] In (672,744) THEN ItemFile.[RATE8] 
			WHEN ItemFile.[Per9] In (672,744) THEN ItemFile.[Rate9] 
			WHEN ItemFile.[Per10] In (672,744) THEN ItemFile.[Rate10] 
	   ELSE 0
			END AS MonthlyBookRate,
	   NULL AS MonthlyFloorRate,
	   NULL AS WeeklyFloorRate, 
	   NULL AS DailyFloorRate
  FROM ItemFile 
-- 06/24/2019  JY  (2989) 
-- WHERE ItemFile.[TYPE] In ('T','H','U','A','L') 
  WHERE (ItemFile.[TYPE] In ('T','H','U','A','L') AND (rtrim(ltrim(ItemFile.Header)) = '' or ItemFile.Header Is Null)) 
	 OR (ItemFile.[TYPE] In ('V'))

		 SET NOCOUNT OFF
END


go

