
CREATE PROCEDURE DBO.spGetPivot_PutSoldAsset
(
	@sItemNumber		VARCHAR(6),
	@bCapitalizeExtra	TINYINT
)

AS

/*************************************************************************/
--	POR.DBO.spGetPivot_ItemIncomeHistory
--		Returns a table with totals summarized by month, pivoted on year
--
--	PARAMETERS: @sItemNumber		- target Item
--				@bCapitalizeExtra	- Capitalize Extra Charges T/F
--
--	HISTORY:	10/24/2014	JY	CREATED									 
--
--
/*************************************************************************/

BEGIN
SET NOCOUNT ON

DECLARE @sSQL VARCHAR(1500)
DECLARE @sItemSelect VARCHAR(1500)
DECLARE @sColumns AS VARCHAR(MAX)

/*
	lvSQL = "Transform Sum( (QuantityPurchased-QuantitySold)*(PriceEach)) AS TotalPrice " & _
        "Select ItemNumber,  Sum( (QuantityPurchased-QuantitySold)*(PriceEach)) AS TotalLinePrice " & _
        "From ItemPurchaseDetail Where ItemNumber = '" & ItemNumber & "' " & _
        "Group By ItemNumber " & _
        "Pivot [PurchaseDate]"

		ItemNumber	TotalLinePrice	5/1/1982	7/1/1996	10/4/2008	5/10/2012
			81			120				0			0			120			0
*/

--DECLARE @SITEMNUMBER VARCHAR(6), @BCAPITALIZEEXTRA TINYINT
--SET @SITEMNUMBER = '    81'
--SET @bCapitalizeExtra = 1

CREATE TABLE #TMP_PURCHASE
(
	[ITEMNUMBER]		VARCHAR(6),
	[PURCHASEDATE]		VARCHAR(10),
	[DTPURCHASE]		DATETIME,
	[TOTALLINEPRICE]	MONEY
)

INSERT INTO #TMP_PURCHASE
	SELECT ITEMNUMBER, CONVERT(VARCHAR(10),PURCHASEDATE,101) AS PURCHASEDATE, PURCHASEDATE AS DTPURCHASE,
		   CASE WHEN (@bCapitalizeExtra = 1) 
					THEN (QuantityPurchased-QuantitySold)*(PriceEach + ExtraCharges) 
				ELSE (QuantityPurchased-QuantitySold)*(PriceEach) 
				END AS TotalLinePrice
	  FROM ItemPurchaseDetail
	 WHERE ItemNumber = @sItemNumber
	 ORDER BY PURCHASEDATE

--SELECT * FROM #TMP_PURCHASE

IF (@@ROWCOUNT > 0)
BEGIN
	-- Get a list of purchase dates for column names
	--select @sColumns = substring((Select DISTINCT ',' + QUOTENAME([PURCHASEDATE]) FROM #TMP_PURCHASE FOR XML PATH ('')),2, 1000) 

	DECLARE @PDATE DATETIME
	SET @PDATE = (SELECT MIN(DTPURCHASE) FROM #TMP_PURCHASE)
	WHILE (@PDATE IS NOT NULL)
	BEGIN
		SET @sColumns = ISNULL(@sColumns,'') + '[' + CONVERT(VARCHAR(10),@PDATE,101)+ ']' + ','
		SET @PDATE = (SELECT MIN(DTPURCHASE) FROM #TMP_PURCHASE WHERE DTPURCHASE > @PDATE)
	END

	SET @sColumns = left(@sColumns,Len(@scolumns)-1)

--SELECT @sColumns

	 ALTER TABLE #TMP_PURCHASE DROP COLUMN DTPURCHASE

	SELECT ITEMNUMBER, SUM(TOTALLINEPRICE) AS TOTALLINEPRICE
	  INTO #TMP_ROLLUP
	  FROM #TMP_PURCHASE
	 GROUP BY ITEMNUMBER
	 
	 set @SSQL =
		'SELECT *
		INTO #TMP_PIVOT1
		FROM #TMP_PURCHASE
		PIVOT 
		(
		  SUM([TOTALLINEPRICE]) 
		  FOR PURCHASEDATE IN(' + @sColumns + ')) as [TOTALLINEPRICE]; ' 

--		  SELECT @SSQL
--		execute(@ssql)

		-- add the monthly total column to the pivot table
		set @ssql = @ssql + 'SELECT P.[ITEMNUMBER], T.[TOTALLINEPRICE], ' + @sColumns + ' FROM #TMP_PIVOT1 P JOIN #TMP_ROLLUP T ON P.[ITEMNUMBER] = T.[ITEMNUMBER]'

--SELECT @SSQL

		execute(@ssql)

	DROP TABLE #TMP_ROLLUP

END

DROP TABLE #TMP_PURCHASE

SET NOCOUNT OFF

END

go

