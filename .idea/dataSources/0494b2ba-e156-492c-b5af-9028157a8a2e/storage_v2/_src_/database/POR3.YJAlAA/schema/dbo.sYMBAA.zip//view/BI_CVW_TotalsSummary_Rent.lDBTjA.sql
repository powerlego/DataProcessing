-- SQL Deploy  3/29/2018 8:38 AM
CREATE VIEW [dbo].[BI_CVW_TotalsSummary_Rent]
  AS
SELECT	SUMM.Date
, DATEPART(YY, SUMM.Date) as [Year]
, DATEPART(QQ, SUMM.Date) as [Quarter]
, DATEPART(MM, SUMM.Date) as [Month]
, DATENAME(MM, SUMM.Date) as [Month Name]
,SUMM.Store
,SUMM.[Cash AR]
,SUMM.[Account AR]
,SUMM.[Reservation Value]
,REV.[Rental Revenue]
,REV.[Damage Waiver Revenue]
,CSH.[Cash Flow]
,CNT.[New Contracts]
,ITEM.[Repair Costs]
FROM	(Select	Dates.Date, Dates.Store 
, (CashAmounts - (CashPayments + CashCredits)) as [Cash AR]
,(AccountAmounts - (AccountPayments + AccountCredits) ) as [Account AR]
, (ReservationValueMonth) As [Reservation Value]
from TotalsSummary a
INNER JOIN
(Select MAX(CONVERT(date, b.[Date], 126)) as [Date], Store
from TotalsSummary b 
group by DATEPART(yy, b.[Date]), DATEPART(mm, b.[Date]), Store) Dates
ON CONVERT(date, a.[Date], 126) = Dates.Date and a.Store = Dates.Store) SUMM
LEFT OUTER JOIN
(Select	MAX(CONVERT(date, [Date], 126)) as [Date], Store
, SUM(RentTx + RentNT) as [Rental Revenue]
, SUM(DwTx + DwNt) as [Damage Waiver Revenue]
from TotalsContractsAccrual
group by DATEPART(yy, [Date]), DATEPART(mm, [Date]), Store) REV
ON SUMM.Date = REV.Date and SUMM.Store = REV.Store
LEFT OUTER JOIN
(Select	MAX(CONVERT(date, [Date], 126)) as [Date], Store
, SUM(BNK + CRC + DebitCards + PNA) as [Cash Flow]
from TotalsCompare
group by DATEPART(yy, [Date]), DATEPART(mm, [Date]), Store) CSH
ON SUMM.Date = CSH.Date and SUMM.Store = CSH.Store
LEFT OUTER JOIN
(Select	MAX(CONVERT(date, [Date], 126)) as [Date], Store
, Count(CNTR) as [New Contracts] 
from TransactionEdit
where Code = 'O' and Not LTRIM(Stat) = 'Q'
group by DATEPART(yy, [Date]), DATEPART(mm, [Date]), Store) CNT
ON SUMM.Date = CNT.Date and SUMM.Store = CNT.Store
LEFT OUTER JOIN	
(Select	MAX(CONVERT(date, [Date], 126)) as [Date], b.CurrentStore as [Store]
, SUM(Repairs) as [Repair Costs]
from ItemIncome a inner join ItemFile b
on a.Num = b.NUM
where Inactive = 0
group by DATEPART(yy, [Date]), DATEPART(mm, [Date]), b.CurrentStore) ITEM
ON SUMM.Date = ITEM.Date and SUMM.Store = ITEM.Store

go

