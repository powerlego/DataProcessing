
CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_GetItemMaintenanceFleet]
@WidgetDataFilter KeyValuePair READONLY 
AS
BEGIN

SET NOCOUNT ON;

DECLARE @StoreNo nvarchar(20) = null;
DECLARE @CurrentDate datetime = GETDATE();
--Declare @StartDate datetime = null;
--Declare @EndDate datetime = null;

SELECT @StoreNo	= SUBSTRING([Value], 1, 20)	FROM @WidgetDataFilter WHERE [Key] = 'StoreNo';
SELECT @CurrentDate	= CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'CurrentDate';
--SELECT @StartDate = CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'StartDate';
--SELECT @EndDate	= CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'EndDate';
 

 SELECT Half.TypeDesc AS [Description], 
		Half.NumOfMaint as [CountSchedules], 
		Half.NumofItems as [CountItems], 
		CAST(Half.Typeoec as money) AS [OEC], 
		CAST(Whole.FleetOEC as money) as [TotalOEC], 
		CONVERT(varchar(50),CAST(Half.TypeOEC as money) / CAST(wHOLE.FLEETOEC as money)*100)+'%' as [PercentOEC]

 FROM

(
     Select '' as ID, OECTbl.[TypeDesc], sum(OECTbl.NumofMaint) AS NumofMaint, sum(OECTbl.NumofItems) as NumofItems, SUM(OECTbl.OEC) AS TYPEOEC
 From
 (
 SELECT  Tab.[TypeDesc], 0 as NumofMaint, Count(Tab.ItemQty) as NumofItems, SUM(Tab.OEC) AS OEC
 from
 (
 Select  (Maintbl.Num) AS ItemQty, 'Past Due' as [TypeDesc], MAX(Maintbl.PURP) AS OEC

 FROM
(
SELECT IM.Num, ITF.PURP, IM.Schedule, IM.Type, IM.Reading, IM.Frequency, ITF.[MTIN], ITF.[HROT3], ITF.CurrentStore, 
(Select Case 
When IM.Type = 'U' Then (ITF.MTIN - IM.Reading) - IM.Frequency
When IM.Type = 'H' and ITF.[Type] = 'H' Then (ITF.MTIN - IM.Reading) - IM.Frequency
When IM.Type = 'H' and ITF.[Type] <> 'H' Then  (ITF.HROT3 - IM.Reading) - IM.Frequency
When IM.Type = 'T' and IM.Reading <= IM.Frequency then -999
When IM.Type = 'T' Then (ITF.TMOT3 - IM.Reading) - IM.Frequency
When IM.Type = 'M' and year(IM.LastDate) < 1980 then DateDiff(m,'1/1/1900',@CurrentDate) - IM.Frequency
When IM.Type = 'M' and IM.LastDate Is Null then DateDiff(m,'1/1/1900',@CurrentDate) - IM.Frequency  
When IM.Type = 'M' and IM.LastDate Is Not Null then DateDiff(m,IM.LastDate,@CurrentDate) - IM.Frequency
When IM.Type = 'R' and IM.LastDate Is Null then DateDiff(m,'1/1/2100',@CurrentDate) - IM.Frequency 
When IM.Type = 'R' and IM.LastDate Is Not Null then DateDiff(m,IM.LastDate,@CurrentDate) - IM.Frequency 
When IM.Type = 'D' and IM.LastDate Is Null then DateDiff(d,'1/1/1900',@CurrentDate) - IM.Frequency 
When IM.Type = 'D' and IM.LastDate Is Not Null then DateDiff(d,IM.LastDate,@CurrentDate) - IM.Frequency 
Else 0
End) AS Due

FROM ItemMaintenance IM
INNER JOIN ItemFile ITF ON IM.Num = ITF.Num
WHERE ITF.[Type] Not In ('V','E') and ITF.[QTY] > 0 and (@StoreNo IS NULL or @StoreNo = '000' or ITF.CurrentStore = @StoreNo)
) AS MainTbl Where Maintbl.Due > 0
Group by Maintbl.Num

 ) AS Tab 
   Group by TAb.TypeDesc 

union

SELECT  Tab.[TypeDesc], 0 as NumofMaint, Count(Tab.ItemQty) as NumofItems, SUM(Tab.OEC) AS OEC
from
(
Select  (Maintbl.Num) AS ItemQty, 'Due Next Week' as [TypeDesc], MAX(Maintbl.PURP) AS OEC 

FROM
(
SELECT IM.Num, ITF.PURP, IM.Schedule, IM.Type, IM.Reading, IM.Frequency, ITF.[MTIN], ITF.[HROT3], ITF.CurrentStore,
(Select Case 
When IM.Type = 'U' Then (ITF.MTIN - IM.Reading) - IM.Frequency
When IM.Type = 'H' and ITF.[Type] = 'H' Then (ITF.MTIN - IM.Reading) - IM.Frequency
When IM.Type = 'H' and ITF.[Type] <> 'H' Then  (ITF.HROT3 - IM.Reading) - IM.Frequency
When IM.Type = 'T' and IM.Reading <= IM.Frequency then -999
When IM.Type = 'T' Then (ITF.TMOT3 - IM.Reading) - IM.Frequency
When IM.Type = 'M' and year(IM.LastDate) < 1980 then DateDiff(m,'1/1/1900',@CurrentDate) - IM.Frequency
When IM.Type = 'M' and IM.LastDate Is Null then DateDiff(m,'1/1/1900',@CurrentDate) - IM.Frequency  
When IM.Type = 'M' and IM.LastDate Is Not Null then DateDiff(m,IM.LastDate,@CurrentDate) - IM.Frequency
When IM.Type = 'R' and IM.LastDate Is Null then DateDiff(m,'1/1/2100',@CurrentDate) - IM.Frequency 
When IM.Type = 'R' and IM.LastDate Is Not Null then DateDiff(m,IM.LastDate,@CurrentDate) - IM.Frequency 
When IM.Type = 'D' and IM.LastDate Is Null then DateDiff(d,'1/1/1900',@CurrentDate) - IM.Frequency 
When IM.Type = 'D' and IM.LastDate Is Not Null then DateDiff(d,IM.LastDate,@CurrentDate) - IM.Frequency 
Else 0
End) AS Due

FROM ItemMaintenance IM
INNER JOIN ItemFile ITF ON IM.Num = ITF.Num
WHERE ITF.[Type] Not In ('V','E') and ITF.[QTY] > 0 and (@StoreNo IS NULL or @StoreNo = '000' or ITF.CurrentStore = @StoreNo)
) AS MainTbl Where Maintbl.Due >= -7 and Maintbl.Due <= 0
Group by Maintbl.Num

 ) AS Tab 
   Group by TAb.TypeDesc 
UNION

SELECT  Tab.[TypeDesc], sum(Count) as NumofMaint, 0 as NumofItems, 0 as OEC 
from
(
Select  Count(due) as Count, 'Past Due' as [TypeDesc]

FROM
(
SELECT IM.Num, ITF.PURP, IM.Schedule, IM.Type, IM.Reading, IM.Frequency, ITF.[MTIN], ITF.[HROT3], ITF.CurrentStore,
(Select Case 
When IM.Type = 'U' Then (ITF.MTIN - IM.Reading) - IM.Frequency
When IM.Type = 'H' and ITF.[Type] = 'H' Then (ITF.MTIN - IM.Reading) - IM.Frequency
When IM.Type = 'H' and ITF.[Type] <> 'H' Then  (ITF.HROT3 - IM.Reading) - IM.Frequency
When IM.Type = 'T' and IM.Reading <= IM.Frequency then -999
When IM.Type = 'T' Then (ITF.TMOT3 - IM.Reading) - IM.Frequency
When IM.Type = 'M' and year(IM.LastDate) < 1980 then DateDiff(m,'1/1/1900',@CurrentDate) - IM.Frequency
When IM.Type = 'M' and IM.LastDate Is Null then DateDiff(m,'1/1/1900',@CurrentDate) - IM.Frequency  
When IM.Type = 'M' and IM.LastDate Is Not Null then DateDiff(m,IM.LastDate,@CurrentDate) - IM.Frequency
When IM.Type = 'R' and IM.LastDate Is Null then DateDiff(m,'1/1/2100',@CurrentDate) - IM.Frequency 
When IM.Type = 'R' and IM.LastDate Is Not Null then DateDiff(m,IM.LastDate,@CurrentDate) - IM.Frequency 
When IM.Type = 'D' and IM.LastDate Is Null then DateDiff(d,'1/1/1900',@CurrentDate) - IM.Frequency 
When IM.Type = 'D' and IM.LastDate Is Not Null then DateDiff(d,IM.LastDate,@CurrentDate) - IM.Frequency 
Else 0
End) AS Due

FROM ItemMaintenance IM
INNER JOIN ItemFile ITF ON IM.Num = ITF.Num
WHERE ITF.[Type] Not In ('V','E') and ITF.[QTY] > 0 and (@StoreNo IS NULL or @StoreNo = '000' or ITF.CurrentStore = @StoreNo)
) AS MainTbl Where Maintbl.Due > 0
Group by Maintbl.due

 ) AS Tab 
   Group by TAb.TypeDesc

   UNION

   SELECT  Tab.[TypeDesc], sum(Count) as NumofMaint, 0 as NumofItems, 0 as OEC 
from
(
Select  Count(due) as Count, 'Due Next Week' as [TypeDesc]

FROM
(
SELECT IM.Num, ITF.PURP, IM.Schedule, IM.Type, IM.Reading, IM.Frequency, ITF.[MTIN], ITF.[HROT3], ITF.CurrentStore,
(Select Case 
When IM.Type = 'U' Then (ITF.MTIN - IM.Reading) - IM.Frequency
When IM.Type = 'H' and ITF.[Type] = 'H' Then (ITF.MTIN - IM.Reading) - IM.Frequency
When IM.Type = 'H' and ITF.[Type] <> 'H' Then  (ITF.HROT3 - IM.Reading) - IM.Frequency
When IM.Type = 'T' and IM.Reading <= IM.Frequency then -999
When IM.Type = 'T' Then (ITF.TMOT3 - IM.Reading) - IM.Frequency
When IM.Type = 'M' and year(IM.LastDate) < 1980 then DateDiff(m,'1/1/1900',@CurrentDate) - IM.Frequency
When IM.Type = 'M' and IM.LastDate Is Null then DateDiff(m,'1/1/1900',@CurrentDate) - IM.Frequency  
When IM.Type = 'M' and IM.LastDate Is Not Null then DateDiff(m,IM.LastDate,@CurrentDate) - IM.Frequency
When IM.Type = 'R' and IM.LastDate Is Null then DateDiff(m,'1/1/2100',@CurrentDate) - IM.Frequency 
When IM.Type = 'R' and IM.LastDate Is Not Null then DateDiff(m,IM.LastDate,@CurrentDate) - IM.Frequency 
When IM.Type = 'D' and IM.LastDate Is Null then DateDiff(d,'1/1/1900',@CurrentDate) - IM.Frequency 
When IM.Type = 'D' and IM.LastDate Is Not Null then DateDiff(d,IM.LastDate,@CurrentDate) - IM.Frequency 
Else 0
End) AS Due

FROM ItemMaintenance IM
INNER JOIN ItemFile ITF ON IM.Num = ITF.Num
WHERE ITF.[Type] Not In ('V','E') and ITF.[QTY] > 0 and (@StoreNo IS NULL or @StoreNo = '000' or ITF.CurrentStore = @StoreNo)
) AS MainTbl Where Maintbl.Due >= -7 and Maintbl.Due <= 0
Group by Maintbl.due

 ) AS Tab 
   Group by TAb.TypeDesc

   ) as OECTbl
  Group by OECTbl.[TypeDesc] 
  ) AS Half 
 
INNER Join   

(
select '' as ID, '' AS FleetDesc, count(ITF_Fleet.NUM) as ItemsinFleet, sum(ITF_OEC.oec) as FleetOEC
 
 From itemFile ITF_Fleet 

 Left Join 
 (SELECT  IPD.[ItemNumber] ,sum(([QuantityPurchased] - [QuantitySold]) * ([PriceEach] + IPD.[ExtraCharges])) AS OEC
                FROM [ItemPurchaseDetail] IPD
				WHERE IPD.[Disposed] = 0
               Group by IPD.[ITEMNUMBER]) as ITF_OEC ON ITF_Fleet.[NUM] = ITF_OEC.[ItemNumber]

WHERE NOT(ITF_Fleet.[TYPE] in ('b','e','f','i','k','m','n','o','p','s','v','w')) 
              AND ITF_Fleet.Qty < 90000 and (@StoreNo IS NULL or @StoreNo = '000' or ITF_Fleet.CurrentStore = @StoreNo)
			  ) AS Whole ON Half.ID = Whole.ID
END
go

