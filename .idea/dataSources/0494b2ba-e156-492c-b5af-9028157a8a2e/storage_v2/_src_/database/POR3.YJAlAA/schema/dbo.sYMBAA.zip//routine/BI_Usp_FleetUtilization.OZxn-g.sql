

CREATE PROCEDURE [dbo].[BI_Usp_FleetUtilization]
@WidgetDataFilter KeyValuePair READONLY 

AS

BEGIN

SET NOCOUNT ON;

-- Default values ----------------------
Declare @Style			Int = 1,
		@ItemNo			NVarChar(6) = 'All',
		@ItemHeader		NVarChar(20) = 'All',
		@Group			NVarChar(1000) = 'All',
		@Category		Int = 0,
		@Division		Int = 0,
		@DateFormat	  nvarchar(5) = 'en-US',
		@StoreNo		nvarchar(20) = '000';

-- Set value from Filter Object only if present --------------
SELECT @Style = CAST([Value] AS INT) FROM @WidgetDataFilter WHERE [Key] = 'PeriodStyle';
SELECT @ItemNo	= SUBSTRING([Value], 1, 6)	FROM @WidgetDataFilter WHERE [Key] = 'ItemNo';
SELECT @ItemHeader = SUBSTRING([Value], 1, 20)	FROM @WidgetDataFilter WHERE [Key] = 'Header';
SELECT @Group = SUBSTRING([Value], 1, 1000)	FROM @WidgetDataFilter WHERE [Key] = 'Group';
SELECT @Category = CAST([Value] AS INT) FROM @WidgetDataFilter WHERE [Key] = 'Category';
SELECT @Division = CAST([Value] AS INT) FROM @WidgetDataFilter WHERE [Key] = 'Division';
SELECT @DateFormat	= [Value] FROM @WidgetDataFilter WHERE [Key] = 'DateFormat';
SELECT @StoreNo	= SUBSTRING([Value], 1, 20)	FROM @WidgetDataFilter WHERE [Key] = 'StoreNo';

Declare @PeriodTypeId      Int = 1,
        @PeriodName        Varchar(6),
        @StartDate         Date,
        @EndDate           Date,
        @DateRpt           Date

CREATE TABLE #tmp_results
(
       [Period]                          Varchar(6),
       [Beg]                             varchar(10),
       [End]                             varchar(10),
       [PeriodHours]                    Int,
       [Item]                            Varchar(6),
       [Header]                          VarChar(16),
       [Group]                           VarChar(50),
       [Category]                        VarChar(50),
       [Divison]                         VarChar(50),
       [Revenue]                         Money,
       [HoursRented]                    Int,
       [OECUtil]                        Int,
       [QtyOwned]                       Int,
       [TotalOEC]                       Int,
       [QtyHours]                       BigInt,
       [DollarUtil]						VARCHAR(25),
       [TimeUtil]                       VARCHAR(25),
       [OnRentUtil]						VARCHAR(25) --OnRentOECUtil
)


--Set @PeriodTypeId = 1

WHILE (@PeriodTypeId <= 4)

BEGIN
		--Current date
       SET @DateRpt = CONVERT(Date, GETDATE()); --Convert(Date,'2/15/2018')

IF (@Style = 1)

       BEGIN

       SET @PeriodName = (Select Case @PeriodTypeId
                            When 1 then 'CM'
                            When 2 then 'LM'
                            When 3 then 'TMLY'
                            When 4 then 'TTM' End)

       SET @StartDate = (Select Case @PeriodTypeId
                            When 1 then DateAdd(day,1,EOMonth(@DateRpt,-1))
                            When 2 then DateAdd(day,1,EOMonth(@DateRpt,-2))
                            When 3 then DateAdd(yyyy,-1,DateAdd(day,1,EOMonth(@DateRpt,-1)))
                            When 4 then DateAdd(mm,-11,DateAdd(day,1,EOMonth(@DateRpt,-1))) End)

       SET @EndDate = (Select Case @PeriodTypeId
                            When 1 then EOMonth(@DateRpt)
                            When 2 then EOMonth(@DateRpt,-1)
                            When 3 then DateAdd(yyyy,-1,EOMonth(@DateRpt))
                            When 4 then EOMonth(@DateRpt) End)
       END

ELSE IF (@Style = 2)

    BEGIN

       SET @PeriodName = (Select Case @PeriodTypeId
                            When 1 then 'MTD'
                            When 2 then 'LMTD'
                            When 3 then 'YTD'
                            When 4 then 'LYTD' End)

       SET @StartDate = (Select Case @PeriodTypeId
                            When 1 then DateAdd(day,1,EOMonth(@DateRpt,-1))
                            When 2 then DateAdd(day,1,EOMonth(@DateRpt,-2))
                            When 3 then DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))
                            When 4 then DateAdd(yyyy,-1,DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))) End)

       SET @EndDate = (Select Case @PeriodTypeId
                            When 1 then @DateRpt
                            When 2 then DateAdd(mm,-1,@DateRpt)
                            When 3 then @DateRpt
                            When 4 then DateAdd(yyyy,-1,@DateRpt) End)

       END

ELSE IF (@Style = 3)

    BEGIN

       SET @PeriodName = (Select Case @PeriodTypeId
                            When 1 then 'MTD'
                            When 2 then 'LYMTD'
                            When 3 then 'YTD'
                            When 4 then 'LYTD' End)

       SET @StartDate = (Select Case @PeriodTypeId
                            When 1 then DateAdd(day,1,EOMonth(@DateRpt,-1))
                            When 2 then DateAdd(yyyy, -1,DateAdd(day,1,EOMonth(@DateRpt,-1)))
                            When 3 then DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))
                            When 4 then DateAdd(yyyy,-1,DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))) End)

       SET @EndDate = (Select Case @PeriodTypeId
                            When 1 then @DateRpt
                            When 2 then DateAdd(yyyy,-1,@DateRpt)
                            When 3 then @DateRpt
                            When 4 then DateAdd(yyyy,-1,@DateRpt) End)
	END

ELSE

    BEGIN

       SET @PeriodName = (Select Case @PeriodTypeId
                            When 1 then 'CW'
                            When 2 then 'CM'
                            When 3 then 'CQ'
                            When 4 then 'CY' End)

       SET @StartDate = (Select Case @PeriodTypeId
							When 1 then Convert(date,DateAdd(wk, DATEDIFF(wk, 0, @DateRpt),-1)) --starts sunday
                            When 2 then DateAdd(day,1,EOMonth(@DateRpt,-1))
                            When 3 then DateAdd(qq, DatePart(qq,@DateRpt) - 1, DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))) 
                            When 4 then DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt))) End)

       SET @EndDate = (Select Case @PeriodTypeId
                            When 1 then Convert(date,DateAdd(wk, DATEDIFF(wk, 0, @DateRpt),5))
                            When 2 then EOMonth(@DateRpt)
                            When 3 then DateAdd(qq, DatePart(qq,@DateRpt), DateAdd(day,0,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))) 
                            When 4 then Convert(date, DateAdd(yy, DateDiff(yy, 0, @DateRpt) + 1, -1)) End)

    END

Insert Into #tmp_results

SELECT @PeriodName AS Period, Format(@StartDate,'d', @DateFormat) AS Beg, Format(@EndDate,'d', @DateFormat) AS [End], DateDiff(hh,@StartDate,@EndDate)+24 AS [PeriodHours],

          MainTbl.Item, MainTbl.Header, MainTbl.[Group], MainTbl.Category, MainTbl.Division,

          sum(MainTbl.Revenue) AS Revenue, sum(MainTbl.HoursRented) AS HoursRented,

          sum(MainTbl.OECUtil) AS OECUtil, sum(MainTbl.QtyOwned) AS QtyOwned, sum(MainTbl.TotalOEC) AS TotalOEC,

          sum(MainTbl.QtyHours) AS QtyHours,

          FORMAT(ISNULL(iif(sum(MainTbl.TotalOEC)=0,0,sum(MainTbl.Revenue) / sum(MainTbl.TotalOEC)), 0), 'p') AS DollarUtil,
          FORMAT(ISNULL(iif(((DateDiff(hh,@StartDate,@EndDate)+24) * sum(MainTbl.QtyOwned))=0,0,sum(MainTbl.HoursRented) / ((DateDiff(hh,@StartDate,@EndDate)+24) * sum(MainTbl.QtyOwned))), 0), 'p') AS TimeUtil,		 
		  FORMAT(ISNULL(iif(sum(MainTbl.TotalOEC)=0,0,sum(MainTbl.OECUtil) / sum(MainTbl.TotalOEC)), 0), 'p') AS OnRentUtil

FROM (

SELECT iif(@ItemNo IS NULL OR @ItemNo = 'All','All',ITF.Num) AS Item,

          iif(@ItemHeader IS NULL OR @ItemHeader = 'All','All',ITF.Header) AS Header,

          iif(@Group IS NULL OR @Group = 'All','All',ITF.[Group]) AS [Group],

          iif(@Category = 0,'All',ITC.Name) AS Category,

          iif(@Division = 0,'All',ITD.DivisionName) AS Division,
		  
		  TransTbl.Revenue, TransTbl.[Hours] AS [HoursRented],

          round(iif((PurchTbl.Quantity * (DateDiff(hh,@StartDate,@EndDate)+24)) * PurchTbl.OEC=0,0,(TransTbl.[Hours] / (PurchTbl.Quantity * (DateDiff(hh,@StartDate,@EndDate)+24))) * PurchTbl.OEC),2) AS [OECUtil],

          PurchTbl.Quantity AS [QtyOwned],

          PurchTbl.OEC AS [TotalOEC],

          (DateDiff(hh,@StartDate,@EndDate)+24) * PurchTbl.Quantity AS [QtyHours],

          Round(iif(PurchTbl.OEC=0,0,(TransTbl.Revenue / PurchTbl.OEC)*100),2) AS [DollarUtil],

          Round(iif((DateDiff(hh,@StartDate,@EndDate)+24) * PurchTbl.Quantity=0,0,((TransTbl.[Hours]) / ((DateDiff(hh,@StartDate,@EndDate)+24) * PurchTbl.Quantity))*100),2) AS [TimeUtil],

		  ITF.CurrentStore

FROM ItemFile ITF

     LEFT JOIN ItemCategory ITC ON ITF.Category = ITC.Category

     LEFT JOIN ItemDivision ITD ON ITC.DivisionNumber = ITD.DivisionNumber

     LEFT JOIN (SELECT Num, sum(PD.Quantity) AS Quantity, Round(Sum(OEC),2) AS OEC

                     FROM (SELECT 'PO' AS Code, ItemPurchaseDetail.[ItemNumber] AS NUM, ItemPurchaseDetail.[PurchaseDate] AS [Date],

                                            ItemPurchaseDetail.[QuantityPurchased] AS Quantity,

                                             ItemPurchaseDetail.[QuantityPurchased] * (ItemPurchaseDetail.[PriceEach] + ItemPurchaseDetail.[ExtraCharges]) AS OEC

                      FROM ItemPurchaseDetail

                      WHERE ItemPurchaseDetail.[PurchaseDate] <= @EndDate

                      UNION

                           SELECT 'SA' AS Code, SoldAssetFile.[ItemNo] AS NUM, SoldAssetFile.[Date] AS [Date],

                                           (SoldAssetFile.[Qty] * -1) AS Quantity, (SoldAssetFile.[PurchaseCost] * -1) AS OEC

                           FROM SoldAssetFile

                           WHERE SoldAssetFile.[Date] <= @EndDate) PD

                           GROUP BY PD.Num

               ) PurchTbl ON ITF.Num = PurchTbl.Num

     LEFT JOIN (SELECT Trans.Item, sum(Trans.Revenue) AS Revenue, sum(Trans.[Hours]) AS [Hours]

                   FROM (SELECT TI.Item, Sum(TI.Pric-TI.DiscountAmount) AS Revenue, sum(TI.HRSC * TI.Qty) AS [Hours]

                         FROM TransactionItems TI

                                 INNER JOIN Transactions T ON TI.CNTR = T.CNTR

                               WHERE left(TI.CNTR,1) Not In ('h','l','q','r','s','t') AND

                                  TI.DDT >= @StartDate AND

                                  TI.DDT <= @EndDate AND

                                  TI.TXTY In ('RR','RX')

                          GROUP BY TI.Item       

                             UNION All

                          SELECT TI.Item, Sum(TI.Pric-TI.DiscountAmount) AS Revenue, sum(TI.HRSC * TI.Qty) AS [Hours]

                          FROM TransItemsHistory TI

                                  INNER JOIN TransHistory T ON TI.CNTR = T.CNTR

                         WHERE left(TI.CNTR,1) Not In ('h','l','q','r','s','t') AND

                                   TI.DDT >= @StartDate AND

                                   TI.DDT <= @EndDate AND

                                   TI.TXTY In ('RR','RX')

                             GROUP BY TI.Item

                      ) AS Trans

                   GROUP BY Trans.Item                                

                        ) AS TransTbl ON ITF.Num = TransTbl.Item

WHERE ITF.[Type] In ('T','H','U','A','L','D') AND

      ITF.Inactive = 0 AND

      ITF.QTY < 90000 AND

      (@ItemNo IS NULL OR @ItemNo = 'All' OR ITF.Num = @ItemNo) AND

      (@ItemHeader IS NULL OR @ItemHeader = 'All' OR ITF.Header = @ItemHeader) AND

      (@Group IS NULL or @Group = 'All' OR ITF.[Group] = @Group ) AND

      (@Category IS NULL or @Category = 0 or ITC.[Category] = @Category) AND

      (@Division IS NULL or @Division = 0 or ITD.[DivisionNumber] = @Division)

	  AND (@StoreNo IS NULL or @StoreNo = '000' or (@StoreNo LIKE '%' + ITF.CurrentStore + '%'))

) AS MainTbl

GROUP By MainTbl.Item, MainTbl.Header, MainTbl.[Group], MainTbl.Category, MainTbl.Division

SET @PeriodTypeId = @PeriodTypeId + 1

END 

SELECT * From #tmp_results
DROP TABLE #tmp_results


END
go

