
CREATE VIEW [dbo].[vwAT_JournalEntriesPendingExport] --WITH ENCRYPTION 
AS
SELECT 
-- GLd.Id															AS SRC_ID
--,GLd.TransMemo													AS REFERENCE
 GL.Id															AS SRC_ID
,GL.TransMemo													AS REFERENCE
,gl.TransDate													AS POST_DATE
,'POR Journal Entries'											AS DETAILS_HDR
--,'POR Journal Entry ' + CAST(Gld.id AS Varchar(9))				AS DETAILS_ITEM
--,CASE WHEN GLd.TransAmount < 0
--		THEN Gld.AccountNumber ELSE '' END						AS CRD_NOMINAL_CODE
--,''																AS CRD_NOMINAL_NAME
--,CASE WHEN GLd.TransAmount >= 0
--		THEN Gld.AccountNumber ELSE '' END						AS DBT_NOMINAL_CODE
--,''																AS DBT_NOMINAL_NAME
--,ABS(gld.TransAmount)											AS AMOUNT
--,''																AS DEPT_CODE
FROM AccountingAPIQueueGL GL
--INNER JOIN AccountingAPIQueueGLDetail GLd ON GLd.AccountingAPIQueueGLId = GL.Id
WHERE GL.DateApproved IS NOT NULL
  AND GL.DatePosted IS NULL
  AND GL.DateCancelled IS NULL
  AND GL.RetryCount <= 10
  AND GL.NoExport = 0
  AND GL.Batch > 0
  AND GL.Direction = 1
--  AND GL.TransCodeId IN (4,30,60,15,7) -- GLTransAdd, DepositAdd, DisbursementAdd, Cash Trans, AR
go

grant select on vwAT_JournalEntriesPendingExport to PORUser
go

