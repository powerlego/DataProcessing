
CREATE PROCEDURE [dbo].[spAT_UpdateExportedPaymentAsPosted](
 @pilAxpId int 
,@pilQueueId int
,@pilTxId Int
,@posErrorMsg varchar(512) OUTPUT -- any user / server error
) --WITH ENCRYPTION 
AS

SET NOCOUNT ON
SET @posErrorMsg = NULL
DECLARE @lErrorNo Int,
		@TransCodeId Int

SET @TransCodeId = (SELECT TransCodeId FROM AccountingAPIQueueTR WHERE Id = @pilQueueId)

UPDATE dbo.AccountingAPIQueueTR
SET    DatePosted = GetDate()
  	   ,DateChanged = GetDate()      
	   ,DateError = NULL
	   ,DateCancelled = NULL
	   ,ErrorMsg = NULL
	   ,ExternalId = @pilTxId
	   ,AccountingLink = CAST(@pilTxId AS VARCHAR(255))
WHERE  Id = @pilQueueId

IF (@TransCodeId IN (40,43)) -- AR Credit
	Update dbo.PaymentDetail
	   SET AccountingLink = CAST(@pilTxId AS VARCHAR(255))
	  FROM AccountingAPIQueueTR
	  INNER JOIN PaymentFile on PaymentFile.GLTransactionGroupId = AccountingAPIQueueTR.GLTransactionGroupId
	 WHERE PaymentDetail.Contract = AccountingAPIQueueTR.ContractNumber
	   AND PaymentDetail.Payment = PaymentFile.Payment
	   AND ISNULL(PaymentDetail.AccountingLink,0) = 0
	   AND AccountingAPIQueueTR.Id = @pilQueueId
ELSE
	Update dbo.PaymentDetail
	   SET AccountingLink = CAST(@pilTxId AS VARCHAR(255))
	  FROM AccountingAPIQueueTR
	 WHERE PaymentDetail.Contract = AccountingAPIQueueTR.ContractNumber
	   AND PaymentDetail.Payment = CAST(AccountingAPIQueueTR.KeyValue AS INT)
	   AND ISNULL(PaymentDetail.AccountingLink,0) = 0
	   AND AccountingAPIQueueTR.Id = @pilQueueId

RETURN

go

grant execute on spAT_UpdateExportedPaymentAsPosted to PORUser
go

