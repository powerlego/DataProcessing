
CREATE PROCEDURE [dbo].[spAT_GetContractForExport2](
 @pilIvbId Int
,@pisAccountType Varchar(1) = 'E' -- E = External, I = Internal, A = All types
) 
-- WITH ENCRYPTION
AS
SET NOCOUNT ON

DECLARE @lDfltInvFtrTextId Int

IF @pisAccountType IS NULL
	SET @pisAccountType = 'E'

SELECT 
RTRIM(LTRIM(ac.AccountingLink))									 AS ACCNO		-- Customer Account Number ?
,Cast(cst.CNUM As Int)											 AS CST_ID
,cst.NAME														 AS CST_NAME
,Tr.Id															 AS IVC_INVOICE_NUMBER
,''																 AS IVC_INVOICE_TYPE
,Tr.ContractNumber												 AS IVC_USER_INVOICE_NUMBER
,Tr.TransDate													 AS IVC_INVOICE_DATE
,Cast(Tr.Store AS Int)											 AS IVC_DEPOT_ID 
,''																 AS IVC_CASH_STATUS
,''																 AS IVC_CASH_PAID_FLAG
,ISNULL(CE.AccountingLink,'')									 AS CUR_ACCOUNTS_CURRENCY_CODE
,Cast(Tr.ExchangeRate AS Real)									 AS IVC_EXCH_RATE
,Tr.TaxAmount													 AS IVC_SALESTAX
,''																 AS ACCOUNTS_DEPT
,CAST(stm.number as VARCHAR(12))								 AS SALESPERSON_CODE
,''																 AS IFT_NAME -- remove 3.28
,''															     AS IFT_ACCOUNTS_CODE
,Tr.DateQueued													 AS CONFIRMED_DATE
,CASE WHEN Tr.TransCodeId IN (40,43) THEN 'CREDIT'
	  WHEN Tr.TransCodeId = 7 THEN 'ACCOUNT'
	  WHEN Tr.TransCodeId = 15 THEN 'CASH'
	  Else 'CONTRACT' END										 AS IVC_INVOICE_TYPE
,''																 AS IVC_BOTTOM_TITLE
FROM ((((((dbo.AccountingAPIQueueTR as Tr
		INNER JOIN AccountNumbers A ON A.Store = tr.Store)
        INNER JOIN dbo.CustomerFile as cst ON Tr.CustomerNumber = cst.CNUM)
	    INNER JOIN dbo.Transactions AS T ON T.CNTR = tr.ContractNumber)
        LEFT OUTER JOIN dbo.Salesman AS stm ON t.Salesman = stm.Number)
	    LEFT OUTER JOIN AccountingCustomer ac ON ac.id = cst.AccountingCustomerId)
		LEFT OUTER JOIN CurrencyExchange CE ON CE.CurrencyNumber = T.CurrencyNumber)
		LEFT OUTER JOIN AccountingLocation AL ON AL.Id = A.AccountingLocationId
--LEFT OUTER JOIN ExportFormat X ON X.ExportFormatId = A.ExportFormat)
--LEFT OUTER JOIN CustomerFile cfc ON cfc.CNUM = x.GenericCashCustomerNumber)
--LEFT OUTER JOIN AccountingCustomer acx ON acx.id = cfc.AccountingCustomerId)

WHERE Tr.Id = @pilIvbId
AND   Tr.DatePosted Is NUll

RETURN
go

grant execute on spAT_GetContractForExport2 to PORUser
go

