
CREATE VIEW [dbo].[VW_TouchpointSearch] --WITH SCHEMABINDING
AS
	SELECT 
					[CRM].[Id] AS [CRM_Id],
					[CRM].[Link] AS [CRM_Link],
					[CRM].[LinkType] AS [CRM_LinkType],
					[CRM].[OpNoAssigned] AS [CRM_OpNoAssigned],
					[CRM].[LastCall] AS [CRM_LastCall],
					[CRM].[NextCall] AS [CRM_NextCall],
					[CRM].[Frequency] AS [CRM_Frequency],
					[CRM].[Priority] AS [CRM_Priority],
					[CRM].[Comment] AS [CRM_Comment],
					[CRM].[Complete] AS [CRM_Complete],
					[CF].[NAME] AS [CF_NAME], 
					[CF].[Salesman] AS [CF_Salesman],
					[CF].[Address] AS [CF_Address],
					[CF].[Address2] AS [CF_Address2],
					[CF].[CITY] AS [CF_CITY],
					[CF].[ZIP] AS [CF_ZIP],
					[CF].[ZIP4] AS [CF_ZIP4],
					[CJ].[Description] AS [CJ_Description], 
					[CJ].[Salesman] AS [CJ_Salesman],
					[CJ].[SiteAddress] AS [CJ_SiteAddress],
					[CJ].[SiteCity] AS [CJ_SiteCity],
					[CJ].[SiteZip] AS [CJ_SiteZip],
					[CJ_TR].[Languagecode] AS [CJ_Languagecode],
					[CJ_TR].[Description] AS [CJ_Description_TR],
					[S1].[Name] AS [S_Name],
					[O].[OPNM] AS [O_OPNM],
					[S2].[Number] AS [O_SalesrepNumber],
					[S2].[Name] AS [O_SalesrepName]
	FROM			[dbo].[CRMTouchpoints]		AS [CRM]
	LEFT OUTER JOIN [dbo].[CustomerFile]		AS [CF]		ON	[CRM].[Link]		= [CF].[CNUM]		AND 
																[CRM].[LinkType]	= 2
	LEFT OUTER JOIN [dbo].[CustomerJobSite]		AS [CJ]		ON	[CRM].[Link]		= [CJ].[Number]		AND 
																[CRM].[LinkType]	= 6
	LEFT OUTER JOIN [dbo].[CustomerJobSite_Tr]	AS [CJ_TR]	ON	[CJ].[Number]		= [CJ_TR].[Number]	AND
																[CJ_TR].[Inactive]	= 0
	LEFT OUTER JOIN [dbo].[Salesman]			AS [S1]		ON  ((
																[CF].[Salesman]		= [S1].[Number]		AND 
																[CRM].[LinkType]	= 2
																) OR (
																[CJ].[Salesman]		= [S1].[Number]		AND 
																[CRM].[LinkType]	= 6)
																) AND 
																[S1].[Inactive]		= 0
	LEFT OUTER JOIN	[dbo].[OperatorId]			AS [O]		ON	[CRM].[OpNoAssigned] = [O].[OPNO]
	LEFT OUTER JOIN [dbo].[Salesman]			AS [S2]		ON  [O].[OPNO] = [S2].[OperatorNo] AND
																[S2].[Inactive]		= 0
	WHERE														[CRM].[Inactive]	= 0

go

