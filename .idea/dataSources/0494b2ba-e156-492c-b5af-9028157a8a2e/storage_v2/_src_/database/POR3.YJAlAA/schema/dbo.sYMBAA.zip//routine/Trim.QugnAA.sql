
-- =============================================
-- Author:		JA
-- Date: 
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[Trim] 
(
	-- Add the parameters for the function here
	@SV NVARCHAR
)
RETURNS NVARCHAR
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result NVARCHAR

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = RTRIM(LTRIM(@SV))

	-- Return the result of the function
	RETURN @Result

END


go

