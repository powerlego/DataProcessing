
CREATE VIEW qryDataDepreciation
AS

SELECT ItemDepreciationSchedules.Description AS DepreciationBook, 
          ItemDepreciationDetail.Date, 
          ItemDepreciationDetail.[Num] AS [Item Number], 
          ItemFile.[KEY] AS [Item Key], 
          ItemFile.[Name] AS [Item Name], 
          ItemDepreciationDetail.Depreciation AS [Monthly Depreciation], 
          IIf([recapture]=1,'Recapture','') AS Recaptured, 
          ItemDepreciation.CurrentValue AS CurrentValue, 
          ItemDepreciation.Accrued AS [Total Accrued Depreciation], 
          ItemDepreciation.Method, ItemDepreciation.MidConvention, 
          ItemDepreciation.Period, ItemDepreciation.SalvageValue, 
          ItemDepreciation.ExtraDepreciation, 
          ItemDivision.DivisionName AS Division, 
          ItemCategory.Name AS Category, 
          ItemType.TypeDescrip AS [Item Type], 
          ItemDepartment.DepartmentName AS Department
  FROM ItemType 
 INNER JOIN ((((ItemDepreciationDetail 
                           INNER JOIN ItemDepreciation              
                                    ON ItemDepreciationDetail.Num = ItemDepreciation.Num) 
                           INNER JOIN ItemDepreciationSchedules 
                                    ON ItemDepreciation.Schedule = ItemDepreciationSchedules.Schedule) 
                           INNER JOIN ((ItemDivision 
                                                 INNER JOIN ItemCategory   
                                                          ON ItemDivision.DivisionNumber = ItemCategory.DivisionNumber) 
                                                 INNER JOIN ItemFile    
                                                          ON ItemCategory.Category = ItemFile.Category) 
                                    ON ItemDepreciationDetail.Num = ItemFile.NUM) 
                                                 INNER JOIN ItemDepartment 
                                                          ON ItemFile.Department = ItemDepartment.Department) 
          ON ItemType.Type = ItemFile.Type;



go

