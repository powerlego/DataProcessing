
CREATE VIEW [dbo].[VW_OperatorSearch] 
AS
		SELECT
					  [O].[OPNO] AS [O_OPNO],
					  [O].[OPID] AS [O_OPID],
					  [O].[OPNM] AS [O_OPNM],
					  [O].[Group] AS [O_Group],
					  [O].[TimeClock] AS [O_TimeClock],
					  [O].[CRTCode] AS [O_CRTCode],
					  [O].[GroupNumber] AS [O_GroupNumber],
					  [O].[HomeStore] AS [O_HomeStore],
					  [O].[SocialSecurity] AS [O_SocialSecurity],
					  [O].[HireDate] AS [O_HireDate],
					  [O].[TerminationDate] AS [O_TerminationDate],
					  [O].[CashDrawer] AS [O_CashDrawer],
					  [O].[DepositDrawer] AS [O_DepositDrawer],
					  [O].[AllowPOSubmission] AS [O_AllowPOSubmission],
					  [O].[MaximumPOAllowed] AS [O_MaximumPOAllowed],
					  [O].[MaximumDiscountPercent] AS [O_MaximumDiscountPercent],
					  [O].[MaximumPriceChange] AS [O_MaximumPriceChange],
					  [O].[EmployeeNumber] AS [O_EmployeeNumber],
					  [O].[Password] AS [O_Password],
					  [O].[PasswordLevel] AS [O_PasswordLevel],
					  [O].[TimeClockId] AS [O_TimeClockId],
					  [O].[HourlyRate] AS [O_HourlyRate],
					  [O].[PayType] AS [O_PayType],
					  [O].[MultiGroup] AS [O_MultiGroup],
					  [O].[Email] AS [O_Email],
					  [O].[CellPhone] AS [O_CellPhone],
					  [O].[CellProvider] AS [O_CellProvider],
					  [O].[DefaultNotification] AS [O_DefaultNotification],
					  [O].[ProgramTipDate] AS [O_ProgramTipDate],
					  [O].[ProgramTipNoShow] AS [O_ProgramTipNoShow],
					  [O].[OfficePhone] AS [O_OfficePhone],
					  [O].[JobAppUser] AS [O_JobAppUser],
					  [O].[DefaultLanguage] AS [O_DefaultLanguage],
					  [G].[GroupName] AS [G_GroupName],
					  [G_TR].[Languagecode] AS [G_Languagecode],
					  [G_TR].[GroupName] AS [G_GroupName_TR],
					  [P].[STORE_NAME] AS [P_STORE_NAME],
					  [P_TR].[Languagecode] AS [P_Languagecode],
					  [P_TR].[STORE_NAME] AS [P_STORE_NAME_TR],
					  [S].[Number] AS [S_Number],
					  [S].[Name] AS [S_Name],
					  ISNULL([TN1].[LanguageCode], [TN2].[LanguageCode]) AS [TN_LanguageCode]
		FROM			[dbo].[OperatorId]			AS [O]
		LEFT OUTER JOIN [dbo].[GroupFile]			AS [G]		ON	[O].[GroupNumber]	= [G].[GroupNumber]
		LEFT OUTER JOIN [dbo].[GroupFile_Tr]		AS [G_TR]	ON	[O].[GroupNumber]	= [G_TR].[GroupNumber] AND 
																	[G_TR].[Inactive]	= 0
		LEFT OUTER JOIN [dbo].[ParameterFile]		AS [P]		ON	[O].[HomeStore]	= [P].[Store]
		LEFT OUTER JOIN [dbo].[ParameterFile_Tr]	AS [P_TR]	ON	[O].[HomeStore]	= [P_TR].[Store] AND 
																	[P_TR].[Inactive]	= 0
		LEFT OUTER JOIN [dbo].[Salesman]			AS [S]		ON	[O].[OPNO] = [S].[OperatorNo] AND [S].[Inactive] = 0
		LEFT OUTER JOIN [dbo].[TranslationNames]	AS [TN1]	ON	[TN1].[Translations] = [O].[DefaultLanguage] AND 
																	[TN1].[LanguageCode] IS NOT NULL AND 
																	[TN1].[Language] IS NOT NULL AND
																	LOWER([TN1].[Language]) <> 'undefined'
		CROSS APPLY	(	
				SELECT  TOP 1 [LanguageCode]
				FROM    [dbo].[TranslationNames]
				WHERE   [dbo].[TranslationNames].[LanguageCode] IS NOT NULL AND 
						[dbo].[TranslationNames].[Language] IS NOT NULL AND
						LOWER([dbo].[TranslationNames].[Language]) <> 'undefined'
				) AS [TN2]
  WHERE [O].[Inactive] = 0
go

