CREATE PROCEDURE [dbo].[BI_Usp_Get_Availability]

@ValueType NVarChar(20),
@Value NVarChar(50)

AS
BEGIN
SET NOCOUNT ON;
--Default values ----------------------
--Declare  
--  @ValueType NVarChar(20) = 'Category',  --Item, Header, Group, Category
--  @Value NVarChar(50) = '73'  --Use the value for the ValueType
--   --100268  30126
--   --6KTHFLIFT
--   --...Test Gr
--   --...Test Category  73    Scissor Lifts/Aerial Lifts   44
Declare
         @DateRpt           Date,
@ValueInt Int,
@NameDisplay NVarChar(50)

--Current date
         SET @DateRpt = CONVERT(Date, GETDATE());

IF @ValueType = 'Category'
SET @ValueInt = CONVERT(int, @Value);

Set @NameDisplay = (Select Case
 When @ValueType = 'Item' Then (Select Top 1 ITF.[Name] FROM ItemFile ITF WHERE @Value = ITF.Num)
 When @ValueType = 'Header' Then (Select Top 1 ITF.[Name] FROM ItemFile ITF WHERE @Value = ITF.Header)
 When @ValueType = 'Group' Then (Select Top 1 ITF.[Group] FROM ItemFile ITF WHERE @Value = ITF.[Group])
 When @ValueType = 'Category' Then (Select Top 1 ITC.[Name] FROM ItemCategory ITC WHERE @ValueInt = ITC.Category)
  End);

--WITH StoreNumber AS
--(
-- SELECT PF.Store FROM ParameterFile PF INNER JOIN ParameterFileAdditional PFA ON PF.Store = PFA.Store WHERE PFA.Closed = 0
-- UNION
-- SELECT DT.ServiceTruckNumber AS Store FROM DeliveryTrucks DT WHERE DT.ServiceTruck <> 0
--)

WITH CTE AS
(
SELECT
ITF.Num, ITF.Header, ITF.[Group], ITF.Category, ITF.CurrentStore
FROM
ItemFile ITF
WHERE ITF.Inactive = 0 AND
     (
(@ValueType = 'Item' AND @Value = ITF.NUM) or
(@ValueType = 'Header' AND @Value = ITF.Header) or
(@ValueType = 'Group' AND @Value = ITF.[Group]) or
(@ValueType = 'Category' AND @ValueInt = ITF.[Category])
 )
)
SELECT PF.Store,
       @NameDisplay AS [Name],
       ISNULL(MainTbl.Owned,0) AS Owned,
  ISNULL(MainTbl.OnRent,0) AS [On Rent],
  ISNULL(MainTbl.LateRtn,0) AS [Overdue],
  ISNULL(MainTbl.OffRent,0) AS [Off Rent],
  ISNULL(MainTbl.SchedPickup,0) AS [PU Sched],
  ISNULL(MainTbl.Subrent,0) AS [Subrented],
  ISNULL(MainTbl.InRepair,0) AS [In Repair],
  ISNULL(MainTbl.NeedMaint,0) AS [Maint Req],
  ISNULL(MainTbl.NeedSrvc,0) AS [Serv Req],
  ISNULL(MainTbl.Rsrvd,0) AS [Rsrvd],
  ISNULL(MainTbl.XferIn,0) AS [Xfer In],
  ISNULL(MainTbl.XferOut,0) AS [Xfer Out],
  iif(MainTbl.Owned = 0, 0, iif(MainTbl.OnRent Is Null, 0, round((MainTbl.[OnRent] / MainTbl.Owned),2))) AS Util
FROM (
SELECT PF.Store FROM ParameterFile PF INNER JOIN ParameterFileAdditional PFA ON PF.Store = PFA.Store WHERE PFA.Closed = 0
UNION
SELECT DT.ServiceTruckNumber AS Store FROM DeliveryTrucks DT WHERE DT.ServiceTruck <> 0
     ) PF
LEFT JOIN (
SELECT ITF.CurrentStore,
  sum(ITF.QTY) AS Owned,
  max(OnRent.OnRentQty) AS [OnRent],
  max(Late.LateQty) AS [LateRtn],
  max(OffRent.OffRentQty) AS [OffRent],
  max(Subrent.SubrentQty) AS [Subrent],
  max(OnIRO.OnIROQty) AS [InRepair],
  max(OnIMO.OnIMOQty) AS [NeedMaint],
  max(OnISO.OnISOQty) AS [NeedSrvc],
  max(OnResv.ResvQty) AS [Rsrvd],
  max(OnXferOut.XferOut) AS [XferOut],
  max(OnXferIn.XferIn) AS [XferIn],
  max(OnPickup.PickupQty) AS [SchedPickup]
FROM ItemFile ITF
LEFT JOIN ItemCategory ITC ON ITF.Category = ITC.Category
LEFT JOIN ItemDivision ITD on ITC.[DivisionNumber] = ITD.[DivisionNumber]
   --GET On OnRent Qty's
LEFT JOIN (SELECT iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore) AS Store, sum([TI].[Qty]) AS OnRentQty
                FROM TransactionItems TI
                     INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
                INNER JOIN CTE AS ItemList ON ItemList.Num = TI.[Item]
                WHERE Left(TI.[CNTR],1) Not In ('c','f','l','q','r','t','w','s') AND
 TI.[TXTY] Not In ('RR','RX') AND
                      Left(TI.[TXTY],1) = 'R' AND
                      Left(T.[STAT],1) = 'O' AND
 (TI.[TXTY] <> 'RH' or (TI.[TXTY] = 'RH' AND TI.[DDT] > DateAdd(d,1,@DateRpt))) AND
 TI.Qty <> 0
   GROUP BY iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore)
               ) AS OnRent ON OnRent.Store = ITF.CurrentStore
   --GET On Late Qty's
LEFT JOIN (SELECT iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore) AS Store, sum([TI].[Qty]) AS LateQty
                FROM TransactionItems TI
                     INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
                INNER JOIN CTE AS ItemList ON ItemList.Num = TI.[Item]
                WHERE Left(TI.[CNTR],1) Not In ('c','f','l','q','r','t','w','s') AND
 TI.[TXTY] Not In ('RR','RX') AND
                      Left(TI.[TXTY],1) = 'R' AND
                      Left(T.[STAT],1) = 'O' AND
 TI.[TXTY] <> 'RH' AND
 TI.[DDT] <= DateAdd(d,1,@DateRpt) AND
 T.Pickup = 0 AND
 TI.Qty <> 0
   GROUP BY iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore)
               ) AS Late ON Late.Store = ITF.CurrentStore
   --GET On OffRent Qty's
LEFT JOIN (SELECT iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore) AS Store, sum([TI].[Qty]) AS OffRentQty
                FROM TransactionItems TI
                     INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
                INNER JOIN CTE AS ItemList ON ItemList.Num = TI.[Item]
                WHERE Left(TI.[CNTR],1) Not In ('c','f','l','q','r','t','w') AND
 TI.[TXTY] = 'RH' AND
 TI.[DDT] <= DateAdd(d,1,@DateRpt) AND
 Left(T.[STAT],1) = 'O' AND
 TI.Qty <> 0
   GROUP BY iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore)
               ) AS OffRent ON OffRent.Store = ITF.CurrentStore

   --GET On Subrented Qty's
LEFT JOIN (SELECT iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore) AS Store, Abs(sum([TI].[Qty])) AS SubrentQty
                FROM TransactionItems TI
                     INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
                INNER JOIN CTE AS ItemList ON ItemList.Num = TI.[Item]
                WHERE Left(TI.[CNTR],1) = 's' AND
 TI.[TXTY] Not In ('RR','RX') AND
                      Left(TI.[TXTY],1) = 'R' AND
                      Left(T.[STAT],1) = 'O' AND
 (TI.[TXTY] <> 'RH' or (TI.[TXTY] = 'RH' AND TI.[DDT] > DateAdd(d,1,@DateRpt))) AND
 TI.Qty <> 0
   GROUP BY iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore)
               ) AS Subrent ON Subrent.Store = ITF.CurrentStore

   --GET On IRO Qty's
LEFT JOIN (SELECT iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore) AS Store, sum([TI].[Qty]) AS OnIROQty
                FROM TransactionItems TI
                     INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
                INNER JOIN CTE AS ItemList ON ItemList.Num = TI.[Item]
                WHERE Left(TI.[CNTR],1) = ('r') AND
 TI.[TXTY] Not In ('RR','RX') AND
 Left(T.[STAT],1) = 'O' AND
 TI.Qty <> 0
   GROUP BY iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore)
               ) AS OnIRO ON OnIRO.Store = ITF.CurrentStore
   --GET On IMO Qty's
LEFT JOIN (SELECT iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore) AS Store, sum([TI].[Qty]) AS OnIMOQty
                FROM TransactionItems TI
                     INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
                INNER JOIN CTE AS ItemList ON ItemList.Num = TI.[Item]
INNER JOIN CustomerFile CF ON T.[CUSN] = CF.[CNUM]
                WHERE Left(TI.[CNTR],1) = ('r') AND
 TI.[TXTY] In ('RR','RX') AND
 Left(T.[STAT],1) = 'O' AND
 CF.[KEY] LIKE 'REPAIRS-MAINT%' AND
 TI.Qty <> 0
   GROUP BY iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore)
               ) AS OnIMO ON OnIMO.Store = ITF.CurrentStore
   --GET On ISO Qty's
LEFT JOIN (SELECT iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore) AS Store, sum([TI].[Qty]) AS OnISOQty
                FROM TransactionItems TI
                     INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
                INNER JOIN CTE AS ItemList ON ItemList.Num = TI.[Item]
INNER JOIN CustomerFile CF ON T.[CUSN] = CF.[CNUM]
                WHERE Left(TI.[CNTR],1) = ('r') AND
 TI.[TXTY] In ('RR','RX') AND
 Left(T.[STAT],1) = 'O' AND
 CF.[KEY] LIKE 'REPAIRS-SERV%' AND
 TI.Qty <> 0
   GROUP BY iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore)
               ) AS OnISO ON OnISO.Store = ITF.CurrentStore
   --GET On Reservation Qty's
LEFT JOIN (SELECT iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore) AS Store, sum([TI].[Qty]) AS ResvQty
                FROM TransactionItems TI
                     INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
                INNER JOIN CTE AS ItemList ON ItemList.Num = TI.[Item]
                WHERE Left(T.[STAT],1) In ('R') AND
     convert(date,T.[DATE]) >= DateAdd(d,-1,@DateRpt) AND
     Left(ltrim(TI.CNTR),1) Not In ('h','l','s','t','r','w','q','c') AND
 Left(ltrim(TI.TXTY),1) In ('R') AND
 left(ltrim(TI.TXTY),2) Not In ('RR','RX') AND
 TI.Qty <> 0
   GROUP BY iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore)
               ) AS OnResv ON OnResv.Store = ITF.CurrentStore
   --GET Items on Transfer Out
LEFT JOIN (SELECT iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore) AS Store, sum([TI].[Qty]) AS XferOut
FROM TransactionItems TI
INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
INNER JOIN CTE AS ItemList ON ItemList.Num = TI.[Item]
WHERE Left(T.[STAT],1) In ('O') AND
 Left(ltrim(TI.CNTR),1) In ('t') AND
 Left(ltrim(TI.TXTY),1) In ('R') AND
 left(ltrim(TI.TXTY),2) Not In ('RR','RX') AND
 TI.Qty <> 0
GROUP BY iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore)
  ) AS OnXferOut ON ITF.CurrentStore = OnXferOut.Store
   --GET Items on Transfer In
LEFT JOIN (SELECT right('000' + right(rtrim(CF.[KEY]),len(rtrim(CF.[KEY])) - (max(CHARINDEX('xfer-', CF.[Key]))+4)),3) AS Store,
sum([TI].[Qty]) AS XferIn
FROM TransactionItems TI
INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
INNER JOIN CustomerFile CF ON T.CUSN = CF.CNUM
INNER JOIN CTE AS ItemList ON ItemList.Num = TI.[Item]
WHERE --isnumeric(right(CF.[KEY],1)) = 1,
Left(T.[STAT],1) In ('O') AND
Left(ltrim(TI.CNTR),1) In ('t') AND
Left(ltrim(TI.TXTY),1) In ('R') AND
left(ltrim(TI.TXTY),2) Not In ('RR','RX') AND
TI.Qty <> 0
GROUP BY CF.[Key]
  ) AS OnXferIn ON ITF.CurrentStore = OnXferIn.Store
   --Get Items on Pickup
LEFT JOIN (SELECT iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore) AS Store, sum([TI].[Qty]) AS PickupQty
FROM TransactionItems TI
INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR]
INNER JOIN CTE AS ItemList ON ItemList.Num = TI.[Item]
WHERE Left(T.[STAT],1) In ('O') AND
 Left(ltrim(TI.CNTR),1) Not In ('c','h','q','r','s','t','w') AND
 Left(ltrim(TI.TXTY),1) In ('R') AND
 left(ltrim(TI.TXTY),2) Not In ('RR','RX') AND
 TI.Qty <> 0 AND
 T.Pickup <> 0
GROUP BY iif(ItemList.CurrentStore = '000',T.[Str],ItemList.CurrentStore)
  ) AS OnPickup ON ITF.CurrentStore = OnPickup.Store
WHERE ITF.[Type] In ('T','H','U','A','L') AND
      ITF.Inactive = 0 AND
 (
  (@ValueType = 'Item' AND @Value = ITF.NUM) or
  (@ValueType = 'Header' AND @Value = ITF.Header) or
  (@ValueType = 'Group' AND @Value = ITF.[Group]) or
  (@ValueType = 'Category' AND @ValueInt = ITF.[Category])
 )
GROUP BY ITF.CurrentStore,
         CASE
WHEN @ValueType = 'Item' THEN ITF.Name
WHEN @ValueType = 'Header' THEN ITF.Name
WHEN @ValueType = 'Group' THEN ITF.[GROUP]
WHEN @ValueType = 'Category' THEN ITC.[Name]
ELSE ''
END
) AS MainTbl ON PF.Store = MainTbl.CurrentStore
ORDER BY PF.Store

option (recompile)
END
go

