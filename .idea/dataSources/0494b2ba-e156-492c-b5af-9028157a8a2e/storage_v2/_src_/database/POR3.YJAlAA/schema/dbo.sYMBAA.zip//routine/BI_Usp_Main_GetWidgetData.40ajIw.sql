
CREATE PROCEDURE [dbo].[BI_Usp_Main_GetWidgetData]
	@WidgetDataFilter KeyValuePair READONLY -- pass parameters via Table Type Param
AS
BEGIN

	-------------------------------------------------------
	Declare @StoredProcDefaultId tinyint = 1; --Id in view table
	Declare @ViewId smallint = null;
	Declare @FilterQuery nvarchar(MAX) = null;
	Declare @StoreFilterField nvarchar(100) = null;
	Declare @DateFilterField nvarchar(100) = null;
	Declare @SalesRepFilterField nvarchar(100) = null;
	Declare @GroupByQuery nvarchar(255) = null;
	Declare @OrderByQuery nvarchar(255) = null;
	Declare @SelectQuery nvarchar(MAX);
	Declare @SortOrder nvarchar(4);
	Declare @ParamDef nvarchar(1000);
	
	SET NOCOUNT ON;	
	
	Declare @TemplateId int;
	Set @TemplateId	= (SELECT	CAST([Value] AS INT)	FROM @WidgetDataFilter WHERE [Key] = 'TemplateId');

	Declare @DateFormat nvarchar(5) = 'en-US'
	Set @DateFormat	= (SELECT	[Value]					FROM @WidgetDataFilter WHERE [Key] = 'DateFormat');

	-- Select Template 
	SELECT	@ViewId = WidgetViewId,
			@FilterQuery = FilterClause,
			@StoreFilterField = StoreFilterField,
			@DateFilterField = DateFilterField,
			@SalesRepFilterField = SalesRepFilterField,
			@GroupByQuery = GroupByClause,
			@OrderByQuery = OrderByClause,
			@SortOrder = WidgetSortOrder
			FROM dbo.BI_WidgetTemplates 
			WHERE BI_WidgetTemplates.ID = @TemplateId;

	-- =================================================================
	-- Using Views /Tables as Data Source
	-- ================================================================
	IF @ViewId > @StoredProcDefaultId
		BEGIN
		
			--Widget Data Filter Params ---------------------------
			Declare @StoreNo nvarchar(20) = null;
			Set @StoreNo	= (SELECT	SUBSTRING([Value], 1, 20)	FROM @WidgetDataFilter WHERE [Key] = 'StoreNo');

			Declare @CustomerNo nvarchar(6) = null; -- //CNUM
			Set @CustomerNo	= (SELECT	SUBSTRING([Value], 1, 6)	FROM @WidgetDataFilter WHERE [Key] = 'CustomerNo');

			Declare @ItemNo nvarchar(6) = null; -- //NUM
			Set @ItemNo		= (SELECT	SUBSTRING([Value], 1, 6)	FROM @WidgetDataFilter WHERE [Key] = 'ItemNo');

			Declare @ContractNo nvarchar(10) = null; -- //CNTR
			Set @ContractNo	= (SELECT	SUBSTRING([Value], 1, 10)	FROM @WidgetDataFilter WHERE [Key] = 'ContractNo');
			
			Declare @CurrentDate datetime = null;
			Set @CurrentDate= (SELECT	CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'CurrentDate');

			Declare @StartDate datetime = null;
			Set @StartDate	= (SELECT	CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'StartDate');

			Declare @EndDate datetime = null;
			Set @EndDate	= (SELECT	CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'EndDate');

			Declare @OperatorNo int = null;
			Set @OperatorNo	= (SELECT	CAST([Value] AS INT)		FROM @WidgetDataFilter WHERE [Key] = 'OperatorNo');

			Declare @GroupBy nvarchar(20) = null;
			Set @GroupBy	= (SELECT	SUBSTRING([Value], 1, 20)	FROM @WidgetDataFilter WHERE [Key] = 'GroupBy');

			Declare @GroupNo int = null;
			Set @GroupNo	= (SELECT	CAST([Value] AS INT)		FROM @WidgetDataFilter WHERE [Key] = 'GroupNo');
			
			Declare @SalesRep int = null;
			Set @SalesRep	= (SELECT	CAST([Value] AS INT)		FROM @WidgetDataFilter WHERE [Key] = 'SalesRep');

			Declare @CustomerTypeNo smallint = null;
			Set @CustomerTypeNo = (SELECT CAST([Value] AS smallint)	FROM @WidgetDataFilter WHERE [Key] = 'CustomerTypeNo'); 
			if(@CustomerTypeNo is null or @CustomerTypeNo = 0) set @CustomerTypeNo = 1;-- default to 1

			--Optional Parameters - Default values used in majority of templates
			Declare @DurationDays int = null; -- default to 30 days
			Set @DurationDays = (SELECT CAST([Value] AS INT)		FROM @WidgetDataFilter WHERE [Key] = 'DurationDays'); 
			if(@DurationDays is null or @DurationDays = 0) Set @DurationDays = 30;--default to 30

			Declare @DurationMonths int = null; -- default to 12 months
			Set @DurationMonths = (SELECT CAST([Value] AS INT)	FROM @WidgetDataFilter WHERE [Key] = 'DurationMonths'); 
			if(@DurationMonths is null or @DurationMonths = 0) set @DurationMonths = 12;--default to 12

			SET @ParamDef = N'@Today datetime, @StoreNo nvarchar(20), @DateFormat nvarchar(5), @CustomerNo nvarchar(6), @ContractNo nvarchar(10), @ItemNo nvarchar(6), @StartDate datetime, @EndDate datetime, @OperatorNo int, @GroupBy nvarchar(20), @GroupNo int, @SalesRep int, @DurationDays int, @DurationMonths int, @CustomerTypeNo smallint'; -- Parameter Definition for passing in parameters with sp_executesql --

			IF(@FilterQuery IS NOT NULL AND @StoreFilterField IS NOT NULL)
				SET @FilterQuery = @FilterQuery + ' AND (@StoreNo IS NULL OR @StoreNo = ''000'' OR (@StoreNo LIKE ''%'' + ' + @StoreFilterField + ' + ''%''))';

			IF(@FilterQuery IS NOT NULL AND @DateFilterField IS NOT NULL)
				SET @FilterQuery = @FilterQuery + ' AND ((@StartDate IS NULL OR (' + @DateFilterField + ' >= @StartDate)) AND (@EndDate IS NULL OR (' + @DateFilterField + ' <= @EndDate)))';
				
			IF(@FilterQuery IS NOT NULL AND @SalesRepFilterField IS NOT NULL)
				SET @FilterQuery = @FilterQuery + ' AND (@SalesRep IS NULL OR @SalesRep = 0 OR ' + @SalesRepFilterfield + ' IS NULL OR ' + @SalesRepFilterfield + ' = 0 OR ' + @SalesRepFilterField + ' = @SalesRep)';

			SET @SelectQuery = (SELECT N'SELECT ' + [SelectClause] 
										+ ' FROM ' + [QueryFromClause] 
										+ CASE WHEN @FilterQuery IS NOT NULL
											THEN ' WHERE ' +  @FilterQuery 
											ELSE '' END
										+ CASE WHEN @GroupByQuery IS NOT NULL 
											THEN ' GROUP BY ' + @GroupByQuery + ' ORDER BY ' + @OrderByQuery + ' ' + CASE WHEN  @SortOrder IS NOT NULL THEN @SortOrder ELSE 'ASC' END 
											ELSE '' END
						From BI_WidgetTemplates
						INNER JOIN [BI_WidgetViews]
						ON BI_WidgetTemplates.WidgetViewId = BI_WidgetViews.ID
						WHERE BI_WidgetTemplates.ID = @TemplateId );

			-------------------------------------------------------------------------------------------------------------------------------------------------
			EXEC sp_executesql @SelectQuery, @ParamDef, @Today = @CurrentDate, 
								@StoreNo = @StoreNo, @DateFormat = @DateFormat, 
								@CustomerNo = @CustomerNo, @ContractNo = @ContractNo, 
								@ItemNo = @ItemNo, @StartDate = @StartDate, 
								@EndDate = @EndDate, @OperatorNo = @OperatorNo, @GroupBy = @GroupBy, 
								@GroupNo = @GroupNo, @SalesRep = @SalesRep, 
								@DurationDays = @DurationDays, @DurationMonths = @DurationMonths, @CustomerTypeNo = @CustomerTypeNo;
			------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		END
	-------------------------------------------------------
	-- Using Stored Procedure as Data Source
	------------------------------------------------------
	ELSE IF @ViewId = @StoredProcDefaultId 
		BEGIN
			SET @SelectQuery = (Select [SelectClause] From BI_WidgetTemplates Where BI_WidgetTemplates.ID = @TemplateId);
			--------------------------------------------
			EXEC @SelectQuery @WidgetDataFilter;
			-------------------------------------------------
		END
END
go

