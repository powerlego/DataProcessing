
-- required stub only
CREATE FUNCTION dbo.fnAT_InvoiceType
(
   @ContractNumber   VARCHAR(20)
)
RETURNS VARCHAR(10)
-- WITH ENCRYPTION
AS

BEGIN
   DECLARE @SourceCode VarChar(10) 

   SET @SourceCode = 'HIRE'
 
   RETURN ISNULL(@SourceCode,'HIRE');
END
go

