
CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_GetOpenItems]
	@WidgetDataFilter KeyValuePair READONLY
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @StoreNo nvarchar(20) = null;
	SET @StoreNo	= (SELECT	SUBSTRING([Value], 1, 20)	FROM @WidgetDataFilter WHERE [Key] = 'StoreNo');

	-------------Using UNPIVOT --------------------------------------------
	SELECT Maintbl.[Type], SUM(maintbl.total) as [Total]
    FROM

		(SELECT 
			--0 as tabletotal,
            SUM(IIF(c.[KEY] LIKE 'REPAIRS-MAINT%',1,0)) AS [Open Maintenance (IMO)],
            SUM(IIF(c.[KEY] LIKE  'REPAIRS-SERV%',1,0)) AS [Open Service (ISO)],
            SUM(IIF(c.[KEY] NOT LIKE 'REPAIRS-MAINT%' AND c.[KEY] NOT LIKE 'REPAIRS-SERV%' AND LEFT(t.CNTR,1) = 'R',1,0)) AS [Open Repairs (IRO)],
            SUM(IIF(LEFT(t.CNTR,1) = 'W',1,0)) AS [Open Work Orders (WO)]

        FROM (	
			SELECT t.CUSN, t.STAT, t.[STR], t.CNTR 
			FROM Transactions t 
			INNER JOIN TransactionItems ti ON t.CNTR = ti.CNTR 
			WHERE ti.QTY <> 0 and ti.SUBF = 1
		) AS t
		LEFT OUTER JOIN CustomerFile c ON t.CUSN = c.CNUM
		WHERE	(@StoreNo IS NULL OR @StoreNo = '000' OR (@StoreNo LIKE '%' + T.[STR] + '%')) AND LEFT(t.CNTR,1) IN ('r','w') 
				AND LEFT(t.STAT,1) IN ('O','W') 
				AND RIGHT(LEFT(T.[STAT] + '  ',2),1) NOT IN ('C')
         ) AS W     
    UNPIVOT
		(Total FOR [Type] 
		IN (
			[Open Maintenance (IMO)],
			[Open Service (ISO)],
			[Open Repairs (IRO)],
			[Open Work Orders (WO)])
	) AS  Maintbl
	GROUP BY Maintbl.[type]

END
go

