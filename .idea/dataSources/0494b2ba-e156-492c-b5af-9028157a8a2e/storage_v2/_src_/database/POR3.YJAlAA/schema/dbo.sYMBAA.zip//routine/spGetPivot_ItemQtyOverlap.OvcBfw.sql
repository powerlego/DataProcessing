
CREATE PROCEDURE DBO.spGetPivot_ItemQtyOverlap
(
	@sTempTableName	VARCHAR(100)
)

AS

/*****************************************************************************************/
--	POR.DBO.spGetPivot_ItemQtyOverlap
--		Returns a table with totals summarized by month, pivoted on year
--
--	PARAMETERS: @sTempTableName  - The name of a working table built by the client in POR
--
--	HISTORY:	10/23/2014	JY	CREATED	--
--
--
/*****************************************************************************************/

BEGIN
SET NOCOUNT ON

-- "TRANSFORM Max([QtyOut]) AS [The Value] SELECT [Month], Max([QtyOut]) AS [Max Overlap] From [" & ResultTable1 & "] GROUP BY [Month] ORDER BY [Year] DESC PIVOT [Year];"

--SET @sTempTableName = '[POR.DBO.' + @sTempTableName + ']'

IF (OBJECT_ID(@sTempTableName) is null)
BEGIN
	RETURN
END

DECLARE @sSQL VARCHAR(5000)
DECLARE @sColumns AS VARCHAR(MAX)

CREATE TABLE #TMP_OVERLAP
([MONTH]		INTEGER,
 [YEAR]			INTEGER,
 [Max Overlap]	INTEGER
)

SET @sSQL = 'SELECT [Month], [Year], Max([QtyOut]) AS [Max Overlap] From ' + @sTempTableName + ' GROUP BY [Month], [Year] ORDER BY [Year], [Month]'

INSERT INTO #TMP_OVERLAP
EXEC(@sSQL)

--SELECT * FROM #TMP_OVERLAP

-- Get max by month for the total column
SELECT [MONTH], MAX([Max Overlap]) AS [The Value]
  INTO #TMP_ROLLUP
  FROM #TMP_OVERLAP
GROUP BY [MONTH]
ORDER BY [MONTH]

--select * from #tmp_rollup

-- Get a list of years for column names
select @sColumns = substring((Select DISTINCT ',' + QUOTENAME([YEAR]) FROM #TMP_OVERLAP FOR XML PATH ('')),2, 1000) 

--SELECT @sColumns

set @SSQL =
'SELECT *
INTO #TMP_PIVOT1
FROM #TMP_OVERLAP
PIVOT 
(
  MAX([Max Overlap]) 
  FOR [year] IN( ' + @sColumns + ' )) as [Max Overlap]; ' 

-- add the monthly total column to the pivot table
set @ssql = @ssql + 'SELECT P.MONTH AS [MONTH], T.[The Value], ' + @sColumns + ' FROM #TMP_PIVOT1 P JOIN #TMP_ROLLUP T ON P.MONTH = T.MONTH'

--select @ssql

execute(@ssql)


DROP TABLE #TMP_OVERLAP
DROP TABLE #TMP_ROLLUP

SET NOCOUNT OFF

END

go

