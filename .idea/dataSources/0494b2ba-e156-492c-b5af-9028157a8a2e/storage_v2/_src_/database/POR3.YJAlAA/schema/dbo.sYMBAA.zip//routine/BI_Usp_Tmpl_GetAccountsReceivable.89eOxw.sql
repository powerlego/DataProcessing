
CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_GetAccountsReceivable]
	@WidgetDataFilter KeyValuePair READONLY
	--@IntervalNumber int = 5 -- Number of Aging Buckets --TODO implement
AS
BEGIN
	SET NOCOUNT ON;

	-- Input variables ----------------------------------------
	DECLARE @SalesRepNo int = null;
	DECLARE @StoreNo nvarchar(20) = null;
	DECLARE @Interval int = null; -- No.of Days, No. of months-- TODO Get interval from ParamFile
	DECLARE @IntervalType nvarchar(1) = null; -- D:Day, M: Month, Y: Year -- TODO Get Type from ParamFile

	SET @SalesRepNo = (SELECT CAST([Value] AS INT) FROM @WidgetDataFilter WHERE [Key] = 'SalesRep');
	SET @StoreNo = (SELECT SUBSTRING([Value], 1, 20) FROM @WidgetDataFilter WHERE [Key] = 'StoreNo');
	SET @Interval = (SELECT CAST([Value] AS INT) FROM @WidgetDataFilter WHERE [Key] = 'ARInterval');
	SET @IntervalType = (SELECT SUBSTRING([Value], 1, 1) FROM @WidgetDataFilter WHERE [Key] = 'ARIntervalType');

	IF(@Interval IS NULL)
		SET @Interval = 30;
	IF(@IntervalType IS NULL)
		SET @IntervalType = 'D';
	IF(@SalesRepNo = 0)
		SET @SalesRepNo = NULL;

	-- Dependent Variables ------------------------------------
	DECLARE @Interval2 int = @Interval * 2;
	DECLARE @Interval3 int = @Interval * 3;
	DECLARE @Interval4 int = @Interval * 4;
	DECLARE @IntervalName nvarchar(16);
	DECLARE @Interval2Name nvarchar(16);
	DECLARE @Interval3Name nvarchar(16);
	DECLARE @Interval4Name nvarchar(16);
	DECLARE @Interval5Name nvarchar(16);
	DECLARE @SelectQry nvarchar(Max);
	DECLARE @SalesRepFilterQry nvarchar(Max);
	DECLARE @ParamDef nvarchar(255);
	DECLARE @Datepart nvarchar(10);

	SET @ParamDef = N'@StoreNo nvarchar(20), @SalesRepNo int, @Interval int, @Interval2 int, @Interval3 int, @Interval4 int';

	IF(@IntervalType = 'D') 
		-- Aging by days
		BEGIN
				SET @Datepart = 'day';
				SET @IntervalName = CONCAT('<=',@Interval,' days');
				SET @Interval2Name = CONCAT('31-',@Interval2,' days');
				SET @Interval3Name = CONCAT('61-',@Interval3,' days');
				SET @Interval4Name = CONCAT('91-',@Interval4,' days');
				SET @Interval5Name = CONCAT('>',@Interval4,' days');
		END
	ELSE IF(@IntervalType = 'M') 
		--Aging by Months
		BEGIN
			SET @Datepart = 'month';
				SET @IntervalName = DATENAME(month, GETDATE()); --Current Month -- ie.Dec
				SET @Interval2Name = DATENAME(month, DATEADD(month, -1,GETDATE())); -- previous Month
				SET @Interval3Name = DATENAME(month, DATEADD(month, -2,GETDATE())); -- previous Month * 2
				SET @Interval4Name = DATENAME(month, DATEADD(month, -3,GETDATE())); --previous Month * 3
				SET @Interval5Name = CONCAT('< ',@Interval4Name);
		END
	--ELSE 
	--	--Aging by Years
	--	BEGIN
	--		SET @Datepart = 'year';
	--			--SET @IntervalName = CONCAT('<=',@Interval,' days'); -- Current Year
	--			--SET @Interval2Name = CONCAT('31-',@Interval2,' days'); --Previous Year
	--			--SET @Interval3Name = CONCAT('61-',@Interval3,' days');
	--			--SET @Interval4Name = CONCAT('91-',@Interval4,' days');
	--			--SET @Interval5Name = CONCAT('>',@Interval4,' days');
	--	END
	

	-- Build Query----------------------------
	SET @SalesRepFilterQry = IIF(@SalesRepNo = -1, 'T.Salesman IN (0, NULL, '''') OR S.INACTIVE = 1', 
				'(@SalesRepNo IS NULL OR (T.Salesman = @SalesRepNo)) AND S.Number > 0');

	SET @SelectQry = N'SELECT Qry.SalesRep, Qry.[Type] as [Age], SUM(Qry.Account) as [AcctAR], SUM(Qry.Cash) AS [CashAR] 
						FROM (SELECT Main.SalesRep, Main.[Type], IIF(Main.Status = ''Account'',SUM(TOTAL),0) AS [Account],
								IIF(Main.Status = ''Cash'',SUM(TOTAL),0) AS [Cash]
								FROM(SELECT IIF(S.Name IS NULL, ''None'', S.Name) AS SalesRep, 
										IIF(T.PYMT = ''E'',''Account'',''Cash'') AS [Status],
										SUM(IIF(DateDiff(' + @Datepart +',T.CLDT, GetDate()) <= @Interval,T.Totl - T.Paid,0)) AS ' + QUOTENAME(@IntervalName) + N', 
										SUM(IIF(DateDiff(' + @Datepart +',T.CLDT, GetDate()) > @Interval and DateDiff(' + @Datepart +',T.CLDT,GetDate()) <= @Interval2,T.Totl - T.Paid,0)) AS ' + QUOTENAME(@Interval2Name) + N',
										SUM(IIF(DateDiff(' + @Datepart +',T.CLDT, GetDate()) > @Interval2 and DateDiff(' + @Datepart +',T.CLDT,GetDate()) <= @Interval3,T.Totl - T.Paid,0)) AS ' + QUOTENAME(@Interval3Name) + N',
										SUM(IIF(DateDiff(' + @Datepart +',T.CLDT, GetDate()) > @Interval3 and DateDiff(' + @Datepart +',T.CLDT,GetDate()) <= @Interval4,T.Totl - T.Paid,0)) AS ' + QUOTENAME(@Interval4Name) + N',
										SUM(IIF(DateDiff(' + @Datepart +',T.CLDT, GetDate()) > @Interval4,T.Totl - T.Paid,0)) AS ' + QUOTENAME(@Interval5Name) + N'
										FROM dbo.Transactions T
											LEFT JOIN dbo.Salesman S 
											ON T.Salesman = S.Number
										WHERE (T.PYMT <> ''T'') AND (@StoreNo IS NULL OR @StoreNo = ''000'' OR (@StoreNo LIKE ''%'' + T.[Str] + ''%'')) AND (@SalesRepNo IS NULL OR (T.Salesman = @SalesRepNo)) AND S.Number > 0
										GROUP BY T.Salesman, S.Name, IIF(T.PYMT = ''E'',''Account'',''Cash'')
								) AS Calc
								UNPIVOT(TOTAL FOR [Type] IN (
										Calc.' + QUOTENAME(@IntervalName) + ', Calc.' + QUOTENAME(@Interval2Name) + ', Calc.' + QUOTENAME(@Interval3Name) + ', Calc.' + QUOTENAME(@Interval4Name) + ', Calc.' + QUOTENAME(@Interval5Name) + '
										)) Main
								GROUP BY Main.[Type], Main.[SalesRep], Main.[Status]
						) AS Qry
						GROUP By Qry.SalesRep, Qry.[Type]
						ORDER by Qry.SalesRep, 
							CASE Qry.[Type]
								WHEN ''' +  @IntervalName + '''THEN 1
								WHEN ''' +  @Interval2Name + '''THEN 2
								WHEN ''' +  @Interval3Name + '''THEN 3
								WHEN ''' +  @Interval4Name + '''THEN 4
								WHEN ''' +  @Interval5Name + '''THEN 5 END ASC';

	-- Run Query
	EXEC sp_executesql @SelectQry, @ParamDef, @StoreNo = @StoreNo, @SalesRepNo = @SalesRepNo, @Interval = @Interval, @Interval2 = @Interval2, @Interval3 = @Interval3, @Interval4 = @Interval4;
END
go

