
CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_AverageAge]
       @WidgetDataFilter KeyValuePair READONLY
AS

BEGIN

SET NOCOUNT ON;

		DECLARE @Group VarChar(50) = 'Customer Type';
		SELECT @Group = SUBSTRING([Value], 1, 1000) FROM @WidgetDataFilter WHERE [Key] = 'AgeBucketGroup';

		CREATE TABLE #Average_Age (
			[YearLbl] Nvarchar(50),
			[No.] Nvarchar(50),
			[Name] Nvarchar(50),
			[YearAge] int
		)

		INSERT INTO #Average_Age
		(Yearlbl,[No.],Name, YearAge)
    
		SELECT	AvgDays.YearLbl, 
			IIF(AvgDays.Togroupby is null,'None',AvgDays.Togroupby) AS 'No.',
			IIF(avgDays.Descgroupby is null,'None',AvgDays.Descgroupby) AS 'Name',
			AvgDays.YearAge
		FROM(

			Select YearGrp.YearLbl, YearGrp.Togroupby, YearGrp.Descgroupby,  (sum(YearGrp.AvgAge)/count(YearGrp.Contracts)) as yearage
			From (
				   Select iif( Year(GetDAte())=Year(T.Completed),'Year-0', iif(Year(getdate())-1=Year(T.completed),'Year-1','Year-2')) as YearLbl,
					Case
						When @Group = 'Customer' then Convert(varchar(50),C.CNum) 
						when  @Group = 'Customer Type' then convert(varchar(50),CT.Type)
						when  @Group = 'Customer Group' then convert(varchar(50),CG.Customergroup)
						when  @Group = 'Operator' then convert(varchar(50),C.OperatorAssigned)
						When  @Group = 'Salesrep' then convert(varchar(50),Salesman.Number)
					End as Togroupby,
					Case
						When @Group = 'Customer' then C.[Name] 
						when  @Group = 'Customer Type' then CT.[Description]
						when  @Group = 'Customer Group' then CG.GroupName
						when  @Group = 'Operator' then Oper.OPNM
						When  @Group = 'Salesrep' then Salesman.[Name]
					End as Descgroupby,
					(t.CNTR) as Contracts,
					datediff(d,T.CLDT,T.Completed) AS AvgAge
				   From (((((Transactions t
						Left outer join ParameterFile P on T.[STR] = P.Store)
						Left outer join Customerfile C on T.CUSN = C.CNUM)
						Left join Salesman On C.Salesman = Salesman.Number)
						Left Join CustomerType CT ON C.Type = CT.Type)
						Left Join CustomerGroup CG ON C.[Group] = CG.CustomerGroup)
						Left Join OperatorID Oper ON C.OperatorAssigned = Oper.OPNO
				   Where
						left (t.CNTR,1) not in  ('r', 'c', 'f') and
						t.PYMT = 'E' and
						t.TOTL > 0.00 and
						t.Completed-t.CLDT >=1  and
						Year(T.Completed) >= Year(Getdate())-2
				UNION

				Select iif( Year(GetDAte())=Year(T.Completed),'Year-0', iif(Year(getdate())-1=Year(T.completed),'Year-1','Year-2')) as YearLbl,
				Case
				  When @Group = 'Customer' then Convert(varchar(50),C.CNum) 
				  when  @Group = 'Customer Type' then convert(varchar(50),CT.Type)
				  when  @Group = 'Customer Group' then convert(varchar(50),CG.Customergroup)
				  when  @Group = 'Operator' then convert(varchar(50),C.OperatorAssigned)
				  When  @Group = 'Salesrep' then convert(varchar(50),Salesman.Number)
				  End as Togroupby,
				Case
				  When @Group = 'Customer' then C.[Name] 
				  when  @Group = 'Customer Type' then CT.[Description]
				  when  @Group = 'Customer Group' then CG.GroupName
				  when  @Group = 'Operator' then Oper.OPNM
				  When  @Group = 'Salesrep' then Salesman.[Name]
				  End as Descgroupby,
				(t.CNTR) as Contracts,
				datediff(d,T.CLDT,T.Completed) AS AvgAge
				From  (((((TransHistory t
						Left outer join ParameterFile P on T.[STR] = P.Store)
						Left outer join Customerfile C on T.CUSN = C.CNUM)
						Left join Salesman On C.Salesman = Salesman.Number)
						Left Join CustomerType CT ON C.Type = CT.Type)
						Left Join CustomerGroup CG ON C.[Group] = CG.CustomerGroup)
						Left Join OperatorID Oper ON C.OperatorAssigned = Oper.OPNO
				Where
					  left (t.CNTR,1) not in  ('r', 'c', 'f') and
					  t.PYMT = 'E' and
					  t.TOTL > 0.00 and
					  t.Completed-t.CLDT >=1  and
					  Year(T.Completed) >= Year(Getdate())-2
				  ) AS YearGrp
              Group by YearGrp.ToGroupby, YearGrp.Descgroupby, YearGrp.YearLbl
	) AS AvgDays

	Order by AvgDays.ToGroupBy

-- Query ======================================

	DECLARE @cols AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX)
	SELECT @cols = STUFF(
					(SELECT distinct ',' + QUOTENAME(YearLbl)
						FROM #Average_Age
						ORDER BY ',' + QUOTENAME(YearLbl) Asc
						FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)')
        ,1,1,'')

	SET @query = 'SELECT [No.], Name,  ' + @cols + ' FROM
				 (
					SELECT [No.], Name, YearLbl, YearAge
					FROM #Average_Age
				) x
				PIVOT
				(
				   min(YearAge) for YearLbl in (' + @cols + ')
				) p '

 

EXECUTE(@query)
DROP TABLE #Average_Age

END
go

