
--------------------------------------------------------------

CREATE VIEW [dbo].[BI_VW_Items_SerializedFleet]

 

AS

SELECT

       ITF.Qty, ItemQty.[OnRent]

       , ItemQty.[OffRent]

       , ItemQty.[IRO]

       , ItemQty.[IMO]

          , ItemQty.[ISO]

       , iif(ITF.QTY - (ItemQty.[OnRent] + ItemQty.[OffRent] + ItemQty.[IRO]) is null, ITF.Qty, ITF.QTY - (ItemQty.[OnRent] + ItemQty.[OffRent] + ItemQty.[IRO])) AS Ready

       , ITF.[KEY] AS ItemKey

       , ITF.[Name] AS ItemName

       , ITF.[Qty] AS ItemQty

       , ITF.[QYOT] AS QtyOut

       , ITF.[Type] AS ItemType

       , ITF.[Num] AS ItemNum

       , ITF.[CNTR] AS ItemCntr

       , ITF.[PURP] AS ItemPurp

       , ITF.[CurrentStore]

       , ITF.[HomeStore]

       , ITF.[Header] AS ItemHeader

       , ITF.[ReplacementCost] AS ItemReplaceCost

       , ITF.[BulkItem]

       , ITF.[Inactive]

       , ITF_h.[KEY] AS HeaderKey

       , ITF_h.[Name] AS HeaderName

       , ITF_h.[Num] AS HeaderNum

       , ITF_h.[ReplacementCost] AS HeaderReplaceCost

       , PF.[STORE_NAME] AS CurrentStoreName

       , ITC.[Name] AS CategoryName

       , ITF.[Category] AS CategoryNumber

       , ITD.[DivisionName] AS DivisionName

       , ITF_OEC.OEC AS OEC

FROM (((((ItemFile ITF

     LEFT JOIN ItemFile AS ITF_h ON ITF.[Header] = ITF_h.[KEY])

     LEFT JOIN ParameterFile PF ON ITF.[CurrentStore] = PF.[Store])

     LEFT JOIN ItemCategory ITC ON ITF.[Category] = ITC.[Category])

     LEFT JOIN ItemDivision ITD on ITC.[DivisionNumber] = ITD.[DivisionNumber])

     LEFT JOIN (SELECT TI.[ITEM],

                       sum(iif(Left(TI.[CNTR],1)<>'r' and (not(TI.[TXTY] In ('RR','RX')) or TI.[TXTY] = 'RH' and TI.[DDT] > getdate()),[TI].[Qty],0)) AS OnRent,

                       sum(iif(Left(TI.[CNTR],1)<>'r' and TI.[TXTY] = 'RH' and TI.[DDT] <= getdate(),[TI].[Qty],0)) AS OffRent,

                       sum(iif(Left(TI.[CNTR],1)='r' and Not(TI.[TXTY] In ('RR','RX')),[TI].[Qty],0)) AS IRO,

                       sum(iif(Left(TI.[CNTR],1)='r' and TI.[TXTY] In ('RR','RX'),[TI].[Qty],0)) AS IMO,

                                      sum(iif(cf.[KEY] LIKE 'REPAIRS-SERV%' and TI.SUBF = 1,TI.Qty,0)) AS ISO

                FROM ((TransactionItems TI

                       INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR])

                       INNER JOIN ItemFile ITF ON TI.[Item] = ITF.[Num])

                       INNER JOIN CustomerFile CF ON T.[CUSN] = CF.[CNUM]

                WHERE Left(TI.[CNTR],1) Not In ('c','f','l','q','t','w') AND

                      Left(TI.[TXTY],1) = 'R' and

                      Left(T.[STAT],1) = 'O' and

                      ITF.Qty < 99000

                GROUP BY TI.[Item]

                       ) AS ItemQty ON ITF.[Num] = ItemQty.[Item])

     LEFT JOIN (SELECT [ItemNumber] ,sum(([QuantityPurchased] - [QuantitySold]) * ([PriceEach] + [ExtraCharges])) AS OEC

                FROM [ItemPurchaseDetail]

                WHERE [Disposed] = 0

                GROUP BY [ItemNumber]) AS ITF_OEC ON ITF.[NUM] = ITF_OEC.[ItemNumber]

WHERE not(ITF.[TYPE] in ('b','e','f','i','k','m','n','o','p','s','v','w'))

              AND ITF.Qty < 90000


go

