
CREATE VIEW [dbo].[vwAT_CustomersPendingExport] 
--WITH ENCRYPTION 
AS
SELECT
 cst.ID							As CST_ID
,RTRIM(LTRIM(ISNULL(ac.AccountingLink, cf.[CNUM])))		As CST_ACCOUNT_NUMBER
,cst.CustomerName				As CST_NAME
,ISNULL(tx.AccountingLink,'')	As CST_TAX_CODE
,ISNULL(cf.FederalId, cf.SocialSecurity)	As CST_VAT_NUMBER
,cf.Email						As CST_EMAIL_ID
,''								As CST_WEB_SITE_URL
,cst.CustomerAddress1			As ADR_LINE1
,cst.CustomerAddress2			As ADR_LINE2
,''								As ADR_LINE3
,cst.CustomerCityState			As ADR_TOWN 
,''								As ADR_COUNTY
,cst.CustomerZip				As ADR_POSTCODE
,cst.customerphone				AS ADR_TELEPHONE
,cst.customerfax				AS ADR_FAX
,Cast(IsNull(ce.AccountingLink, '') As VarChar(3))	AS CUR_ACCOUNTS_CURRENCY_CODE
,cc.Alpha2Code					AS COU_ACCOUNTS_COUNTRY_CODE
,cc.[Description]				AS COU_NAME
,''								AS CompanyType
,CAST(NULL AS Varchar(60))		AS ACCOUNTS_CODE_1
,CAST(NULL AS Varchar(60))		AS ACCOUNTS_CODE_2
,cf.BillContact					AS ContactName
,0								AS BUS_AREA_ID
,ISNULL(cf.FederalId,'')		As CST_COMPANY_REG_NO
,cf.CreditLimit					As CST_CREDIT_LIMIT
FROM [dbo].[AccountingAPIQueueCustomer] AS cst
INNER JOIN [dbo].[CustomerFile] AS cf ON cf.CNUM = cst.CustomerNumber
LEFT OUTER JOIN [dbo].[CurrencyExchange] AS ce ON ce.CurrencyNumber = cst.CustomerCurrencyNumber
LEFT OUTER JOIN [dbo].[TaxTable] AS tx ON tx.TaxCode = cf.TaxCode
LEFT OUTER JOIN [dbo].[AccountingCustomer] AS ac ON ac.Id = cf.AccountingCustomerId
LEFT OUTER JOIN [dbo].[CountryCodes] cc on cc.Id = cf.CountryCode
WHERE cst.DateApproved IS NOT NULL
  AND cst.DatePosted IS NULL
  AND cst.DateCancelled IS NULL
  AND cst.RetryCount <= 10

go

grant select on vwAT_CustomersPendingExport to PORUser
go

