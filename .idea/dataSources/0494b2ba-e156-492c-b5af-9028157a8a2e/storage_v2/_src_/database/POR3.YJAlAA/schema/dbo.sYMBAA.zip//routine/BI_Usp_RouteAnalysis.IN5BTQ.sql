
CREATE PROCEDURE [dbo].[BI_Usp_RouteAnalysis]
@WidgetDataFilter KeyValuePair READONLY
AS

BEGIN

SET NOCOUNT ON;

-- Default values -------------
Declare @DateFormat nvarchar(5) = 'en-US';

DECLARE @Style        Int = 1;
DECLARE	@DateRpt      Date = CONVERT(Date, GETDATE());
DECLARE	@Driver       VarChar(50) = 'All';
DECLARE	@StoreNo      VarChar(3) = null;

SELECT @Style = CAST([Value] AS INT) FROM @WidgetDataFilter WHERE [Key] = 'PeriodStyle';
SELECT @StoreNo = SUBSTRING([Value], 1, 20) FROM @WidgetDataFilter WHERE [Key] = 'StoreNo';
SELECT @Driver  = SUBSTRING([Value], 1, 50) FROM @WidgetDataFilter WHERE [Key] = 'Driver';
SELECT @DateRpt = CAST([Value] AS DATE)	FROM @WidgetDataFilter WHERE [Key] = 'SelectedDate';
SELECT @DateFormat	= [Value] FROM @WidgetDataFilter WHERE [Key] = 'DateFormat';

DECLARE @PeriodTypeId      Int,
        @PeriodName        Varchar(10),
        @StartDate         Date,
        @EndDate           Date;

Create Table #tmp_results
(     
	[Period]                  Varchar(6),
	[Beg]                      varchar(10),
	[End]                      varchar(10),
	[Store]                    VarChar(3),
	[Driver]                   VarChar(50),
	[Stops]                    Int,
	[ReqNumberLate]            Int,
	[PlanNumberLate]           Int,
	[ReqMinutesLate]			Int,
	[PlanMinutesLate]			Int
)

SET @PeriodTypeId = 1

WHILE (@PeriodTypeId <= 4)
BEGIN

IF (@Style = 1 )

       BEGIN

       SET @PeriodName = (Select Case @PeriodTypeId
                            When 1 then 'CM'
                            When 2 then 'LM'
                            When 3 then 'TMLY'
                            When 4 then 'TTM' End)

       SET @StartDate = (Select Case @PeriodTypeId
                            When 1 then DateAdd(day,1,EOMonth(@DateRpt,-1))
                            When 2 then DateAdd(day,1,EOMonth(@DateRpt,-2))
                            When 3 then DateAdd(yyyy,-1,DateAdd(day,1,EOMonth(@DateRpt,-1)))
                            When 4 then DateAdd(mm,-11,DateAdd(day,1,EOMonth(@DateRpt,-1))) End)

       SET @EndDate = (Select Case @PeriodTypeId
                            When 1 then EOMonth(@DateRpt)
                            When 2 then EOMonth(@DateRpt,-1)
                            When 3 then DateAdd(yyyy,-1,EOMonth(@DateRpt))
                            When 4 then EOMonth(@DateRpt) End)
       END

ELSE IF (@Style = 2)

    BEGIN

       SET @PeriodName = (Select Case @PeriodTypeId
                            When 1 then 'MTD'
                            When 2 then 'LMTD'
                            When 3 then 'YTD'
                            When 4 then 'LYTD' End)

       SET @StartDate = (Select Case @PeriodTypeId
                            When 1 then DateAdd(day,1,EOMonth(@DateRpt,-1))
                            When 2 then DateAdd(day,1,EOMonth(@DateRpt,-2))
							When 3 then DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))
                            When 4 then DateAdd(yyyy,-1,DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))) End)

       SET @EndDate = (Select Case @PeriodTypeId
                            When 1 then @DateRpt
                            When 2 then DateAdd(mm,-1,@DateRpt)
                            When 3 then @DateRpt
                            When 4 then DateAdd(yyyy,-1,@DateRpt) End)
       END

ELSE IF (@Style = 3)

    BEGIN

       SET @PeriodName = (Select Case @PeriodTypeId
							When 1 then 'MTD'
                            When 2 then 'LYMTD'
                            When 3 then 'YTD'
                            When 4 then 'LYTD' End)

       SET @StartDate = (Select Case @PeriodTypeId
							When 1 then DateAdd(day,1,EOMonth(@DateRpt,-1))
                            When 2 then DateAdd(yyyy, -1,DateAdd(day,1,EOMonth(@DateRpt,-1)))
                            When 3 then DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))
                            When 4 then DateAdd(yyyy,-1,DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))) End)

       SET @EndDate = (Select Case @PeriodTypeId
							When 1 then @DateRpt
                            When 2 then DateAdd(yyyy,-1,@DateRpt)
                            When 3 then @DateRpt
                            When 4 then DateAdd(yyyy,-1,@DateRpt) End)
       END

ELSE

    BEGIN

       SET @PeriodName = (Select Case @PeriodTypeId
							When 1 then 'CW'
                            When 2 then 'CM'
                            When 3 then 'CQ'
                            When 4 then 'CY' End)

       SET @StartDate = (Select Case @PeriodTypeId
							When 1 then Convert(date,DateAdd(wk, DATEDIFF(wk, 0, @DateRpt),-1)) --starts sunday
                            When 2 then DateAdd(day,1,EOMonth(@DateRpt,-1))
                            When 3 then DateAdd(qq, DatePart(qq,@DateRpt) - 1, DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))) 
                            When 4 then DateAdd(day,1,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt))) End)

       SET @EndDate = (Select Case @PeriodTypeId
							When 1 then Convert(date,DateAdd(wk, DATEDIFF(wk, 0, @DateRpt),5))
                            When 2 then EOMonth(@DateRpt)
                            When 3 then DateAdd(qq, DatePart(qq,@DateRpt), DateAdd(day,0,EOMonth(DateAdd(mm,-month(@DateRpt),@DateRpt)))) 
                            When 4 then Convert(date, DateAdd(yy, DateDiff(yy, 0, @DateRpt) + 1, -1)) End)
       END


INSERT INTO #tmp_results

SELECT	@PeriodName AS [Period], 
		Format(@StartDate,'d', @DateFormat) AS Beg,  
		Format(@EndDate,'d', @DateFormat)  AS [End], 
		MainTbl.Store, 
		MainTbl.Driver, 
		count(MainTbl.ContractNumber) AS [Stops], 
		sum(MainTbl.ReqOnTime) AS [ReqNumberLate], 
		sum(MainTbl.PlannedOnTime) AS [PlanNumberLate],
		sum(MainTbl.ReqDiff) AS [ReqMinutesLate], 
		sum(MainTbl.PlannedDiff) AS [PlanMinutesLate]

FROM (

              SELECT Main.*,

                        iif(Main.ActualArrival Is Null,0,iif(Main.ActualArrival <= Main.ReqByTime,0,1)) AS ReqOnTime,

                        iif(Main.ActualArrival Is Null or Main.Planned Is Null,0,iif(Main.ActualArrival <= Main.Planned,0,1)) AS PlannedOnTime,

                        iif(Main.ActualArrival Is Null,0,iif(Main.ActualArrival > Main.ReqByTime,DateDiff(Minute,Main.ReqByTime,Main.ActualArrival),0)) AS ReqDiff,

                        iif(Main.ActualArrival Is Null,0,iif(Main.ActualArrival > Main.Planned,DateDiff(Minute,Main.Planned,Main.ActualArrival),0)) AS PlannedDiff

              FROM (

                        SELECT MRD.ContractNumber, MR.routeNumber AS [Route], MR.tripDate AS [Trip Date], IIF(@StoreNo IS NULL OR @StoreNo = '000' OR @StoreNo = 'All','All',MR.startStore) AS Store, MR.driverID AS [Driver ID], IIF(@Driver = 'All','All',OPR.OPNM) AS [Driver], MRD.preferredArrival AS [Required], DATEADD(day, DATEDIFF(day, 0, CONVERT(Date,MRD.preferredArrival)), CONVERT(datetime,CONVERT(TIME,IIF(MRD.MPEstimatedArrivalTime is null, '', MRD.MPEstimatedArrivalTime)))) AS Planned,

                                    (CASE

                                                WHEN DATEPART(HOUR,   MRD.preferredArrival) = 00 THEN CONVERT(DateTime, DateDiff(Day,1,Convert(Date, MRD.preferredArrival)))

                                                WHEN DATEPART(SECOND, MRD.preferredArrival) = 00 THEN MRD.preferredArrival

                                                WHEN DATEPART(SECOND, MRD.preferredArrival) = 42 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST('12:30 PM' AS Datetime))

                                                WHEN DATEPART(SECOND, MRD.preferredArrival) > 42 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST(CONCAT(DATEPART(SECOND, MRD.preferredArrival) - 42, ':30 PM') AS Datetime))

                                                WHEN DATEPART(SECOND, MRD.preferredArrival) > 29 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST(CONCAT(DATEPART(SECOND, MRD.preferredArrival) - 30,':30 AM') AS Datetime))

                                                WHEN DATEPART(SECOND, MRD.preferredArrival) > 12 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST(CONCAT(DATEPART(SECOND, MRD.preferredArrival) -12, ':00 PM') AS Datetime))

                                                WHEN DATEPART(SECOND, MRD.preferredArrival) = 12 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST('12:00 PM' AS Datetime))

                                                WHEN DATEPART(SECOND, MRD.preferredArrival) < 12 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST(CONCAT(DATEPART(SECOND, MRD.preferredArrival),':00 AM') AS Datetime))

                                    END) AS ReqByTime, MRD.ActualArrival

                        FROM MapRouteDetails MRD

                                INNER JOIN MapRoutes MR ON MRD.routeNumber = MR.routeNumber

                                INNER JOIN OperatorID OPR ON MR.driverID = OPR.OPNO

                        WHERE MR.tripDate >= @StartDate AND

                                MR.tripDate <= @EndDate AND

                                MR.driverID > 0 AND

                                MR.startStore <> '000' AND

                                (@Driver = 'All' OR @Driver = OPR.OPNM) AND

                               (@StoreNo IS NULL OR @StoreNo = 'All' OR @StoreNo = '000' OR (@StoreNo LIKE '%' + MR.startStore + '%'))

                        ) AS Main

              ) AS MainTbl

GROUP BY MainTbl.Store, MainTbl.Driver

       Set @PeriodTypeId = @PeriodTypeId + 1
END

SELECT * From #tmp_results

DROP TABLE #tmp_results


END
go

