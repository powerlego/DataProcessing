
CREATE VIEW [dbo].[vwAT_AllCustomersWithAging] 
--WITH ENCRYPTION 
AS
SELECT
 CAST(cst.AccountingCustomerId AS Integer)	AS CST_ID
,cst.[NAME]								AS CST_NAME
,RTRIM(LTRIM(cst.CNUM))				    AS ACCOUNT_NUMBER
,cst.CreditLimit						AS CST_CREDIT_LIMIT
,cst.CurrentBalance						AS CST_ACCT_BALANCE
,0										AS CST_ON_HOLD
--,''										AS CST_UNPAID_INVS
-- Replicate Syrinx Unpaid_Invs string
,Unpaid.UNPAID_INVS					    AS CST_UNPAID_INVS
,cst.Status							    AS CST_CTYPE
,CAST(0 AS DECIMAL(12,2))				AS CST_AGED_DEBT_1
,CAST(0 AS DECIMAL(12,2))				AS CST_AGED_DEBT_2
,CAST(0 AS DECIMAL(12,2))				AS CST_AGED_DEBT_3
,CAST(0 AS DECIMAL(12,2))				AS CST_AGED_DEBT_4
,CAST(0 AS DECIMAL(12,2))				AS CST_AGED_DEBT_5
,''										AS CST_COMPANY_REG_NO
,TaxId								    AS CST_VAT_NUMBER
,1									    AS CST_CURRENT_FLAG
,cst.[Address]							AS ADR_LINE1
,cst.Address2							AS ADR_LINE2
,''										AS ADR_LINE3
,cst.CITY							    AS ADR_TOWN
,''										AS ADR_COUNTY
,cst.ZIP								AS ADR_POSTCODE
,cst.Phone								AS ADR_TELEPHONE
,cst.FAX								AS ADR_FAX
,'GB'									AS COU_ACCOUNTS_COUNTRY_CODE
,0 AS BUS_AREA_ID
FROM  dbo.CustomerFile AS cst
-- Replicate Syrinx Unpaid_Invs string
LEFT OUTER JOIN (SELECT CUSN, '' AS UNPAID_INVS
				   FROM Transactions Tr 
				  WHERE Tr.TOTL - Tr.PAID > 0 
				    AND Tr.Archived = 0
					AND CMDT IS NOT NULL
				  GROUP BY CUSN) AS Unpaid ON Unpaid.CUSN = cst.CNUM

go

grant select on vwAT_AllCustomersWithAging to PORUser
go

