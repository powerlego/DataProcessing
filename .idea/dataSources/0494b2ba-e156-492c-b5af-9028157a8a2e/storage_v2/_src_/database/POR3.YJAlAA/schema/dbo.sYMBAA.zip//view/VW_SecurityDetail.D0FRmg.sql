
CREATE VIEW [dbo].[VW_SecurityDetail] 
	AS
	SELECT
			O.OPNO                                     ,
			SL.SecurityListId                          ,
			SA.SecurityAreaName       AS SecurityArea  ,
			SL.SecurityDescription                     ,
			EmployeeLevel.AllowAccess AS EmployeeAccess,
			GroupLevel.AllowAccess    AS GroupAccess   ,
			CompanyLevel.AllowAccess  AS CompanyAccess ,
			SL.DefaultAllowAccess     AS DefaultAccess ,
			ISNULL(ISNULL(ISNULL(EmployeeLevel.AllowAccess, GroupLevel.AllowAccess), CompanyLevel.AllowAccess), SL.DefaultAllowAccess) AS AllowAccess   ,
			CASE WHEN EmployeeLevel.AllowAccess IS NOT NULL THEN 'Employee' 
			ELSE (CASE WHEN GroupLevel.AllowAccess IS NOT NULL THEN 'Group' 
			ELSE (CASE WHEN CompanyLevel.AllowAccess IS NOT NULL THEN 'Company' 
																	ELSE 'Default' END) END) END AS [Level]
	FROM
			dbo.OperatorId AS O
	CROSS JOIN
			dbo.SecurityList AS SL
	LEFT OUTER JOIN
			dbo.SecurityDetail AS EmployeeLevel
		ON
				SL.SecurityListId            = EmployeeLevel.SecurityListId
		AND     EmployeeLevel.SecurityTypeId = 5
		AND     EmployeeLevel.SecurityLink   = O.OPNO
	LEFT OUTER JOIN
			(
					SELECT
							SD.SecurityListId,
							OG.OpNo          ,
							CAST((MAX(CAST(SD.AllowAccess AS TINYINT))) AS BIT) AS AllowAccess
					FROM
							dbo.SecurityDetail AS SD
					INNER JOIN
							dbo.OperatorIdGroupFileXref AS OG
					ON
							SD.SecurityLink   = OG.GroupNumber
					AND     SD.SecurityTypeId = 2
					WHERE
							OG.Inactive = 0
					GROUP BY
							SD.SecurityListId,
							OG.OpNo) AS GroupLevel
		ON
				SL.SecurityListId = GroupLevel.SecurityListId
		AND     GroupLevel.OpNo   = O.OPNO
	LEFT OUTER JOIN
			dbo.SecurityDetail AS CompanyLevel
		ON
				SL.SecurityListId = CompanyLevel.SecurityListId
		AND     CompanyLevel.SecurityTypeId = 1
	LEFT OUTER JOIN
			dbo.SecurityArea AS SA
		ON
				SL.SecurityAreaId = SA.Id
go

