
CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_IRO_IMO_ISO_Summary]
	@WidgetDataFilter KeyValuePair READONLY 
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE	@StoreNo VarChar(3) = null;
	SELECT @StoreNo = SUBSTRING([Value], 1, 20) FROM @WidgetDataFilter WHERE [Key] = 'StoreNo';

	SELECT 
		OECTYPE.Type AS [Description], 
		OECTYPE.NumofItems AS [Quantity], 
		CAST(OECTYPE.OEC AS [MONEY]) AS [OEC], 
		CAST(Whole.FleetOEC AS [MONEY]) AS [TotalOEC], 
		CONVERT(varchar(50),CAST(OECTYPE.OEC AS [MONEY]) / CAST(WHOLE.FLEETOEC AS [MONEY])*100)+'%' AS [PercentOEC]
	FROM(
		SELECT ' ' AS ID, typetbl.TYPE, COUNT(typetbl.NumType) AS 'NumofItems', SUM(Typetbl.OEC) AS OEC
		FROM(
			SELECT 'IRO' AS TYPE, Trans.ItemNum, Trans.NumType, ITF_OEC.OEC
			FROM(
				SELECT ItemQty.ItemNum, COUNT(ItemQty.TypeRepair) AS Numtype, ItemQty.CNTR
				FROM(  
					SELECT TI.ITEM AS ItemNum, COUNT(TI.ITEM) AS TypeRepair, T.CNTR
					FROM (TransactionItems TI
                       INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR])
                       INNER JOIN ItemFile ITF ON TI.[Item] = ITF.[Num]
					   INNER JOIN CustomerFile CF ON T.[CUSN] = CF.[CNUM]
					WHERE
                      LEFT(TI.[TXTY],1) = 'R' 
                      AND LEFT(T.[STAT],1) = 'O' 
                      AND (@StoreNo IS NULL OR @StoreNo = '000' OR (@StoreNo LIKE '%' + T.[STR] + '%'))
					  AND LEFT(TI.CNTR,1) IN ('r')
					  AND TI.[TXTY] NOT IN ('RR','RX')
					  AND CF.[KEY] NOT LIKE 'REPAIRS-MAINT%' 
					  AND CF.[KEY] NOT LIKE 'REPAIRS-SERV%'
					  AND TI.SUBF = 1
					GROUP BY TI.[Item], T.CNTR
					) AS ItemQty 
				GROUP BY 
					ItemQty.Itemnum, ItemQty.CNTR
				) AS Trans
			LEFT JOIN (
						SELECT [IPD].[ItemNumber], SUM(([IPD].[QuantityPurchased] - [IPD].[QuantitySold]) * ([IPD].[PriceEach] + [IPD].[ExtraCharges])) AS OEC
						FROM [ItemPurchaseDetail] AS [IPD]
						WHERE [Disposed] = 0
						GROUP BY [ItemNumber]
						) AS ITF_OEC ON Trans.ItemNum = ITF_OEC.[ItemNumber]
			) AS Typetbl  
		GROUP BY Typetbl.[TYPE]

	UNION
     
	SELECT 
		' ' AS ID, Typetbl.[TYPE], COUNT(Typetbl.NumType) AS 'NumofItems', SUM(typetbl.OEC) AS OEC
	FROM(
		SELECT 'IMO' AS [TYPE], Trans.ItemNum, Trans.NumType, ITF_OEC.OEC
        FROM(
			SELECT ItemQty.ItemNum, COUNT(ItemQty.TypeRepair) AS NumType, ItemQty.CNTR
            FROM(
				SELECT TI.ITEM AS ItemNum, COUNT(TI.ITEM) AS TypeRepair, T.CNTR
                FROM (TransactionItems TI 
                       INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR])
                       INNER JOIN ItemFile ITF ON TI.[Item] = ITF.[Num]
					   INNER JOIN CustomerFile CF ON T.[CUSN] = CF.[CNUM]
                WHERE
					LEFT(TI.[TXTY],1) = 'R'
					AND LEFT(T.[STAT],1) = 'O'
					AND (@StoreNo IS NULL OR @StoreNo = '000' OR (@StoreNo LIKE '%' + T.[STR] + '%'))
					AND LEFT(TI.[CNTR],1)='r' 
					AND TI.[TXTY] IN ('RR','RX')
					AND CF.[KEY] LIKE 'REPAIRS-MAINT%' 
					AND CF.[KEY] NOT LIKE 'REPAIRS-SERV%'
					AND TI.SUBF = 1
				GROUP BY TI.[Item], T.CNTR
				) AS ItemQty 
			GROUP BY ItemQty.Itemnum, ItemQty.CNTR
			) AS Trans
		LEFT JOIN(
				SELECT [IPD].[ItemNumber], SUM(([IPD].[QuantityPurchased] - [IPD].[QuantitySold]) * ([IPD].[PriceEach] + [IPD].[ExtraCharges])) AS OEC
				FROM [ItemPurchaseDetail] AS [IPD]
				WHERE [Disposed] = 0
				GROUP BY [IPD].ItemNumber
				) AS ITF_OEC ON Trans.ItemNum = ITF_OEC.[ItemNumber]
		) AS Typetbl  
	GROUP BY Typetbl.TYPE          

	UNION

	SELECT ' ' AS ID, Typetbl.TYPE, COUNT(Typetbl.NumType) AS 'NumofItems', SUM(Typetbl.OEC) AS OEC
	FROM(
		SELECT 'ISO' AS [TYPE], Trans.ItemNum, Trans.Numtype, ITF_OEC.OEC
        FROM(
			SELECT ItemQty.ItemNum, COUNT(ItemQty.TypeRepair) AS NumType
            FROM(
				SELECT  TI.ITEM AS ItemNum, COUNT(TI.ITEM) AS TypeRepair
                FROM ((TransactionItems TI 
                       INNER JOIN Transactions T ON TI.[CNTR] = T.[CNTR])
                       INNER JOIN ItemFile ITF ON TI.[Item] = ITF.[Num])
					   INNER JOIN CustomerFile CF ON T.[CUSN] = CF.[CNUM]                       
                WHERE
					LEFT(TI.[TXTY],1) = 'R' 
					AND LEFT(T.[STAT],1) = 'O' 
					AND (@StoreNo IS NULL OR @StoreNo = '000' OR (@StoreNo LIKE '%' + T.[STR] + '%'))
					AND CF.[KEY] LIKE 'REPAIRS-SERV%' 
					AND TI.SUBF = 1
				GROUP BY TI.[Item]
				) AS ItemQty 
			  GROUP BY ItemQty.ItemNum
			  ) AS Trans
	      LEFT JOIN (
				SELECT [IPD].[ItemNumber], SUM(([IPD].[QuantityPurchased] - [IPD].[QuantitySold]) * ([IPD].[PriceEach] + [IPD].[ExtraCharges])) AS OEC
                FROM [ItemPurchaseDetail] AS [IPD]
                WHERE [Disposed] = 0
                GROUP BY [IPD].ItemNumber
			
					) AS ITF_OEC ON Trans.ItemNum = ITF_OEC.[ItemNumber]
		) AS Typetbl  
	GROUP BY Typetbl.TYPE    
	) AS OECTYPE    

	INNER JOIN (
		SELECT '' AS ID, '' AS FleetDesc, COUNT(ITF_Fleet.NUM) AS ItemsinFleet, SUM(ITF_OEC.oec) AS FleetOEC
		FROM itemFile ITF_Fleet
		LEFT JOIN( 
			SELECT  IPD.[ItemNumber], SUM(([QuantityPurchased] - [QuantitySold]) * ([PriceEach] + IPD.[ExtraCharges])) AS OEC
			FROM [ItemPurchaseDetail] IPD
			WHERE IPD.[Disposed] = 0
			GROUP BY IPD.[ITEMNUMBER]
				) AS ITF_OEC ON ITF_Fleet.[NUM] = ITF_OEC.[ItemNumber]
		WHERE 
			ITF_Fleet.[TYPE] NOT IN ('b','e','f','i','k','m','n','o','p','s','v','w')
			AND (@StoreNo IS NULL OR @StoreNo = '000' OR (@StoreNo LIKE '%' + ITF_Fleet.CurrentStore + '%'))
			  ) AS Whole ON OECTYPE.ID = Whole.ID
END
go

