CREATE FUNCTION dbo.fnParseKitField (@sKitField as varchar(500))
RETURNS @tblItemNumbers TABLE 
(
    sItemNumber varchar(10)
)

/*************************************************************************/
-- Filename   : fnParseKitField.SQL
--
-- Description: This function returns a table with the parsed item numbers as rows.
--
-- Parameters : 
--                                    
-- Returns    : 
--
-- Example    : 
--
-- Outputs    : 
--
-- History    : 02/02/2015  JY  Initial
/*************************************************************************/

AS -- WITH ENCRYPTION AS

BEGIN

	--declare @sKitField as varchar(500)
	--set @sKitField = '20857-001 20382 20378 20356'
	Declare @ndx1 as int, @ndx2 as int

	set @ndx1 = charindex('-',@skitfield,0)

	if @ndx1 > 0
	begin
	--	select @ndx1, substring(@sKitField,1, @ndx1)
		insert into @tblItemNumbers (sItemNumber) values (substring(@sKitField,1, @ndx1-1))
	end

	set @ndx1 = charindex(' ',@skitfield,@ndx1) + 1

	while (@ndx1 > 0 and @ndx1 < len(@sKitField)-1)
	begin
	  set @ndx2 = charindex(' ',@skitfield,@ndx1)
		if @ndx2 > 0
		begin
	--		select @ndx1, @ndx2, substring(@sKitField,@ndx1, @ndx2-@ndx1)
			insert into @tblItemNumbers (sItemNumber) values (substring(@sKitField,@ndx1, @ndx2-@ndx1))
			set @ndx1 = charindex(' ',@skitfield,@ndx2)+1
		end
		else
		begin
	--		select @ndx1, @ndx2, substring(@sKitField,@ndx1, len(@skitfield)-@ndx1)
			insert into @tblItemNumbers (sItemNumber) values (substring(@sKitField,@ndx1, len(@skitfield)-@ndx2))
			set @ndx1 = 0
		end
	end
	--select * from @tblItemNumbers

   RETURN
END;
go

