
CREATE PROCEDURE DBO.spItemDaysInStore
(
	@Year		Int,
	@Month		Int,
	@ItemNumber	VarChar(20)
)

 
AS

/*************************************************************************/
--	POR.DBO.spItemDaysInStore
--		Returns a data set with rows for each store the item was transferred to during the month
--      with the number of days the item stayed at the store
--
--	PARAMETERS: @Year		- Depreciation Year
--				@Month		- Depreciation Month
--				@ItemNumber  - Targeted Item number
--
--	HISTORY:	10/07/2020	JY	CREATED  (9920)									 
--
/*************************************************************************/

BEGIN
SET NOCOUNT ON

CREATE TABLE #location
(
	[Id]	Int	Identity(1,1),
	[Num]	varchar(20),
	[Date] date,
	[Store] varchar(3)
);

DECLARE @HomeStore As VarChar(3) = (Select HomeStore From ItemFile Where Num = @ItemNumber)
DECLARE @StoreAtStartOfMonth as VarChar(3) = @HomeStore
DECLARE @StoreAtEndOfMonth as VarChar(3) = @HomeStore
DECLARE @FirstDayOfCurrentMonth as Date = DATEFROMPARTS(@year, @month, 1)
DECLARE @LastDayOfCurrentMonth as Date = DATEFROMPARTS(@year, @month, Day(EOMONTH(@FirstDayOfCurrentMonth)))
DECLARE @FirstDayOfNextMonth as Date = DATEADD(M,1,@FirstDayOfCurrentMonth)

-- Is there a transfer before the first of the current month?
-- If so, the last transfer before the first of the target month is the starting store for the current month
-- If the transfer 'To' store is not a 'real' store in ParamterFile, Use the Item's HomeStore
DECLARE @Store As VarChar(3) = (SELECT Top 1 ISNULL(ParameterFile.Store, ItemFile.HomeStore) As StoreTo 
								  FROM CurrentStoreTransfers 
								  LEFT OUTER JOIN ParameterFile ON ParameterFile.Store = CurrentStoreTransfers.StoreTo
								  LEFT OUTER JOIN ItemFile On ItemFile.Num = CurrentStoreTransfers.Num
								 WHERE CurrentStoreTransfers.Num = @ItemNumber 
								   AND [Date] < @FirstDayOfCurrentMonth
				 				   AND QuantityTransfered > 0
								   ORDER BY [Date] Desc)
-- If no prior transfer, use HomeStore
SET @StoreAtStartOfMonth = ISNULL(@Store, @HomeStore)

-- Is there a transfer before the first of the next month?
-- If so, the last transfer before the first of the next month is the ending store for the current month
-- If the transfer 'To' store is not a 'real' store in ParamterFile, Use the Item's HomeStore
SET @Store = Null
SET @Store = (Select Top 1 ISNULL(ParameterFile.Store, ItemFile.HomeStore) As StoreTo  
		        From CurrentStoreTransfers 
				LEFT OUTER JOIN ParameterFile ON ParameterFile.Store = CurrentStoreTransfers.StoreTo
				LEFT OUTER JOIN ItemFile On ItemFile.Num = CurrentStoreTransfers.Num
			   Where CurrentStoreTransfers.Num = @ItemNumber 
				 And Date < @FirstDayOfNextMonth
				 AND QuantityTransfered > 0
			   Order By [Date] Desc)
-- If no prior transfer, use the starting store
SET @StoreAtEndOfMonth = ISNULL(@Store, @StoreAtStartOfMonth)

--select @store, @StoreAtStartOfMonth, @StoreAtEndOfMonth

-- Build a list of all CurrentStore locations for the item during the current month
INSERT INTO #location (Num, [Date], Store)

	-- Get recorded location changes from CurrentStoreTransfers
	-- If there are multiple transfers on the same date, this will get the last one on the date only
	-- If the transfer 'To' store is not a 'real' store in ParamterFile, Use the Item's HomeStore
	SELECT CurrentStoreTransfers.Num, CAST(CurrentStoreTransfers.Date AS DATE) As Date, ISNULL(ParameterFile.Store, ItemFile.HomeStore) As StoreTo
	  FROM CurrentStoreTransfers 
	 INNER JOIN (SELECT CAST([Date] AS DATE) AS Date, Max(Id) as Id 
					FROM CurrentStoreTransfers 
				   WHERE QuantityTransfered > 0 
				     AND num = @ItemNumber And YEAR(Date) = @year and MONTH(Date) = @month 
				   GROUP BY CAST([Date] AS DATE)) As LastTransfer On CurrentStoreTransfers.Id = LastTransfer.Id 
	  LEFT OUTER JOIN ParameterFile ON ParameterFile.Store = CurrentStoreTransfers.StoreTo
	  LEFT OUTER JOIN ItemFile On ItemFile.Num = CurrentStoreTransfers.Num
	  WHERE QuantityTransfered > 0

	union 

	-- Add row for the first day of the month if there is not one
	SELECT @ItemNumber as Num, DATEFROMPARTS(@year, @month, 1) As Date, @StoreAtStartOfMonth As Store
	 WHERE (SELECT CAST(ISNULL(MIN(Date), DATEFROMPARTS(@year, @month, 2)) As Date) 
	          FROM CurrentStoreTransfers 
			 WHERE Num = @ItemNumber AND YEAR(Date) = @year AND MONTH(Date) = @month AND QuantityTransfered > 0) <> @FirstDayOfCurrentMonth

	union

	-- Add row for the last day of the month if there is not one
	SELECT @ItemNumber as Num, @LastDayOfCurrentMonth As Date, 
		   @StoreAtEndOfMonth As Store
	 WHERE ((SELECT CAST(ISNULL(MAX(Date),@FirstDayOfNextMonth) As Date) 
			   FROM CurrentStoreTransfers 
			  WHERE Num = @ItemNumber AND YEAR(Date) = @year AND MONTH(Date) = @month AND QuantityTransfered > 0) <> @LastDayOfCurrentMonth);

	-- Complete the list of item's location for each date in the month
	WITH Data AS (

		SELECT * FROM #location
	)

	, maxDate as (
		SELECT MAX(Date) Date
		FROM Data
	)

	, Dates as (
		SELECT date
		FROM Data

		UNION ALL

		SELECT DATEADD(day,1,date) Date
		FROM Dates
		WHERE DATEADD(day,1,Date) not in (SELECT Date FROM Data)
		  and DATEADD(day,1,Date) < (SELECT Date FROM maxDate)
	)

	SELECT DISTINCT
	  Dates.Date
	, Data.Store
	INTO #StoreDates
	FROM dates
	JOIN Data ON Data.Date = (SELECT MAX(Date) FROM Data WHERE Data.Date <= Dates.Date)
	ORDER BY 1
	OPTION (MAXRECURSION 10000)

-- Return a list of stores where the item was located during the month and the number of days in each store
SELECT Store, Count(Date) as DaysInStore
  FROM #StoreDates
  GROUP BY Store
  ORDER BY Store

--select * from #StoreDates;
--select * from #location;
--Select * from CurrentStoreTransfers Where Num = @ItemNumber And Year(date) = @year and month(date) = @month and QuantityTransfered > 0;

DROP TABLE #StoreDates
DROP TABLE #location

   RETURN
END;
go

