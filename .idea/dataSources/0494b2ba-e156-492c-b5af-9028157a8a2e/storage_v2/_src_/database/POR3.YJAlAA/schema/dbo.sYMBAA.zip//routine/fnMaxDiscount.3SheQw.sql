
CREATE FUNCTION dbo.fnMaxDiscount
(
	@sItemNumber VARCHAR(100)
)
RETURNS DECIMAL(10,2)
AS

    BEGIN

	DECLARE @DISCAMT DECIMAL(10,2)

	SET @DISCAMT = (SELECT ItemCategory.MaxDiscountPercent 
                      FROM ItemCategory 
					  INNER JOIN ItemFile ON ItemCategory.Category = ItemFile.Category 
                      WHERE Num = @sItemNumber) 

    
    RETURN ISNULL(@DISCAMT,0)

    END

go

