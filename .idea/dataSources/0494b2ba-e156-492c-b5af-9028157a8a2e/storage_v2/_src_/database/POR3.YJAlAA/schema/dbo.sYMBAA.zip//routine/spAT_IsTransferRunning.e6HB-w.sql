
CREATE PROCEDURE [dbo].[spAT_IsTransferRunning](
 @pilStageId Int
,@pisWorkstationName Varchar(120)
,@pibIsService Bit
,@pmlRunId Int OUTPUT
,@polStatusId Int OUTPUT -- 0 = OK, 
                         -- 1 = Already running Interactively
                         -- 2 = Already Running as Service
                         -- 3 = Another Transfer program has started between stage 1 and 2
,@posStatusInfo varchar(512) OUTPUT
,@posErrorMsg varchar(512) OUTPUT -- any user / server error
) AS
SET NOCOUNT ON

DECLARE @lErrorNo int, @lNextId Int
DECLARE @sOptValue Varchar(255)  
DECLARE @ExportFormatId Int = 1011
SET @posErrorMsg = NULL
SET @polStatusId = 0
SET @posStatusInfo = NULL

/*
-- Stage 1 - Before setting the current config and loading the job list
-- Stage 2 - Before running the transfer
-- Stage 3 - At the end of running the transfer

IF @pilStageId IN (1, 2)
BEGIN
  --
  -- Need to check the transfer program is not already running elsewhere
  --
  
  --SELECT @sOptValue = OPT_OPTION_VALUE
  --FROM   dbo.TH_OPTIONS
  --WHERE  OPT_DOMAIN = 'SxAtx-Current Execution'

 SELECT @sOptValue = GLConnectionPath
  FROM   dbo.ExportFormat
  WHERE  ExportFormatId = @ExportFormatId

  IF @sOptValue IS NOT NULL
  BEGIN
    IF LEFT(@sOptValue,2) = 'S:'
      SET @polStatusId = 2
    ELSE
      SET @polStatusId = 1

    SET @posStatusInfo = @sOptValue -- SUBSTRING(@sOptValue, 3, 999)

    RETURN
  END

  --
  -- Get a unique Id for the execution
  --
  --SELECT @lNextId = NEXT_NO FROM dbo.TH_NEXT_ID_SXATXRUN WITH (TABLOCKX)
  --EXEC @lErrorNo = dbo.splbTestError @@ERROR, 'spTHA19_SxAtxRun\010', @posErrorMsg output
  --IF @lErrorNo != 0 RETURN @lErrorNo

    SELECT @lNextId = ISNULL(CreatedBy,1) FROM dbo.ExportFormat WITH (TABLOCKX) WHERE  ExportFormatId = @ExportFormatId
	IF (@@ERROR) > 0
	BEGIN
		SET @lErrorNo = @@ERROR
		SET @posErrorMsg = 'server error ' + cast(@@ERROR as varchar)  + ' at location '   + 'spTHA19_SxAtxRun\010'
	END
	IF @lErrorNo != 0 RETURN @lErrorNo

  --UPDATE dbo.TH_NEXT_ID_SXATXRUN SET NEXT_NO = NEXT_NO + 1
  --EXEC @lErrorNo = dbo.splbTestError @@ERROR, 'spTHA19_SxAtxRun\020', @posErrorMsg output
  --IF @lErrorNo != 0 RETURN @lErrorNo

    UPDATE dbo.ExportFormat SET CreatedBy = CreatedBy + 1 WHERE  ExportFormatId = @ExportFormatId
	IF (@@ERROR) > 0
	BEGIN
		SET @lErrorNo = @@ERROR
		SET @posErrorMsg = 'server error ' + cast(@@ERROR as varchar)  + ' at location '   + 'spTHA19_SxAtxRun\020'
	END
	IF @lErrorNo != 0 RETURN @lErrorNo

  -- On stage 1, we just return the Id
  IF @pilStageId = 1
  BEGIN
    SET @pmlRunId = @lNextId
    RETURN
  END
  
  -- On stage 2, we need to make sure the next id immediately follows the one allocated in stage 1
  -- If not, another transfer program has started and may have run through to the end, so we need to abort
  IF @lNextId <> (COALESCE(@pmlRunId,-1) + 1)
  BEGIN
    SET @polStatusId = 3
    RETURN
  END

  SET @pmlRunId = @lNextId

  -- If all OK, set option to indicate we are running
  SET @sOptValue = CASE WHEN @pibIsService = 1 THEN 'S:' ELSE 'I:' END + COALESCE(@pisWorkstationName, '<unknown>')
  --IF EXISTS (SELECT 1
  --           FROM   dbo.TH_OPTIONS
  --           WHERE  OPT_DOMAIN = 'SxAtx-Current Execution')
  --BEGIN
    --UPDATE dbo.TH_OPTIONS
    --SET    OPT_OPTION_VALUE = @sOptValue
    --WHERE  OPT_DOMAIN = 'SxAtx-Current Execution'
    --EXEC @lErrorNo = dbo.splbTestError @@ERROR, 'spTHA19_SxAtxRun\030', @posErrorMsg output
    --IF @lErrorNo != 0 RETURN @lErrorNo
  --END
  --ELSE
  --BEGIN
  --  INSERT INTO dbo.TH_OPTIONS(OPT_DOMAIN, OPT_OPTION_VALUE)
  --  VALUES ('SxAtx-Current Execution', @sOptValue)

  --  EXEC @lErrorNo = dbo.splbTestError @@ERROR, 'spTHA19_SxAtxRun\040', @posErrorMsg output
  --  IF @lErrorNo != 0 RETURN @lErrorNo
  --END

	UPDATE dbo.ExportFormat
    SET    GLConnectionPath = @sOptValue
    WHERE  ExportFormatId = @ExportFormatId

	IF (@@ERROR) > 0
	BEGIN
		SET @lErrorNo = @@ERROR
		SET @posErrorMsg = 'server error ' + cast(@@ERROR as varchar)  + ' at location '   + 'spTHA19_SxAtxRun\030'
	END
	IF @lErrorNo != 0 RETURN @lErrorNo
  RETURN  
END

--
-- At the end of the transfer, update the option to indicate we are no longer running
--
IF @pilStageId = 3
BEGIN
  --UPDATE dbo.TH_OPTIONS
  --SET    OPT_OPTION_VALUE = NULL
  --WHERE  OPT_DOMAIN = 'SxAtx-Current Execution'

  --EXEC @lErrorNo = dbo.splbTestError @@ERROR, 'spTHA19_SxAtxRun\100', @posErrorMsg output
  --IF @lErrorNo != 0 RETURN @lErrorNo

	UPDATE dbo.ExportFormat
    SET    GLConnectionPath = NULL
    WHERE  ExportFormatId = @ExportFormatId

	IF (@@ERROR) > 0
	BEGIN
		SET @lErrorNo = @@ERROR
		SET @posErrorMsg = 'server error ' + cast(@@ERROR as varchar)  + ' at location '   + 'spTHA19_SxAtxRun\100'
	END
	IF @lErrorNo != 0 RETURN @lErrorNo

END


  */
RETURN

go

grant execute on spAT_IsTransferRunning to PORUser
go

