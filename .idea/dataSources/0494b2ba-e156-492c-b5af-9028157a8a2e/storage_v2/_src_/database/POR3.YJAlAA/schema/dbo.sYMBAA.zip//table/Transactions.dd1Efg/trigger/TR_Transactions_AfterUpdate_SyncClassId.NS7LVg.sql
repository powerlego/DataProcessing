
CREATE TRIGGER TR_Transactions_AfterUpdate_SyncClassId ON [Transactions]
AFTER UPDATE 
AS  
IF (ROWCOUNT_BIG() = 0)
RETURN;
BEGIN  
	
	SET NOCOUNT ON; -- SET NOCOUNT ON added to prevent extra result sets from interfering

	DECLARE @NewValue int
	DECLARE @CurrentValue int
	Declare @Contract nvarchar(10) 
	
	BEGIN TRY

		SELECT @Contract = [inserted].[cntr] From [inserted]--Get the record in question

		IF(LEFT(@Contract,1) NOT IN ('r','t')) Return; --Only an r or t can change class upon Customer record change...

		SELECT @CurrentValue = [inserted].[classid] From [inserted]--Get the current value in question


		--Define what the class is, All fully numeric or q contracts are 0, everything else has a value
		--Only an r or t can change class upon Customer record change...
		SELECT @NewValue =  CASE 
				 WHEN LEFT([inserted].[cntr],1) = 'r' AND CustomerFile.[Key] IS NULL THEN 2
				 WHEN CustomerFile.[Key] like 'REPAIRS-MAINT%' THEN 3
				 WHEN  CustomerFile.[Key] like 'REPAIRS-SERV%' THEN 4
				 WHEN  LEFT([inserted].[cntr],1) = 'r' THEN 2
				 WHEN  LEFT([inserted].[cntr],1) = 't' AND CustomerFile.[Key] IS NULL  THEN 6
				 WHEN  LEFT([inserted].[cntr],1) = 't' AND IsNumeric(LEFT(CustomerFile.[Key],1))=1 THEN 7
				 WHEN  LEFT([inserted].[cntr],1) = 't' THEN 6
				 ELSE @CurrentValue
				 END 
				 FROM [inserted] LEFT JOIN CustomerFile On [inserted].cusn = CustomerFile.cnum 

			IF (@CurrentValue = @NewValue) 
				SET NOCOUNT OFF; -- Clear our override
			ELSE
				UPDATE [Transactions]
				SET ClassId = @NewValue
				Where [Transactions].Cntr = @Contract; --fix the column value
	END TRY
	BEGIN CATCH
		SET NOCOUNT OFF;-- Clear our override
	END CATCH;

END;
go

