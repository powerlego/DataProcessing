
CREATE VIEW [dbo].[vwAT_VendorPayablesPendingExport] 
--WITH ENCRYPTION 
AS
SELECT 
 poq.AccountingAPIQueuePOId				AS PIV_ID
,Cast(poq.PONumber AS Varchar(20))		as PIV_USER_NUMBER
,poq.InvoiceDate						AS PIV_INV_DATE
,Cast(poq.InvoiceNumber as Varchar(20))	AS PIV_INV_NUMBER
,CASE WHEN poq.TotalAmount > 0 
		THEN 'I' ELSE 'C' END			AS PIV_INV_TYPE  -- I invoice, or C credit
,cast(poq.Store as Int)					AS PIV_DEPOT_ID
,CASE WHEN poq.TotalAmount > 0 
	   THEN 'Invoice' ELSE 'Credit' END AS InvType
,poq.DateQueued							AS PIV_POSTING_DATE
,NULL									AS PIV_PY_DATE
,''										AS PIV_PY_ACCOUNT
,''										AS PIV_PY_REF
,0.00									AS PIV_PY_AMOUNT
,Cast(ISNULL(poq.ExchangeRate,1.00) As Real) AS PIV_EXCH_RATE
,poq.AccountsPayableAccount				AS PIV_ACCOUNTS_CODE
,Cast(poq.VendorNumber As VarChar(8))   AS SUP_ACCOUNT_NUMBER
,vf.VendorName							AS SUP_NAME
,''										AS IDR_ACCOUNTS_DISPUTE_CODE
,0										AS DPT_BUS_AREA_ID
,''										AS DPT_ACCOUNTS_DEPT
,poq.InvoiceNumber						AS ORDER_NUMBER
,ISNULL(cepo.AccountingLink, ISNULL(cev.AccountingLink,''))		AS CUR_ACCOUNTS_CURRENCY_CODE
,poq.ShippingCost						AS PIV_SHIPPING_COST
,poq.Miscellaneous						AS PIV_MISC_COST
,poq.Tax								AS PIV_TAX_AMOUNT
,poq.POShippingAccount					AS PIV_SHIPPING_ACCT
,poq.POMiscellaneousAccount				AS PIV_MISC_ACCT
,poq.POTaxAccount						AS PIV_TAX_ACCT
FROM AccountingAPIQueuePO poq
INNER JOIN VendorFile vf on vf.VendorNumber = poq.VendorNumber
LEFT OUTER JOIN CurrencyExchange cepo ON cepo.CurrencyNumber = poq.CurrencyNumber
LEFT OUTER JOIN CurrencyExchange cev ON cev.CurrencyNumber = vf.CurrencyNumber
WHERE poq.DateApproved IS NOT NULL
  AND poq.DatePosted IS NULL
  AND poq.DateCancelled IS NULL
  AND poq.RetryCount <= 10


go

grant select on vwAT_VendorPayablesPendingExport to PORUser
go

