
CREATE VIEW [dbo].[qryTransactionItems]
AS
select * from TransactionItems UNION Select * from TransItemsHistory;

go

