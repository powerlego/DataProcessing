
CREATE VIEW [dbo].[vwAT_CashCustomerKeys] 
--WITH ENCRYPTION 
AS
SELECT DISTINCT cst.[CNUM] AS AccountNo 
FROM  dbo.CustomerFile cst
WHERE cst.[STATUS] = 'H'

go

grant select on vwAT_CashCustomerKeys to PORUser
go

