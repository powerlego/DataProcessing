
CREATE PROCEDURE DBO.spGetSuspendedDatesForContract
(
	@ContractNumber	VARCHAR(12),
	@LineNumber		INTEGER = 0,
	@CountOnly		BIT = 0
)

AS

/*************************************************************************/
--	POR.DBO.spGetSuspendedDatesForContract
--		Returns a table with suspended dates and hours for contract line numbers
--
--	PARAMETERS: @ContractNumber - Required contract number    
--				@LineNumber		- Optional, to get suspended dates for a 
--								  specific line number
--				@CountOnly      - Optional bit flag to return only the count 
--								  of suspense rows for the contract
--
--  DEPENDENCIES:
--              CustomerFile.Suspense (Int)
--					0 = Follow Item or Category setting
--					1 = Apply Suspense to All Rentals, override Item and Category
--					2 = None (Exempt from Suspense)
--				ItemFile.Suspense (Bit)
--					0 = False (Exempt from Suspense)
--					1 = True (Allow Suspense)
--				ItemCategory.Suspense (Bit) 
--					0 = False (Exempt from Suspense)
--					1 = True (Allow Suspense)
--
--	HISTORY:	04/09/2020	JY	CREATED	
--				04/24/2020  JY  Added handling for exchanges
--				04/27/2020  JY  Corrected handling for continued contracts
--
/*************************************************************************/

BEGIN
	SET NOCOUNT ON

	-- Get Parent Contract number if this is a continuation billed contract
	DECLARE @ParentContract VarChar(12)
    SET @ParentContract = (SELECT ParentContract 
							 FROM Transactions
							WHERE CNTR = @ContractNumber
							  AND ISNUMERIC(RIGHT(LTRIM(RTRIM(CNTR)),1)) = 0		-- ends with non-numeric character
							  AND RTRIM(LTRIM(ISNULL(CONT,''))) <> ''				-- CONT column is not empty 
							  AND RTRIM(LTRIM(ISNULL(ParentContract,''))) <> '')    -- ParentContract column is not empty

    SET @ContractNumber = ISNULL(@ParentContract, @ContractNumber)

   --select @ContractNumber, @ParentContract

	-- Get the suspense dates with LineNumber = 0
	-- These apply to every line on the contract
    SELECT TransItemsSuspense.LineNumber, TransItemsSuspense.SuspenseDate, MAX(ISNULL(TransItemsSuspense.SuspensePercentCharge,0)) as SuspensePercentCharge,
		   MIN(IIF(ISNULL(TransItemsSuspense.SuspenseHours,0) = 0, 24, TransItemssuspense.SuspenseHours)) AS SuspenseHours, Cast('0 - Zeros' As Varchar(100)) As SuspenseSource
	  INTO #tmp_Suspense
	  FROM (TransItemsSuspense 
     INNER JOIN Transactions ON Transactions.CNTR = TransItemsSuspense.CNTR)
     INNER JOIN CustomerFile ON CustomerFile.CNUM = Transactions.CUSN 
     WHERE TransItemsSuspense.CNTR = @ContractNumber 
	   AND TransItemsSuspense.LineNumber = 0
    -- Exclude if exempted by the customer
       AND (CustomerFile.Suspense != 2) 
     GROUP BY TransItemsSuspense.LineNumber, TransItemsSuspense.SuspenseDate 
	 ORDER BY TransItemsSuspense.LineNumber, TransItemsSuspense.SuspenseDate

	-- Apply the dates with LineNumber = 0 to all line numbers currently on the contract
	INSERT INTO #tmp_Suspense
    SELECT TransactionItems.LineNumber, TransItemsSuspense.SuspenseDate, MAX(ISNULL(TransItemsSuspense.SuspensePercentCharge,0)) as SuspensePercentCharge,
		   MIN(IIF(ISNULL(TransItemsSuspense.SuspenseHours,0) = 0, 24, TransItemssuspense.SuspenseHours)) AS SuspenseHours, Cast('1 - All Lines From Zeros'  As Varchar(100)) As SuspenseSource
	  FROM (((TransItemsSuspense 
     INNER JOIN Transactions ON Transactions.CNTR = TransItemsSuspense.CNTR 
     INNER JOIN TransactionItems ON TransactionItems.CNTR = TransItemsSuspense.CNTR) 
     INNER JOIN ItemFile ON ItemFile.NUM = TransactionItems.Item) 
     INNER JOIN ItemCategory ON ItemCategory.Category = ItemFile.Category) 
     INNER JOIN CustomerFile ON CustomerFile.CNUM = Transactions.CUSN 
     WHERE TransItemsSuspense.CNTR = @ContractNumber 
	   AND TransItemsSuspense.LineNumber = 0
    -- Exclude lines exempted by the customer, item or category even if TransItemsSuspense rows exist
       AND ((CustomerFile.Suspense = 0 AND (ItemFile.SuspenseExempt = 0 AND ItemCategory.SuspenseExempt = 0)) 
        OR	(CustomerFile.Suspense = 1)) 
     GROUP BY TransactionItems.LineNumber, TransItemsSuspense.SuspenseDate 
	 ORDER BY TransactionItems.LineNumber, TransItemsSuspense.SuspenseDate

	-- Add any line number specific dates that were not already covered by a LineNumber = 0 row
	INSERT INTO #tmp_Suspense
    SELECT TransItemsSuspense.LineNumber, TransItemsSuspense.SuspenseDate, MAX(ISNULL(TransItemsSuspense.SuspensePercentCharge,0)) as SuspensePercentCharge,
		   MIN(IIF(ISNULL(TransItemsSuspense.SuspenseHours,0) = 0, 24, TransItemssuspense.SuspenseHours)) AS SuspenseHours, Cast('2 - Line Specific ' + Cast(TransItemsSuspense.LineNumber As varchar(10)) As Varchar(100)) As SuspenseSource
      FROM ((((TransItemsSuspense 
     INNER JOIN Transactions ON Transactions.CNTR = TransItemsSuspense.CNTR 
     INNER JOIN TransactionItems ON TransactionItems.CNTR = TransItemsSuspense.CNTR and TransactionItems.LineNumber = TransItemsSuspense.LineNumber) 
     INNER JOIN ItemFile ON ItemFile.NUM = TransactionItems.Item) 
     INNER JOIN ItemCategory ON ItemCategory.Category = ItemFile.Category) 
     INNER JOIN CustomerFile ON CustomerFile.CNUM = Transactions.CUSN)
 	  LEFT OUTER JOIN #tmp_Suspense ON (#tmp_Suspense.LineNumber = TransItemsSuspense.LineNumber And #tmp_Suspense.SuspenseDate = TransItemsSuspense.SuspenseDate)
     WHERE TransItemsSuspense.CNTR = @ContractNumber 
	   AND TransItemsSuspense.LineNumber > 0
	   AND #tmp_Suspense.SuspenseDate Is Null
-- Exclude lines exempted by the customer, item or category even if TransItemsSuspense rows exist
       AND ((CustomerFile.Suspense = 0 AND (ItemFile.SuspenseExempt = 0 AND ItemCategory.SuspenseExempt = 0)) 
        OR	(CustomerFile.Suspense = 1)) 
     GROUP BY TransItemsSuspense.LineNumber, TransItemsSuspense.SuspenseDate 
	 ORDER BY TransItemsSuspense.LineNumber, TransItemsSuspense.SuspenseDate


	-- For Exchange involved TransactionItems:
	-- Add any line number specific dates that were not already covered by a LineNumber = 0 row
	--  and the stand down was specifically for the base/original line for an exhange line
	INSERT INTO #tmp_Suspense
    SELECT TransactionItems.LineNumber, TransItemsSuspense.SuspenseDate, MAX(ISNULL(TransItemsSuspense.SuspensePercentCharge,0)) as SuspensePercentCharge,
		   MIN(IIF(ISNULL(TransItemsSuspense.SuspenseHours,0) = 0, 24, TransItemssuspense.SuspenseHours)) AS SuspenseHours, Cast('3 - Base Line Exchange ' + Min(TransactionsRelated.RelatedDocument) As Varchar(100)) As SuspenseSource
      FROM (((((TransItemsSuspense 
     INNER JOIN Transactions ON Transactions.CNTR = TransItemsSuspense.CNTR 
	 -- Join to any exchange relationships for lines on the current contract
	 INNER JOIN TransactionsRelated ON (TransactionsRelated.[Contract] = Transactions.CNTR AND TransactionsRelated.RelatedDocumentType = 2))
	 -- Join to the TransactionItem for the item exchanged for (not the item exchanged)
     INNER JOIN TransactionItems ON (TransactionItems.CNTR = TransItemsSuspense.CNTR and TransactionItems.LineNumber = TransactionsRelated.LineNumber))
	 -- Join to the Item and category for the item exchanged for (not the item exchanged)
     INNER JOIN ItemFile ON ItemFile.NUM = TransactionItems.Item) 
     INNER JOIN ItemCategory ON ItemCategory.Category = ItemFile.Category) 
     INNER JOIN CustomerFile ON CustomerFile.CNUM = Transactions.CUSN)
	  -- Join to any in #tmp_suspense with the same LineNumber / SuspenseDate combination
 	  LEFT OUTER JOIN #tmp_Suspense ON (#tmp_Suspense.LineNumber = TransactionItems.LineNumber And #tmp_Suspense.SuspenseDate = TransItemsSuspense.SuspenseDate)
     WHERE TransItemsSuspense.CNTR = @ContractNumber
	   AND TransactionItems.TransRelated = 1
	   AND TransItemsSuspense.LineNumber > 0
	   AND TransItemsSuspense.LineNumber = TransactionsRelated.RelatedDocument
	   -- Exclude any already in #tmp_suspense with the same LineNumber / SuspenseDate combination
	   AND #tmp_Suspense.SuspenseDate Is Null
	   -- Exclude lines exempted by the customer, item or category even if TransItemsSuspense rows exist
       AND ((CustomerFile.Suspense = 0 AND (ItemFile.SuspenseExempt = 0 AND ItemCategory.SuspenseExempt = 0)) 
       OR	(CustomerFile.Suspense = 1)) 
     GROUP BY TransactionItems.LineNumber, TransItemsSuspense.SuspenseDate 
	 ORDER BY TransactionItems.LineNumber, TransItemsSuspense.SuspenseDate


	 IF (@LineNumber > 0) 
		DELETE FROM #tmp_Suspense WHERE LineNumber <> @LineNumber

	IF (@CountOnly = 1)
		SELECT COUNT(LineNumber) As SuspenseCount
		FROM #tmp_Suspense
	ELSE
		SELECT LineNumber, SuspenseDate, Max(SuspensePercentCharge) As SuspensePercentCharge, Min(SuspenseHours) As SuspenseHours, Min(SuspenseSource) as SuspenseSource
		FROM #tmp_Suspense
		GROUP BY LineNumber, SuspenseDate 
		ORDER BY LineNumber, SuspenseDate

	DROP TABLE #tmp_Suspense

	SET NOCOUNT OFF

END

go

