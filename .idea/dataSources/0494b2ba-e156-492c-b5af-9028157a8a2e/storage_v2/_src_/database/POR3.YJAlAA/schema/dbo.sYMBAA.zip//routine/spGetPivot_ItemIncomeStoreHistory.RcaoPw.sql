
CREATE PROCEDURE DBO.spGetPivot_ItemIncomeStoreHistory
(
	@sQuery		VARCHAR(5000)
)

AS

/*****************************************************************************************/
--	POR.DBO.spGetPivot_ItemIncomeStoreHistory
--		Returns a table with totals summarized by month, pivoted on year
--
--	PARAMETERS: @sQuery  - The base query is formed in the client
--
--	HISTORY:	10/22/2014	JY	CREATED	--
--				11/15/2016  JY  Corrected aggregate by store in total column
/*****************************************************************************************/

BEGIN
SET NOCOUNT ON

DECLARE @sSQL VARCHAR(5000)
DECLARE @sColumns AS VARCHAR(MAX)

CREATE TABLE #TMP_TRANSSUMMARY
([MONTH]		INTEGER,
 [YEAR]			INTEGER,
 [STORE]		VARCHAR(8),
 [Total Income]	MONEY
)

INSERT INTO #TMP_TRANSSUMMARY
EXEC(@sQuery)

--SELECT * FROM #TMP_TRANSSUMMARY

-- Get total by month and store for the total column
SELECT [MONTH], [Store], SUM([TOTAL INCOME]) AS [TOTAL INCOME]
  INTO #TMP_ROLLUP
  FROM #TMP_TRANSSUMMARY
GROUP BY [MONTH],[STORE]
ORDER BY [MONTH], [STORE]

-- Get a list of years for column names
select @sColumns = substring((Select DISTINCT ',' + QUOTENAME([YEAR]) FROM #TMP_TRANSSUMMARY ORDER BY ',' + QUOTENAME([YEAR]) DESC FOR XML PATH ('')),2, 1000) 

--SELECT @sColumns

set @SSQL =
'SELECT *
INTO #TMP_PIVOT1
FROM #TMP_TRANSSUMMARY
PIVOT 
(
  SUM([TOTAL INCOME]) 
  FOR [year] IN( ' + @sColumns + ' )) as [Total Income]; ' 

-- add the monthly total column to the pivot table
set @ssql = @ssql + 'SELECT P.MONTH AS [MONTH], P.[STORE], T.[Total Income], ' + @sColumns + ' FROM #TMP_PIVOT1 P JOIN #TMP_ROLLUP T ON P.MONTH = T.MONTH AND P.[STORE] = T.[STORE]'
set @ssql = @ssql + ' ORDER by [MONTH], [STORE] '

execute(@ssql)


DROP TABLE #TMP_TRANSSUMMARY
DROP TABLE #TMP_ROLLUP

SET NOCOUNT OFF

END

go

