
CREATE VIEW [dbo].[VW_JobsiteSearch] 
AS
	SELECT 
						[CJ].[Number],
						[CJ].[Cnum],
						[CJ].[Description],
						[CJ].[ValidThroughDate],
						[CJ].[ContractInfo],
						[CJ].[PONumber],
						[CJ].[JobNumber],
						[CJ].[Salesman],
						[CJ].[TaxCode],
						[CJ].[RentDiscount],
						[CJ].[SaleDiscount],
						[CJ].[PriceLevel],
						[CJ].[Nontaxable],
						[CJ].[DamageWaiverExempt],
						[CJ].[ItemPercentageExempt],
						[CJ].[ContactName],
						[CJ].[ContactPhone],
						[CJ].[SiteAddress],
						[CJ].[SiteCity],
						[CJ].[SiteZip],
						[CJ].[SiteNotes],
						[CJ].[JobType],
						[CJ].[GeneralContractor],
						[CJ].[ProjectSupervisor],
						[CJ].[SupervisorPhone],
						[CJ].[SiteCompanyName],
						[CJ].[SquareFeet],
						[CJ].[ProjectCost],
						[CJ].[ProjectStartDate],
						[CJ].[ProjectEndDate],
						[CJ].[SiteDeliveryInstructions],
						[CJ].[Notes],
						[CJ].[ContractorPhone],
						[CJ].[DiscountTable],
						[CJ].[OperatorAssigned],
						[CJ].[ReviewBilling],
						[CJ].[RateEngineId],
						[CJ_TR].[Languagecode] AS [CJ_Languagecode],
						[CJ_TR].[Description] AS [CJ_Description_TR],
						[CJ_TR].[ContractInfo] AS [CJ_ContractInfo_TR],
						[CJ_TR].[SiteDeliveryInstructions] AS [CJ_SiteDeliveryInstructions_TR],
						[CJ_TR].[Notes] AS [CJ_Notes_TR],
						[CJ_TR].[SiteNotes] AS [CJ_SiteNotes_TR],
						[CF].[NAME] AS [CF_NAME],
						[S].[Name] AS [S_Name],
						[T].[Id] AS [T_Id]
		FROM			[dbo].[CustomerJobSite]		AS [CJ]
		LEFT OUTER JOIN [dbo].[CustomerJobSite_Tr]	AS [CJ_TR]	ON	[CJ].[Number]	= [CJ_TR].[Number]	AND [CJ_TR].[Inactive] = 0
		LEFT OUTER JOIN [dbo].[CustomerFile]		AS [CF]		ON	[CJ].[Cnum]		= [CF].[CNUM]
		LEFT OUTER JOIN [dbo].[Salesman]			AS [S]		ON	[CJ].[Salesman] = [S].[Number]		AND [S].[Inactive] = 0
		OUTER APPLY
			(SELECT		TOP 1 [Id]
				FROM    [dbo].[CRMTouchpoints]
				WHERE   [Link] = [CJ].[Number] AND [LinkType] = 6 AND [Inactive] = 0
			)			[T]
go

