create view [dbo].[BI_CVW_Open_AR_and_Sales] as
SELECT DISTINCT CustomerFile.NAME        as Customer_Name,
                Transactions.TOTL        as Transaction_Total,
                Transactions.STAT        as Transaction_Status,
                Transactions.CNTR        as Transaction_Contract,
                Transactions.PAID,
                Transactions.CLDT        as Transaction_Close_Date,
                Salesman_Cntr.Name       as Contract_Sales_Rep_Name,
                TransactionType.TypeName as Transaction_Type,
                Salesman_customer.Name   as Customer_Sales_Rep_Name,
                Salesman_jobsite.Name    as Jobsite_Sales_Rep_Name,
                Transactions.DEPP        as Deprication,
                CustomerFile.CurrentBalance,
                CustomerFile.Terms
FROM Transactions
         LEFT OUTER JOIN CustomerFile ON Transactions.CUSN = CustomerFile.CNUM
         LEFT OUTER JOIN Salesman Salesman_Cntr ON Transactions.Salesman = Salesman_Cntr.Number
         LEFT OUTER JOIN CustomerJobSite ON Transactions.JobSite = CustomerJobSite.Number
         LEFT OUTER JOIN TransactionType
                         ON Transactions.TransactionType = TransactionType.TypeNumber
         LEFT OUTER JOIN TransactionOperation
                         ON Transactions.Operation = TransactionOperation.OperationNumber
         LEFT OUTER JOIN ParameterFile ON Transactions.STR = ParameterFile.Store
         LEFT OUTER JOIN Salesman Salesman_jobsite
                         ON CustomerJobSite.Salesman = Salesman_jobsite.Number
         LEFT OUTER JOIN CustomerType ON CustomerFile.Type = CustomerType.Type
         LEFT OUTER JOIN Salesman Salesman_customer
                         ON CustomerFile.Salesman = Salesman_customer.Number
WHERE (Transactions.TOTL <> Transactions.PAID OR Transactions.DEPP <> 0)
  AND Transactions.Archived = 0
  AND Transactions.PYMT <> N'T'
  AND Transactions.STAT NOT LIKE 'R%'
  AND Transactions.STAT NOT LIKE 'Q%'
go

