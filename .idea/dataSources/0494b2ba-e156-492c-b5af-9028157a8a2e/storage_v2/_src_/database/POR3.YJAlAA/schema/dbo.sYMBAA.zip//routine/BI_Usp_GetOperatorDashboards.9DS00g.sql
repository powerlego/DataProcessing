-- SQL Deploy  3/29/2018 8:38 AM
CREATE PROCEDURE [dbo].[BI_Usp_GetOperatorDashboards]
@OperatorNo int
AS
BEGIN
DECLARE @ActiveDashboardCount int;
DECLARE @CustomDashboardCount int;
DECLARE @ItemDashboardCount int;
DECLARE @CustomerDashboardCount int;
DECLARE @ContractDashboardCount int;
 
SET NOCOUNT ON;
 
 
SET @ActiveDashboardCount = (SELECT COUNT(d.ID)
FROM dbo.BI_Dashboards d
WHERE d.OperatorId = @OperatorNo and d.Inactive = 0);
SET @CustomDashboardCount = (SELECT TOP(1) d.ID
FROM dbo.BI_Dashboards d
WHERE d.OperatorId = @OperatorNo and d.DashboardTypeId = 1 and d.Inactive = 0);
SET @ItemDashboardCount = (SELECT TOP(1) d.ID
FROM dbo.BI_Dashboards d
WHERE d.OperatorId = @OperatorNo and d.DashboardTypeId = 2 and d.Inactive = 0);
SET @CustomerDashboardCount = (SELECT TOP(1) d.ID
FROM dbo.BI_Dashboards d
WHERE d.OperatorId = @OperatorNo and d.DashboardTypeId = 3 and d.Inactive = 0);
SET @ContractDashboardCount = (SELECT TOP(1) d.ID
FROM dbo.BI_Dashboards d
WHERE d.OperatorId = @OperatorNo and d.DashboardTypeId = 4 and d.Inactive = 0);
 
 
 
 
IF (@ActiveDashboardCount > 0)
BEGIN
SELECT d.ID, d.UserProfileId, d.OperatorId,
d.DashboardTitle, d.DashboardTypeId,
d.DashboardOrder, d.StartDateFilter,
d.EndDateFilter, d.StoreFilter,
d.OverrideChildSettings, d.CreatedBy
FROM dbo.BI_Dashboards d
WHERE d.OperatorId = @OperatorNo AND d.Inactive= 0
OR 
(
d.ID = IIF (@CustomDashboardCount IS NULL, 1, NULL) OR
d.ID = IIF (@ItemDashboardCount IS NULL, 2, NULL) OR
d.ID = IIF (@CustomerDashboardCount IS NULL, 3, NULL) OR
d.ID = IIF (@ContractDashboardCount IS NULL, 4, NULL)
)
END
ELSE
BEGIN
SELECT d.ID, d.UserProfileId, d.OperatorId,
d.DashboardTitle, d.DashboardTypeId,
d.DashboardOrder, d.StartDateFilter,
d.EndDateFilter, d.StoreFilter,
d.OverrideChildSettings, d.CreatedBy
FROM dbo.BI_Dashboards d
Where
(d.DashboardTypeId >= 1 and d.DashboardTypeId <= 4) and (d.OperatorId IS NULL OR d.OperatorId = 0) and d.Inactive= 0
END
END
go

