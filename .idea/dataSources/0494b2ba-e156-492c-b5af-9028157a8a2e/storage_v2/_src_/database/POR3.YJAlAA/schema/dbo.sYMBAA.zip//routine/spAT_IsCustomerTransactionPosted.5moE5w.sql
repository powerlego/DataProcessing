
CREATE  PROCEDURE [dbo].[spAT_IsCustomerTransactionPosted](
 @pilIvcId Int
,@pobIsPosted Bit OUTPUT
) 
-- WITH ENCRYPTION
AS
SET NOCOUNT ON

IF EXISTS (SELECT 1 
           FROM  dbo.AccountingAPIQueueTr
           WHERE Id = @pilIvcId
           AND   DatePosted IS NOT NULL)
  SET @pobIsPosted = 1
ELSE
  SET @pobIsPosted = 0

--  IF EXISTS (SELECT 1 
--           FROM  dbo.TH_HIRE_INVOICES
--           WHERE IVC_INVOICE_NUMBER = @pilIvcId
--           AND   IVC_CASH_REQUIRES_POSTING_FLAG = 0)
--  SET @pobIsPosted = 1
--ELSE
--  SET @pobIsPosted = 0

RETURN

go

grant execute on spAT_IsCustomerTransactionPosted to PORUser
go

