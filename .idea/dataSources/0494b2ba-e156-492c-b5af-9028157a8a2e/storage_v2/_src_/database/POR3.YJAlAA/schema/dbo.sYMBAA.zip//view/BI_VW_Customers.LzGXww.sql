-- SQL Deploy  3/29/2018 8:38 AM
CREATE VIEW dbo.BI_VW_Customers
 
AS
SELECT C.[KEY] as [Cust.Key]
,C.[CNUM] as [Cust.No]
,C.[NAME] as [Cust.Name]
,C.[Address] as [Cust.Addr Line 1]
,C.[Address2] as [Cust.Addr Line 2]
,C.[CITY] as [Cust.City]
,C.[ZIP] as [Cust.Zip]
,C.[ZIP4] as [Cust.Zip+4]
,C.[DriversLicense] as [Cust.Drivers License No]
,C.[Birthdate] as [Cust.Birth Date]
,C.[Employer] as [Cust.Employer]
,C.[AutoLicense] as [Cust.Auto License/Reg]
,C.[AutoState] as [Cust.Auto State]
,C.[Phone] as [Cust.Primary Phone]
,C.[WORK] as [Cust.Work Phone]
,C.[MOBILE] as [Cust.Mobile Phone]
,C.[FAX] as [Cust.Fax No]
,C.[PAGER] as [Cust.Pager No]
,C.[OpenDate] as [Cust.Open Date]
,C.[LastActive] as [Cust.Last Active Date]
,C.[LastContract] as [Cust.Previous Contract]
,C.[CreditLimit] as [Cust.Credit Limit]
,C.[Status] as [Cust.Status]
,CASE
WHEN C.STATUS = 'D' THEN 'Cash'
WHEN C.STATUS = 'H' THEN 'Cash Only'
WHEN C.STATUS = 'E' THEN 'Any Method'
ELSE 'UNKNOWN'
END AS [Cust.Status Desc]
,C.[Restrictions] as [Cust.Restrictions]
,CASE
WHEN C.[Restrictions] = 'K' THEN 'No Checks,'
WHEN C.[Restrictions] = 'D' THEN 'Waive deposits.� No restrictions.'
WHEN C.[Restrictions] = 'R' THEN 'Pay-on-return, waive deposit, do not collect payment up-front.'
WHEN C.[Restrictions] = 'O' THEN 'Collect payment up front.'
WHEN C.[Restrictions] = 'S' THEN 'Sale customer.� No rent.'
WHEN C.[Restrictions] = 'U' THEN 'Undesirable.� No rent/sale.'
WHEN C.[Restrictions] = 'W' THEN 'Wanted person.� Notify owner or police.� No rent/sale.'
WHEN C.[Restrictions] = 'C' THEN 'Account Closed.'
WHEN C.[Restrictions] = 'H' THEN 'Account put on hold waiting for payment.� Must have the�Manager or Owner�s level password to rent.'
WHEN C.[Restrictions] = '3' THEN 'Can be up to 60 days overdue without requiring password'
WHEN C.[Restrictions] = '6' THEN 'Can be up to 90 days overdue without requiring password'
WHEN C.[Restrictions] = '9' THEN 'Can be up to 120 days overdue without requiring password'
WHEN C.[Restrictions] = 'N' THEN 'Can be any days overdue without requiring password'
ELSE 'None - Collect normal deposits.� No restrictions.'
END AS [Cust.Restriction Desc]
 
,C.[OTHERID] as [Cust.Other ID]
,C.[IncomeYear]  as [Cust.YTD Income]
,C.[IncomeLife] as [Cust.LTD Income]
,C.[IncomeLastYear] as [Cust.Last Yr Income]
,C.[NumberContracts] as [Cust.No Of Contracts]
,C.[TaxCode] as [Cust.Tax Code]
,C.[Discount] as [Cust.Discount]
,ISNULL(DT.Disc_Desc,'') as [Cust.Discount Desc]
,ISNULL(DT.Rent_Disc,'0') as [Cust.Rental Discount %]
,ISNULL(DT.Sale_Disc,'0') as [Cust.Sale Discount %]
,C.[Type] as [Cust.Type]
,ISNULL(CT.[Description],'') as [Cust.Type Desc]
,ISNULL(CT.Display,'') as [Cust.Type Display]
,ISNULL(CT.Inactive,'') as [Cust.Type Inactive]
 
,C.[QtyOut] as [Cust.Qty Out]
 
 
 
 
 
 
,C.[LastPayAmount] as [Cust.Last Pay Amt]
,C.[LastPayDate] as [Cust.Last Pay Date]
,C.[HighBalance] as [Cust.High Balance Amt]
,C.[CurrentBalance] as [Cust.Current Balance Amt]
,C.[Email]  as [Cust.Email]
,C.[Salesman] as [Cust.Salesman]
,ISNULL(S.Name,'') as [Cust.Salesman Name]
,ISNULL(S.OperatorNo,'') as [Cust.Salesman OperatorNo]
,ISNULL(S.Email,'') as [Cust.Salesman Email]
,ISNULL(S.CellPhone,'') as [Cust.Salesman Phone]
,ISNULL(S.Inactive,'') as [Cust.Salesman Inactive]
 
 
 
,C.[DLExpire] as [Cust.DL Expire]
,C.[BillContact] as [Cust.Billing Contact]
,C.[BillPhone] as [Cust.Billing Phone]
,C.[BillAddress1] as [Cust.Billing Addr Line 1]
,C.[BillAddress2] as [Cust.Billing Addr Line 2]
,C.[BillCityState] as [Cust.Billing City-State]
,C.[BillZip] as [Cust.Billing ZipCode]
,C.[BillZip4] as [Cust.Billing Zip4]
,C.[TaxId] as [Cust.Tax ID]
,C.[TaxExemptNumber] as [Cust.Tax Exempt No]
,C.[TaxExemptExpire] as [Cust.Tax Exempt Expire]
,C.[InsuranceNumber] as [Cust.Insurance No]
,C.[InsuranceExpire] as [Cust.Insurance Exp Date]
 
 
,C.[Terms] as [Cust.Terms]
,C.[FinanceChargeDays] as [Cust.Finance Charge Days]
 
 
,C.[UserDefined1] as [Cust.User Defined 1]
,C.[UserDefined2] as [Cust.User Defined 2]
,C.[PriceLevel] as [Cust.Price Level]
 
,C.[AgeDate] as [Cust.Contract Age Date]
 
,C.[HeardAboutUs] as [Cust.Referral] 
, ISNULL(CH.HeardName, '') as [Cust.Referral Desc]
 
,C.[NoEmail] as [Cust.No Email]
,C.[ContractorLicense] as [Cust.Contractor License No]
,C.[ContractorExpire] as [Cust.Contractor Lic Expire]
 
,C.[MonthToMonth] as [Cust.Month To Month]
,C.[PricingType] as [Cust.Pricing Type]
,C.[Group] as [Cust.Group]
 
,C.[Language] as [Cust.Language]
,C.[CommissionLevel] as [Cust.Commission Level]  
,ISNULL(CLC.[Description],'') as [Cust.Commission Level Desc]
,C.[Nontaxable] as [Cust.NonTaxable]
,C.[OperatorAssigned] as [Cust.Operator Assigned]
,C.[LoyaltyLevelId] as [Cust.Loyalty Level Id]
FROM [dbo].[CustomerFile] C
LEFT JOIN [dbo].[CustomerType] CT ON C.Type = CT.Type
LEFT JOIN [dbo].[Salesman] S ON C.Salesman = S.Number
LEFT JOIN [dbo].[DiscountTable] DT ON C.Discount = DT.CODE
LEFT JOIN [dbo].[CustomerHeard] CH ON C.HeardAboutUs = CH.HeardNumber
LEFT JOIN [dbo].[CommissionLevelCustomer] CLC ON C.CommissionLevel = CLC.CommissionLevelCustomer


go

