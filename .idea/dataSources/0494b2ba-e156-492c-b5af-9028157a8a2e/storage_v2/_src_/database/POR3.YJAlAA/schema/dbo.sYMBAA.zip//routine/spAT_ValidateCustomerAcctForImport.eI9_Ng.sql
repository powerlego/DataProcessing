
CREATE PROCEDURE [dbo].[spAT_ValidateCustomerAcctForImport](
 @pisAccountNo varchar(200)
,@pilCustomerId int
,@posMessage varchar(255) OUTPUT
,@pobIsWarning bit OUTPUT
) 
--WITH ENCRYPTION 
AS
SET NOCOUNT ON
SET @posMessage = NULL
SET @pobIsWarning = 0
DECLARE @sCheck varchar(255)
DECLARE @sOptValue varchar(255)
DECLARE @lMaxAccLength int, @bUniqueAcrossCAS Bit

---- Has this account number already been used on old account customer converted to cash?
--SELECT @sCheck = CST_NAME 
--FROM   dbo.TH_CUSTOMERS
--WHERE  CST_TYPE_CHG_WAS_ACCNO = @pisAccountNo
--AND    CST_ID <> COALESCE(@pilCustomerId, -1)

--IF @sCheck IS NOT NULL
--BEGIN
--  SET @posMessage = 'The account number ' + @pisAccountNo + ' was previously allocated to customer ' + @sCheck +  ', and cannot be re-used'
--  RETURN
--END

---- If a new customer, ensure they are not using the cash customer account no
--IF @pilCustomerId IS NULL
--BEGIN
--  IF EXISTS (SELECT 1 FROM dbo.TH_NAP_ACCOUNT_NOS
--             WHERE  NAN_ACCOUNT_NO = @pisAccountNo)
--  BEGIN
--    SET @posMessage = 'The account number ' + @pisAccountNo + ' is being used for non-account (cash) invoices'
--    RETURN
--  END
--END

---- Check the length of the account number
--DECLARE @sAccSysId Varchar(20)
--EXEC dbo.spLbGetSystemOption 'Accounting System Id', NULL, @sAccSysId output
--SELECT
-- @lMaxAccLength = ACS_MAX_ACCOUNT_LEN
--,@bUniqueAcrossCAS = ACS_ACCOUNT_NO_UNIQUE_CAS
--FROM   dbo.TH_ACCTS_SYSTEMS
--WHERE  ACS_ID = @sAccSysId

--IF @lMaxAccLength IS NULL
--  SET @lMaxAccLength = 20
  
--If LEN(@pisAccountNo) > @lMaxAccLength
--BEGIN
--  SET @posMessage = 'Account numbers cannot be longer than ' + CAST(@lMaxAccLength AS varchar) + ' characters'
--  RETURN
--END

--IF PATINDEX('% %', @pisAccountNo) > 0 OR PATINDEX('%,%', @pisAccountNo) > 0  
--BEGIN
--  SET @posMessage = 'Account numbers cannot contain any spaces or commas'
--  RETURN
--END

--IF @bUniqueAcrossCAS = 1
--BEGIN
--  IF EXISTS (SELECT 1
--             FROM   dbo.TH_SUPPLIERS
--             WHERE  SUP_ACCOUNT_NUMBER = @pisAccountNo)
--  BEGIN
--    SET @posMessage = 'This Account number has already been used for a supplier'
--    RETURN
--  END
--END

---- Has this account number already been used?
--SELECT @sCheck = CST_NAME 
--FROM   dbo.TH_CUSTOMERS
--WHERE  CST_CTYPE='A'
--AND    CST_ACCOUNT_NUMBER = @pisAccountNo
--AND    CST_ID <> COALESCE(@pilCustomerId, -1)

--IF @sCheck IS NOT NULL
--BEGIN
--  SET @posMessage = 'Account number ' + @pisAccountNo + ' has already been allocated to customer ' + @sCheck
--  EXEC dbo.spLbGetSystemOption 'Allow Duplicate AccNos', '0', @sOptValue output
--  IF @sOptValue = '1'
--  BEGIN
--      SET @posMessage = @posMessage + '  Are you sure you want to allocate it to this customer also?'
--      SET @pobIsWarning = 1
--  END
--  RETURN
--END

RETURN

go

grant execute on spAT_ValidateCustomerAcctForImport to PORUser
go

