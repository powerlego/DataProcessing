

CREATE VIEW [dbo].[qryDataTransItems]
AS
SELECT TransactionItems.SUBF AS LineNumber, TransactionItems.CNTR AS Contract, Transactions.Str AS Store, ItemCategory.Name AS ItemCategory, 
       ItemFile.[KEY] AS ItemKey, ItemFile.Name AS ItemName, TransactionItems.[Desc] AS MiscItemDesc, Transactions.Date AS DateOut, 
          IIf([TransactionItems].[DDT] Is Null,[Transactions].[Date],[TransactionItems].[DDT]) AS DateIn, 
       Transactions.CLDT AS ClosedDate, TransactionItems.QTY AS Quantity, [TransactionItems].[Pric]-[TransactionItems].[DiscountAmount] AS ExtPrice, 
       CustomerFile.NAME
  FROM (((TransactionItems LEFT JOIN Transactions 
          ON TransactionItems.CNTR = Transactions.CNTR) LEFT JOIN ItemFile 
                ON TransactionItems.ITEM = ItemFile.NUM) LEFT JOIN ItemCategory 
                ON ItemFile.Category = ItemCategory.Category) LEFT JOIN CustomerFile 
                ON Transactions.CUSN = CustomerFile.CNUM
WHERE Left([STAT],1) In (' ','C')
UNION 
SELECT TransactionItems.SUBF AS LineNumber,  TransactionItems.CNTR AS Contract, Transactions.Str AS Store, ItemCategory.Name AS ItemCategory, 
       ItemFile.[KEY] AS ItemKey, ItemFile.Name AS ItemName, TransactionItems.[Desc] AS MiscItemDesc, Transactions.Date AS DateOut, 
          IIf([TransactionItems].[DDT] Is Null,[Transactions].[Date],[TransactionItems].[DDT]) AS DateIn, 
          Transactions.CLDT AS ClosedDate, TransactionItems.QTY AS Quantity, [TransactionItems].[Pric]-[TransactionItems].[DiscountAmount] AS ExtPrice, 
          CustomerFile.NAME
  FROM (((TransItemsHistory AS TransactionItems LEFT JOIN TransHistory AS Transactions 
          ON TransactionItems.CNTR = Transactions.CNTR) LEFT JOIN ItemFile 
                ON TransactionItems.ITEM = ItemFile.NUM) LEFT JOIN ItemCategory 
                ON ItemFile.Category = ItemCategory.Category) LEFT JOIN CustomerFile 
                ON Transactions.CUSN = CustomerFile.CNUM
WHERE Left([STAT],1) In (' ','C');


go

