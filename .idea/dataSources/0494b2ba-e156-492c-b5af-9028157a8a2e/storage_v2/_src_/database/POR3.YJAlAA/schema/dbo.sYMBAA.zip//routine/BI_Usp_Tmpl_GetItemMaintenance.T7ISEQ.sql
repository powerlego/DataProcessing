
CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_GetItemMaintenance]
	@WidgetDataFilter KeyValuePair READONLY -- pass parameters via Table Type Param
AS
BEGIN
	
	SET NOCOUNT ON;
	
	Declare @StoreNo nvarchar(20) = null;
	Set @StoreNo	= (SELECT	SUBSTRING([Value], 1, 20)	FROM @WidgetDataFilter WHERE [Key] = 'StoreNo');
			
	Declare @CurrentDate datetime = null;
	Set @CurrentDate	= (SELECT	CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'CurrentDate');

	Declare @StartDate datetime = null;
	Set @StartDate	= (SELECT	CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'StartDate');

	Declare @EndDate datetime = null;
	Set @EndDate	= (SELECT	CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'EndDate');

	--TODO Stop gap -- Work on this more // using UNPIVOT
	SELECT Tab.[Type], SUM(Tab.Count) as [Total] 
	from
		(
			Select (case WHEN Due <= 0 Then 'Items due next week' else 'Items Past Due' END) as [Type],
			COUNT(Due) as [Count]
			FROM
			(
			  SELECT IM.Num, IM.Schedule, IM.Type, IM.Reading, IM.Frequency, ITF.[MTIN], ITF.[HROT3], ITF.CurrentStore,
					(Select Case 
							When IM.Type = 'U' Then (ITF.MTIN - IM.Reading) - IM.Frequency
							When IM.Type = 'H' and ITF.[Type] = 'H' Then (ITF.MTIN - IM.Reading) - IM.Frequency
							When IM.Type = 'H' and ITF.[Type] <> 'H' Then (ITF.HROT3 - IM.Reading) - IM.Frequency
							When IM.Type = 'T' Then (ITF.TMOT3 - IM.Reading) - IM.Frequency
							When IM.Type = 'M' and year(IM.LastDate) < 1980 then DateDiff(m,'1/1/1900',@CurrentDate) - IM.Frequency
							When IM.Type = 'M' and IM.LastDate Is Null then DateDiff(m,'1/1/1900',@CurrentDate) - IM.Frequency
							When IM.Type = 'M' and IM.LastDate Is Not Null then DateDiff(m,IM.LastDate,@CurrentDate) - IM.Frequency
							When IM.Type = 'R' and IM.LastDate Is Null then DateDiff(m,'1/1/2100',@CurrentDate) - IM.Frequency
							When IM.Type = 'R' and IM.LastDate Is Not Null then DateDiff(m,IM.LastDate,@CurrentDate) - IM.Frequency
							When IM.Type = 'D' and IM.LastDate Is Null then DateDiff(d,'1/1/1900',@CurrentDate) - IM.Frequency
							When IM.Type = 'D' and IM.LastDate Is Not Null then DateDiff(d,IM.LastDate,@CurrentDate) - IM.Frequency
					Else 0
					End) AS Due
			  FROM ItemMaintenance IM
			  INNER JOIN ItemFile ITF ON IM.Num = ITF.Num
			  WHERE ITF.[Type] Not In ('V','E') and ITF.[QTY] > 0 and (@StoreNo IS NULL or @StoreNo = 'All' OR @StoreNo = '000' or ITF.CurrentStore = @StoreNo)
			  ) AS MainTbl WHERE MainTbl.Due >= -7
			  GROUP BY Due ) AS Tab
			  group by Tab.[Type]
END
go

