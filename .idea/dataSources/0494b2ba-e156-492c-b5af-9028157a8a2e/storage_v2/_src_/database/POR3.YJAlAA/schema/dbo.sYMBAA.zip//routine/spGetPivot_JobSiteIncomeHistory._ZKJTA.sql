
CREATE PROCEDURE DBO.spGetPivot_JobSiteIncomeHistory
(
	@sQuery			VARCHAR(5000),
	@sFieldName		VARCHAR(100),
	@sType			VARCHAR(5)
)

AS

/*****************************************************************************************/
--	POR.DBO.spGetPivot_JobSiteIncomeHistory
--		Returns a table with totals summarized by month, pivoted on year
--
--	PARAMETERS: @sQuery     - The base query is formed in the client
--				@sFieldName - Specifies column being summarized 
--							     ([TotlAmt], [SaleAmt], [RentAmt])
--				@sType		- Summary function ('SUM', 'COUNT')
--
--	HISTORY:	10/23/2014	JY	CREATED	----
--				11/15/2016  JY  Camel case for output column names
--
/*****************************************************************************************/

BEGIN
	SET NOCOUNT ON

	DECLARE @SSQL VARCHAR(1500)
	DECLARE @scolumns AS VARCHAR(MAX)

	CREATE TABLE #TMP_INCOMESUMMARY
	([Month]		INTEGER,
	 [Year]			INTEGER,
	 [RENTAMT]		MONEY,
	 [SALEAMT]		MONEY,
	 [TOTLAMT]		MONEY
	)

	-- Get Income summary data using query from client
	INSERT INTO #TMP_INCOMESUMMARY		
	exec(@sQuery)


	CREATE TABLE #TMP_TRANSSUMMARY
	(	[Month]		INTEGER,
		[Year]			INTEGER,
		[Amount]		INTEGER
	)

	IF (@sType = 'SUM')
	BEGIN
		ALTER TABLE #TMP_TRANSSUMMARY ALTER COLUMN [Amount] MONEY
	END

				-- Get transaction summary (COUNT)
	SET @SSQL = 'INSERT INTO #TMP_TRANSSUMMARY ' +
				'SELECT [Month], [Year], ' +
				@sType + '(' + @sFieldName + ') AS Amount ' +
				' From #TMP_INCOMESUMMARY ' +
				' WHERE ISNULL(' + @sFieldName + ',0) != 0 ' +
				' GROUP BY [Month], [Year] ' 

	--SELECT @SSQL
	exec(@SSQL)

	select @scolumns = substring((Select DISTINCT ',' + QUOTENAME([year]) FROM #TMP_TRANSSUMMARY order by ',' + QUOTENAME([year]) desc FOR XML PATH ('')),2, 1000) 

	SELECT [Month], SUM(Amount) AS Month_Amt
	  INTO #TMP_MONTH_TOTAL
	  FROM #TMP_TRANSSUMMARY
	GROUP BY [MONTH]
	ORDER BY [MONTH]

	set @SSQL =
	'SELECT *
	INTO #TMP_PIVOT
	FROM #TMP_TRANSSUMMARY
	PIVOT 
	(
	  SUM(amount) 
	  FOR [year] IN( ' + @scolumns + ' )) as Amount'

	  -- add the monthly total column to the pivot table
	set @ssql = @ssql + '; SELECT P.[Month], M.[Month_Amt] AS [Total],' + @scolumns + ' FROM #TMP_PIVOT P JOIN #TMP_MONTH_TOTAL M ON M.[MONTH] = P.[MONTH] ORDER BY P.[MONTH]'
	exec(@ssql)

	drop table #TMP_MONTH_TOTAL
	drop table #TMP_TRANSSUMMARY
	drop table #TMP_INCOMESUMMARY

	SET NOCOUNT OFF

END

go

