
CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_OffRentAnalysis]
@WidgetDataFilter KeyValuePair READONLY 
AS
BEGIN

SET NOCOUNT ON;

	DECLARE @StoreNo nvarchar(20) = null;
	DECLARE @CurrentDate datetime = null;

	SET @StoreNo	= (SELECT	SUBSTRING([Value], 1, 20)	FROM @WidgetDataFilter WHERE [Key] = 'StoreNo');
	SET @CurrentDate	= (SELECT	CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'CurrentDate');

 
SELECT DaysSort.Name, DaysSort.COUNTEvents, DaysSort.TotalDays, DaysSort.AvgDaysOut, DaysSort.RevenueLost
FROM(
	SELECT DaysUn.Name, COUNT(Daysun.CNTR) AS COUNTEvents, SUM(DaysUn.DaysUnavail) AS TotalDays,
	CONVERT(varchar(50),CAST(SUM(DaysUn.DaysUnavail) as money) / CAST(COUNT(Daysun.CNTR) as money)) as 'AvgDaysOut',
	CONVERT(varchar(50),CAST(SUM(Daysun.LostRevenue) as money)) AS RevenueLost

	FROM (
 
	SELECT Distinct IC.Name, TI.Item, 
		   ItemFile.PURP, T.CNTR,
		   CONVERT(varchar(12),TI.DDT) AS DDT, 
		   (DATEDIFF("d",TI.DDT,@currentDate))+1 as DaysUnavail,
		   IIF(TI.Dailyamount = 0,(ItemFile.Rate1*TI.Qty),(TI.Dailyamount*TI.Qty)) as DayRate,
		   (IIF(TI.Dailyamount = 0,(ItemFile.Rate1*TI.Qty),(TI.Dailyamount*TI.Qty))
							 *               ((DATEDIFF("d",TI.DDT,@CurrentDate))+1)) AS LostRevenue 

	FROM ((Transactions T  
		   INNER JOIN TransactionItems TI ON T.CNTR = TI.CNTR) 
		   LEFT JOIN  ItemFile ON TI.ITEM = ItemFile.NUM)
		   LEFT JOIN ItemCategory IC ON ItemFile.Category = IC.Category 
	  
	WHERE 
		  Left(TI.TXTY,2) = 'RH' 
		  AND CONVERT(DATE, TI.DDT) <= @CurrentDate
		  AND Left(T.[STAT],1) NOT IN (' ','C') 
		  AND Left(T.CNTR,1) NOT IN ('t','c','s','r','q') 
		  AND TI.Qty <> 0 
		  AND (@StoreNo IS NULL OR @StoreNo = 'All' OR @StoreNo = '000' OR (@StoreNo LIKE '%' + T.[STR] + '%'))
		  AND T.Archived = 0
	
		) AS DaysUn 
		GROUP BY DaysUn.Name 

	) AS DaysSort
	ORDER BY DaysSort.AvgDaysOut

END
go

