




CREATE VIEW [dbo].[qryDataContractItemHistory] AS 
SELECT TI.CNTR, TI.DDT AS DateDue,Month(TI.DDT) AS DueMonth, Year(TI.DDT) as DueYear,
 Transactions.CUSN as CustNum, CustomerFile.Name AS CustName,TransactionType.TypeName AS TransType,
 ItemFile.[KEY],TI.ITEM,ItemFile.Name AS ItemName, Ti.QTY,TI.HRSC,TI.PRIC, TI.DiscountAmount,
 Transactions.AutoLicense, Transactions.PickedUpDlNo, Transactions.JOBN

											
From (((Transactions 
  Inner Join TransactionItems TI on Transactions.CNTR = TI.CNTR)
  Inner join ItemFile on TI.Item = ItemFile.NUM)
  Left Join TransactionType on Transactions.TransactionType = TransactionType.TypeNumber)
  Left Join CustomerFile on Transactions.CUSN = CustomerFile.CNUM
Where  Left(Transactions.STAT,1) in ('C',' ')
and Year(Transactions.DATE) >= Year(GetDate())-2
And TI.Qty <> 0 and (Right(Left(Transactions.STAT+'  ',2),1)) not in ('C') 
AND Left(TI.TXTY,1) = 'R'
Union
SELECT TI.CNTR, TI.DDT AS DateDue,Month(TI.DDT) AS DueMonth, Year(TI.DDT) as DueYear,
 Transactions.CUSN as CustNum, CustomerFile.Name AS CustName,TransactionType.TypeName AS TransType,
 ItemFile.[KEY],TI.ITEM,ItemFile.Name AS ItemName, Ti.QTY,TI.HRSC,TI.PRIC, TI.DiscountAmount,
 Transactions.AutoLicense, Transactions.PickedUpDlNo, Transactions.JOBN
From (((TransHistory  Transactions 
  Inner Join TransItemsHistory  TI on Transactions.CNTR = TI.CNTR)
  Inner join ItemFile on TI.Item = ItemFile.NUM) 
  Left Join TransactionType on Transactions.TransactionType = TransactionType.TypeNumber)
  Left Join CustomerFile on Transactions.CUSN = CustomerFile.CNUM
Where  Left(Transactions.STAT+'  ',1) in ('C',' ')
and Year(Transactions.DATE) >= Year(GetDate())-2
And TI.Qty <> 0 and (Right(Left(Transactions.STAT+'  ',2),1)) not in ('C') 
AND Left(TI.TXTY,1) = 'R'



go

