-- SQL Deploy  3/29/2018 8:38 AM
CREATE VIEW [dbo].[BI_CVW_TotalsSummary_Sales] 
  AS
SELECT	SUMM.Date
, DATEPART(YY, SUMM.Date) as [Year]
, DATEPART(QQ, SUMM.Date) as [Quarter]
, DATEPART(MM, SUMM.Date) as [Month]
, DATENAME(MM, SUMM.Date) as [Month Name]
,SUMM.Store
,REV.[Sales Revenue]
,COG.COGS
,CNT.[New Contracts]
FROM	(Select MAX(CONVERT(date, b.[Date], 126)) as [Date], Store
from TotalsSummary b 
group by DATEPART(yy, b.[Date]), DATEPART(mm, b.[Date]), Store) SUMM
LEFT OUTER JOIN
(Select	MAX(CONVERT(date, [Date], 126)) as [Date], Store
, SUM(SaleTx + SaleNT) as [Sales Revenue]
from TotalsContractsAccrual
group by DATEPART(yy, [Date]), DATEPART(mm, [Date]), Store) REV
ON SUMM.Date = REV.Date and SUMM.Store = REV.Store
LEFT OUTER JOIN
(Select MAX(CONVERT(date, [Date], 126)) as [Date], Store
, SUM((PurchasePrice + ExtraCharges) * Quantity) as [COGS]
from CostOfGoods 
group by DATEPART(yy, [Date]), DATEPART(mm, [Date]), Store) COG
ON SUMM.Date = COG.Date and SUMM.Store = COG.Store
LEFT OUTER JOIN
(Select	MAX(CONVERT(date, [Date], 126)) as [Date], Store
, Count(CNTR) as [New Contracts] 
from TransactionEdit
where Code = 'O' and Not LTRIM(Stat) = 'Q'
group by DATEPART(yy, [Date]), DATEPART(mm, [Date]), Store) CNT
ON SUMM.Date = CNT.Date and SUMM.Store = CNT.Store

go

