CREATE VIEW [dbo].[BI_VW_Income_Item]
 
AS 
SELECT [ItemFile].[KEY], 
       ItemFile.Name, 
	   ItemType.TypeDescrip AS Type, 
	   ItemCategory.Name AS [Category Name], 
	   ItemDepartment.DepartmentName, 
	   ItemDivision.DivisionName, 
	   ItemCategorySuper.SuperCategoryName, 
	   ItemIncome.Date, 
	   ItemIncome.Income, 
	   ItemIncome.Times, 
	   ItemIncome.Repairs, 
	   ItemIncome.Quantity, 
	   ItemIncome.Depreciation, 
	   ItemIncome.CostOfGoods, 
	   ItemIncome.SubrentalCosts, 
	   ItemIncome.PurchasePrice, 
	   ItemIncome.DamageWaiver, 
	   ItemIncome.ItemPercent, 
	   ItemFile.HomeStore, 
	   ItemFile.CurrentStore, 
	   ItemFile.Header
  FROM (ItemType RIGHT JOIN 
          (ItemIncome LEFT JOIN 
		     (ItemDivision RIGHT JOIN 
	            ((ItemCategory RIGHT JOIN ItemFile ON ItemCategory.Category = ItemFile.Category) 
	               LEFT JOIN ItemDepartment ON ItemFile.Department = ItemDepartment.Department) 
	                  ON ItemDivision.DivisionNumber = ItemCategory.DivisionNumber)
					     ON ItemIncome.Num = ItemFile.NUM) 
					        ON ItemType.Type = ItemFile.Type)
   LEFT JOIN ItemCategorySuper ON ItemCategory.SuperCategory = ItemCategorySuper.SuperCategory
go

