-- SQL Deploy  3/29/2018 8:38 AM
CREATE PROCEDURE [dbo].[BI_Usp_CopyDashboard]
@OperatorNo int,
@DashboardId int,
@UserProfileId int = 2, 
@NewDashboardTitle nvarchar(75) = NULL,
@NewDashboardId int OUTPUT
AS
 
 
 
 
 
 
 
 
 
 
 
 
 
BEGIN
SET NOCOUNT ON;
Declare @MaxDashboardOrder int;
Declare @NewDashboardOrder int;
 
SET @MaxDashboardOrder = (SELECT MAX(DashboardOrder)
FROM dbo.BI_Dashboards d
WHERE ((d.OperatorId = @OperatorNo) OR (d.UserProfileId = 1))
); 
SET @NewDashboardOrder = @MaxDashboardOrder + 1;
 
 
 
INSERT INTO dbo.BI_Dashboards(UserProfileId, OperatorId, DashboardTypeId, DashboardTitle,
DashboardOrder, StartDateFilter, EndDateFilter, StoreFilter, OverrideChildSettings, 
CreatedBy, ChangedBy, ChangeNote)
SELECT	@UserProfileId as [UserProfileId],
@OperatorNo as [OperatorId],
Dashboard.[DashboardTypeId],
ISNULL(@NewDashboardTitle, Dashboard.DashboardTitle + ' ' + CAST(@NewDashboardOrder AS nvarchar)), 
@NewDashboardOrder, 
Dashboard.[StartDateFilter],
Dashboard.[EndDateFilter],
Dashboard.[StoreFilter],
Dashboard.[OverrideChildSettings],
@OperatorNo as [CreatedBy],
@OperatorNo as [ChangedBy],
'Application: Elite Launchpad; Dashboard Copy' as [ChangeNote]
FROM
(SELECT [DashboardTypeId]
,[DashboardTitle]
,[StartDateFilter]
,[EndDateFilter]
,[StoreFilter]
,[OverrideChildSettings]
FROM dbo.BI_Dashboards
WHERE ID = @DashboardId) As Dashboard;
SET @NewDashboardId = SCOPE_IDENTITY();
 
 
 
INSERT INTO dbo.BI_Widgets (DashboardId, WidgetTemplateId, WidgetTypeId, WidgetTitle,
WidgetOrder, ChartDimensionAxisType, LowGoal, MediumGoal, HighGoal, WidgetSortOrder,
CreatedBy, ChangedBy, ChangeNote)
SELECT	@NewDashboardId as [DashboardId], 
WidgetTemplateId,
WidgetTypeId,
WidgetTitle,
WidgetOrder,
ChartDimensionAxisType,
LowGoal,
MediumGoal,
HighGoal,
WidgetSortOrder,
@OperatorNo as [CreatedBy],
@OperatorNo as [ChangedBy],
'Application: Elite Launchpad; Dashboard Copy' as [ChangeNote]
FROM dbo.BI_Widgets
WHERE DashboardId = @DashboardId
END
go

