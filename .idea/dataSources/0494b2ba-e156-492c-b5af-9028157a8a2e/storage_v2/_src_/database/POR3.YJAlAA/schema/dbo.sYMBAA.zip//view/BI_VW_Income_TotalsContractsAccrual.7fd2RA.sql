CREATE VIEW [dbo].[BI_VW_Income_TotalsContractsAccrual]
 
AS 
SELECT
	[CF].[KEY] AS CustomerKey,
	LTRIM([TCA].[Cusn]) AS CustomerNumber,
	[CF].[NAME] AS CustomerName,
	[CF].[Address] AS CustomerAddress,
	[CF].[CITY] AS CustomerCity,
	[CF].[ZIP] AS CustomerZip,
	[CFT].[Description] AS CustomerType,
	([TCA].[Date]) As Posted_Date,
	([TCA].[RentTX] + [TCA].[RentNT]) AS Rent, 
	([TCA].[SaleTX] + [TCA].[SaleNT]) AS Sale,
	([TCA].[AssetTX] + [TCA].[AssetNT]) AS Asset,
	([TCA].[DWTx] + [TCA].[DWNT]) AS DmgWvr,
	Other,
	[TCA].[Tax] AS SalesTax,
	([TCA].[RentTx] + [TCA].[SaleTx] + [TCA].[DwTx] + [TCA].[AssetTx] + [TCA].[RentNT] + [TCA].[SaleNT] 
		+ [TCA].[DwNT] + [TCA].[AssetNT] + [TCA].[Other] + [TCA].[Tax] + [TCA].[ItemPercentageTax] + [TCA].[ItemPercentageNonTax]) AS RevenueWithTax, 
	([TCA].[RentTx] + [TCA].[SaleTx] + [TCA].[DwTx] + [TCA].[AssetTx] + [TCA].[RentNT] + [TCA].[SaleNT] 
		+ [TCA].[DwNT] + [TCA].[AssetNT] + [TCA].[Other] + [TCA].[ItemPercentageTax] + [TCA].[ItemPercentageNonTax]) AS RevenueWithOutTax,
	[SR].[Name] AS SalesRepName,
	[TCA].[CNTR] AS [Contract],
	[CJ].[Number] AS JobsiteNumber, 
	[CJ].[Description] AS JobsiteName,
	[TCA].[Salesman] AS [Salesman],
	[SR].[Inactive] AS [InactiveSalesRep],
	[TCA].[Store] AS [Store]
FROM 
	TotalsContractsAccrual TCA
	LEFT JOIN Salesman SR ON [TCA].[Salesman] = [SR].[Number],
	CustomerFile CF
	LEFT JOIN CustomerType CFT ON [CF].[Type] = [CFT].[Type],
	Transactions T
	LEFT JOIN  CustomerJobSite CJ ON [T].[JobSite] = [CJ].[Number]
WHERE 
	[TCA].[CNTR] = [T].[CNTR] 
	AND [TCA].[Cusn] = [CF].[CNUM]

UNION

SELECT 
	[CF].[KEY] AS CustomerKey,
	LTRIM([TCA].[Cusn]) AS CustomerNumber,
	[CF].[NAME] AS CustomerName,
	[CF].[Address] AS CustomerAddress,
	[CF].[CITY] AS CustomerCity,
	[CF].[ZIP] AS CustomerZip,
	[CFT].[Description] AS CustomerType,
	([TCA].[Date]) As Posted_Date,
	([TCA].[RentTX] + [TCA].[RentNT]) AS Rent, 
	([TCA].[SaleTX] + [TCA].[SaleNT]) AS Sale,
	([TCA].[AssetTX] + [TCA].[AssetNT]) AS Asset,
	([TCA].[DWTx] + [TCA].[DWNT]) AS DmgWvr,
	Other,
	[TCA].[Tax] AS SalesTax,
	([TCA].[RentTx] + [TCA].[SaleTx] + [TCA].[DwTx] + [TCA].[AssetTx] + [TCA].[RentNT] + [TCA].[SaleNT] 
		+ [TCA].[DwNT] + [TCA].[AssetNT] + [TCA].[Other] + [TCA].[Tax] + [TCA].[ItemPercentageTax] + [TCA].[ItemPercentageNonTax]) AS RevenueWithTax, 
	([TCA].[RentTx] + [TCA].[SaleTx] + [TCA].[DwTx] + [TCA].[AssetTx] + [TCA].[RentNT] + [TCA].[SaleNT] 
		+ [TCA].[DwNT] + [TCA].[AssetNT] + [TCA].[Other] + [TCA].[ItemPercentageTax] + [TCA].[ItemPercentageNonTax]) AS RevenueWithOutTax,
	[SR].[Name] AS SalesRepName,
	[TCA].[CNTR] AS [Contract],
	[CJ].[Number] AS JobsiteNumber, 
	[CJ].[Description] AS JobsiteName,	
	[TCA].[Salesman] AS [Salesman],
	[SR].[Inactive] AS [InactiveSalesRep],
	[TCA].[Store] AS [Store]
FROM 
	TotalsContractsAccrual TCA
	LEFT JOIN Salesman SR ON [TCA].[Salesman] = [SR].[Number],
	CustomerFile CF
	LEFT JOIN CustomerType CFT ON [CF].[Type] = [CFT].[Type],
	TransHistory T
	LEFT JOIN  CustomerJobSite CJ ON [T].[JobSite] = [CJ].[Number]
WHERE 
	[TCA].[CNTR] = [T].[CNTR] 
	AND [TCA].[Cusn] = [CF].[CNUM]
go

