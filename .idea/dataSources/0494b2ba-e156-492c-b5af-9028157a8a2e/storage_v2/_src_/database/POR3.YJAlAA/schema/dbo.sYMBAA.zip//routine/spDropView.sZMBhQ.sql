
CREATE PROCEDURE DBO.spDropView
(
	@sViewName			VARCHAR(500)
)

AS

/*****************************************************************************************/
--	POR.DBO.spDropView
--		Drops a temporary view created by the client.  
--
--	PARAMETERS: @sViewName  - The name of a view
--
--	HISTORY:	11/19/2014	JY	CREATED	--
--
--
/*****************************************************************************************/

BEGIN

	DECLARE @ssql	VARCHAR(600)

	IF (object_id('POR.DBO.' + @sViewName) > 0)
	BEGIN
		set @ssql = 'DROP VIEW ' + @sViewName
		exec(@ssql)
	END

END

go

