
CREATE PROCEDURE [dbo].[spAT_UpdateExportedContractAsPosted](
 @pilAxpId int 
,@pilIvcId int
,@pisAccNo varchar(20)
,@pilTxId Int
,@pisTxLink varchar(255)
,@posErrorMsg varchar(512) OUTPUT -- any user / server error
) 
--WITH ENCRYPTION 
AS

SET NOCOUNT ON
SET @posErrorMsg = NULL
DECLARE @lErrorNo Int

UPDATE dbo.AccountingAPIQueueTR
SET    DatePosted = GetDate()
  	   ,DateChanged = GetDate()      
	   ,DateError = NULL
	   ,DateCancelled = NULL
	   ,ErrorMsg = NULL
	   ,ExternalId = (CASE When @pilTxId > 0 THEN CAST(@pilTxId AS VARCHAR(255)) ELSE @pisTxLink END)
	   ,AccountingLink = (CASE When @pilTxId > 0 THEN CAST(@pilTxId AS VARCHAR(255)) ELSE @pisTxLink END)
WHERE  Id = @pilIvcId

Update dbo.Transactions
   SET AccountingLink = (CASE When @pilTxId > 0 THEN CAST(@pilTxId AS VARCHAR(255)) ELSE @pisTxLink END)
  FROM AccountingAPIQueueTR
 WHERE Transactions.CNTR = AccountingAPIQueueTR.ContractNumber
   AND AccountingAPIQueueTR.Id = @pilIvcId

RETURN

go

grant execute on spAT_UpdateExportedContractAsPosted to PORUser
go

