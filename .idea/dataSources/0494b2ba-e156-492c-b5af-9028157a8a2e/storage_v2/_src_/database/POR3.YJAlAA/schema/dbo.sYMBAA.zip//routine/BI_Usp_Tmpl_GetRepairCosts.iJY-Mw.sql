
-- =============================================
-- Author:		MM
-- Create date: 12/22/2016
-- Last Updated by: MM
-- Last Updated on: 05/11/2017
-- Description:	Retrieves Repair Cost Widget Template Data
-- Last Update Note: Changed Date Variables to start on Sundays, added Else to Case Statement --MM
-- =============================================

CREATE PROCEDURE [dbo].[BI_Usp_Tmpl_GetRepairCosts]
	@WidgetDataFilter KeyValuePair READONLY -- pass parameters via Table Type Param
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @StoreNo nvarchar(20) = null;
	SET @StoreNo	= (SELECT	SUBSTRING([Value], 1, 20)	FROM @WidgetDataFilter WHERE [Key] = 'StoreNo');

	--Declare @CurrentDate datetime = null;
	--Set @CurrentDate	= (SELECT	CAST([Value] AS DATETIME)	FROM @WidgetDataFilter WHERE [Key] = 'CurrentDate');

	DECLARE	@CurrentDate datetime = null
	--SET current date to either the given date or default to today-----------
	SET @CurrentDate = (Case When @CurrentDate IS NULL Then GETDATE() ELSE @CurrentDate END) 
	DECLARE @CurrentWeekStart datetime = DATEADD(wk, DATEDIFF(wk, 0, @CurrentDate), -1) -- Sundays
	DECLARE @LastWeekStart datetime = DATEADD(wk, DATEDIFF(wk, 6, @CurrentDate), -1) -- Sundays
	DECLARE @CurrentMonthStart datetime = DATEADD(mm,DATEDIFF(mm,0,@CurrentDate),0)
	DECLARE @LastMonthStart datetime = DATEADD(mm, -1, @CurrentMonthStart)

	SELECT 
			MainTbl.[Type],
			SUM([MainTbl].PAID) as [Total]
			FROM
				(SELECT DISTINCT TE.CNTR,TE.[Store], 'Open Now' as [Type], TE.PAID
					FROM TransactionEdit AS TE
					INNER JOIN Transactions T ON TE.CNTR = T.CNTR
					WHERE Left([TE].[CNTR],1)='r' AND Left([T].[STAT],1)='O'
				UNION
				SELECT DISTINCT TE.CNTR, TE.[Store],
					(CASE	WHEN [TE].[Date] BETWEEN  @CurrentWeekStart and @CurrentDate Then 'This Week'
							WHEN [TE].[Date] BETWEEN  @LastWeekStart and @CurrentDate Then 'Last Week' 
							WHEN [TE].[Date] >=  @LastMonthStart and [TE].[Date] < @CurrentMonthStart Then 'Last Month' 
							ELSE 'Rest of this Month'
							 END) as [Type],
					TE.PAID
					FROM
					(SELECT T.CNTR,T.[Store], T.[Date], T.PAID, T.Stat
						FROM TransactionEdit T
						WHERE Left([T].[CNTR],1)='r' AND [T].[Date] BETWEEN  @LastMonthStart AND @CurrentDate) AS TE
					INNER JOIN
					(SELECT T.CNTR 
						FROM Transactions T 
						WHERE Left([T].[STAT],1) In (' ','C')
						UNION
						Select T.CNTR 
						FROM TransHistory T
						WHERE Left([T].[STAT],1) In (' ','C')
						) as Hist
					ON TE.CNTR = Hist.CNTR
			) AS MainTbl
			WHERE @StoreNo IS NULL OR @StoreNo = 'All' OR @StoreNo = '000' OR [MainTbl].[Store] = @StoreNo
			GROUP BY MainTbl.[Type]

END
go

