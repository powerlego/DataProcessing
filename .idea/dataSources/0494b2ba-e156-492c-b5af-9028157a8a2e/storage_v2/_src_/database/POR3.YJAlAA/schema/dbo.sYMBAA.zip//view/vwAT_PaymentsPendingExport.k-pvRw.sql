
CREATE VIEW [dbo].[vwAT_PaymentsPendingExport] 
--WITH ENCRYPTION 
AS
SELECT 
 Tr.TransDate										AS CTX_DATE
,Tr.Id											    AS CTX_ID
,CASE WHEN Tr.TransCodeId IN (40,43) 
		THEN ISNULL(Trd.OffsetAccountNumber,'')
	  ELSE ISNULL(Tr.AccountNumber,'') END			AS BANK_ACCOUNT	
,Tr.TransAmount										AS CTX_AMOUNT
,CASE WHEN Tr.TransCodeId IN (40,43) 
		THEN CAST(1 AS BIT)
	  ELSE CAST(0 AS BIT) END						AS IS_CREDIT
,CAST(1 AS Bit)										AS IS_CASH
,CAST(0 AS Decimal(12,2))							AS CTX_UNALLOC_SA_AMOUNT
,NULL												AS CTX_UNALLOC_SA_TXID
,Tr.ContractNumber									AS IVC_USER_INVOICE_NUMBER
-- Need to derive invoice type
,CASE WHEN LEFT(T.CNTR,1) = 'c' THEN 'CREDIT'
	  WHEN Tr.TransCodeId = 7 THEN 'ACCOUNT'
	  WHEN Tr.TransCodeId = 15 THEN 'CASH'
	  Else 'CONTRACT' END						    AS IVC_INVOICE_TYPE
,Tr.Id												AS IVC_UNPAID_TX_ID
,Tr.ContractNumber									AS SOURCE_DOC_REFNO
,'C'												AS SOURCE_DOC_TYPE
,Tr.Id												AS SOURCE_DOC_ID
--,RTRIM(LTRIM(Tr.CustomerNumber))					AS ACCOUNT_NO
,RTRIM(LTRIM(ac.AccountingLink))					AS ACCOUNT_NO
,CASE When Tr.TransCodeId = 13
	  THEN 'Paid Prior to Close'
	  ELSE '' END									AS CTX_NOTES
,''													AS ADJ_NOMINAL_CODE
,Tr.Store											AS DEPOT_DEPARTMENT
FROM AccountingAPIQueueTR Tr
INNER JOIN Transactions T ON T.CNTR = Tr.ContractNumber
INNER JOIN CustomerFile cf ON cf.CNUM = Tr.CustomerNumber
LEFT OUTER JOIN AccountingCustomer ac ON ac.id = cf.AccountingCustomerId
--INNER JOIN AccountNumbers AcctNos on AcctNos.Store = Tr.Store
--INNER JOIN ExportFormat x ON x.ExportFormatId = AcctNos.ExportFormat
--LEFT OUTER JOIN CustomerFile cfx ON cfx.CNUM = x.GenericCashCustomerNumber
--LEFT OUTER JOIN AccountingCustomer acx ON acx.id = cfx.AccountingCustomerId
LEFT OUTER JOIN AccountingAPIQueueTRDetail Trd ON Trd.AccountingAPIQueueTRId = Tr.Id
Where Tr.DatePosted Is NUll
  AND Tr.DateCancelled Is NULL
  AND tr.TransCodeId in (10,13,40,43)
  AND Tr.Direction = 1
  AND Tr.NoExport = 0
  AND Tr.RetryCount <= 10
  --AND ISNULL(T.AccountingLink,'') <> ''

go

grant select on vwAT_PaymentsPendingExport to PORUser
go

