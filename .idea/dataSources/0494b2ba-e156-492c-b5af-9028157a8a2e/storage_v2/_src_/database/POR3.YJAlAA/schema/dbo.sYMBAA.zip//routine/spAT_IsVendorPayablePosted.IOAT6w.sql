
CREATE  PROCEDURE [dbo].[spAT_IsVendorPayablePosted](
 @pilPivId Int
,@pobIsPosted Bit OUTPUT
) 
-- WITH ENCRYPTION
AS
SET NOCOUNT ON

IF EXISTS (SELECT 1 
           FROM  dbo.AccountingAPIQueuePO
           WHERE AccountingAPIQueuePOId = @pilPivId
           AND   DatePosted Is Not Null)
  SET @pobIsPosted = 1
ELSE
  SET @pobIsPosted = 0

RETURN

go

grant execute on spAT_IsVendorPayablePosted to PORUser
go

