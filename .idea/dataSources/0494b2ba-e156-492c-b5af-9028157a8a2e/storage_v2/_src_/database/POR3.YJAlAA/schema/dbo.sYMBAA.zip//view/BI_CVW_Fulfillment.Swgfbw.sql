-- SQL Deploy  3/29/2018 8:38 AM
CREATE VIEW [dbo].[BI_CVW_Fulfillment]
 
AS
SELECT      dbo.TransactionItemsSerialization.OpNo AS OperatorNumber, dbo.OperatorId.OPNM AS OperatorName, 
CAST(dbo.TransactionItemsSerialization.TimeStamp AS date) AS DateStamp, 
DATEPART(HOUR, dbo.TransactionItemsSerialization.TimeStamp) AS Hour, 
DATEPART(WEEKDAY, dbo.TransactionItemsSerialization.TimeStamp) AS DayOfWeek, 
DATEPART(MONTH, dbo.TransactionItemsSerialization.TimeStamp) AS Month, 
DATEPART(YEAR, dbo.TransactionItemsSerialization.TimeStamp) AS Year, 
dbo.TransactionItemsSerializationAction.Description AS Action, SUM(dbo.TransactionItemsSerialization.Quantity) AS Qty, 
dbo.TransactionItemsSerialization.Cntr AS Contract,
sum(dbo.TransactionItemsSerialization.Quantity*dbo.ItemFile.Weight) as Weight
FROM            dbo.TransactionItemsSerialization 
INNER JOIN     dbo.TransactionItemsSerializationAction ON dbo.TransactionItemsSerialization.ActionId = dbo.TransactionItemsSerializationAction.ActionId 
INNER JOIN     dbo.OperatorId ON dbo.TransactionItemsSerialization.OpNo = dbo.OperatorId.OPNO
INNER JOIN     dbo.ItemFile ON dbo.TransactionItemsSerialization.Num = dbo.ItemFile.Num
GROUP BY	dbo.TransactionItemsSerialization.OpNo, dbo.OperatorId.OPNM, 
CAST(dbo.TransactionItemsSerialization.TimeStamp AS date), 
DATEPART(HOUR,dbo.TransactionItemsSerialization.TimeStamp), 
DATEPART(WEEKDAY, dbo.TransactionItemsSerialization.TimeStamp), 
DATEPART(MONTH, dbo.TransactionItemsSerialization.TimeStamp), 
DATEPART(YEAR, dbo.TransactionItemsSerialization.TimeStamp), 
dbo.TransactionItemsSerializationAction.[Description], 
dbo.TransactionItemsSerialization.Cntr

go

