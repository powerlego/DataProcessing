
-- required stub only
CREATE FUNCTION dbo.fnAT_InvoiceSourceCode
(
   @ContractNumber   VARCHAR(20)
)
RETURNS VARCHAR(1)
-- WITH ENCRYPTION
AS

BEGIN
   DECLARE @SourceCode VarChar(1) 

   SET @SourceCode = 'H'

 
   RETURN ISNULL(@SourceCode,'H');
END
go

