

CREATE PROCEDURE [dbo].[spItemSearch]
       @SearchValue varchar(100),
       @MaxResults   int = null,
       @Store        varchar(3) = null,
       @inactive     bit = null,
       @rentalItems bit = null,
       @saleItems bit = null,
       @partsItems bit = null,
       @zeroQuantity bit = null,
       @serializedItems bit = null,
       @componentItems            bit = null,
       @sharedInventory     bit = null

AS
BEGIN
       -- SET NOCOUNT ON added to prevent extra result sets from
       -- interfering with SELECT statements.
       SET NOCOUNT ON;

    -- Insert statements for procedure here
       SELECT TOP (ISNULL(@MaxResults , 500)) 
              outerItemFileTable.NUM AS 'Number', 
              [KEY] as 'Key' ,
              OwnedQty as 'Owned', 
              QtyAvail as 'Available', 
                       
              QuantityOnOrder,
              SUBR,
              PartNumber, 
              SerialNumber,
                       
              SDATE,
              HomeStore, 
              CurrentStore, 
              [Name], 
              DescriptionLong,
                            
              [Lookup],
              DEP,
              RATE1,
              PER1,
              RATE2,
              PER2,
              RATE3,
              PER3,
                            
              RATE4,
              PER4,
              RATE5,
              PER5,
              RATE6,
              PER6,
              RATE7,
              PER7,
              RATE8,
              PER8,
              RATE9,
              PER9,
              RATE10,
              PER10,
              SELL,
              RetailPrice,
              IncomeDmgWvr,
                       
              ItemPercentage,
              INST,
              FUEL,
              ADDT,
              MANF,
                            
              MODN,
              ModelYear,
              RMIN,
              RMAX,
              CaseQty,
              MTIN,
                       
              MTOT,
              PURD,
              PURP,
              REPC1,
              SubrentCostYTD,
                       
              TMOT1,
              TMOT2,
              TMOT3,
              HROT1,
              HROT2,
                       
              HROT3,
              LDATE,
              Asset,
              GLAccount,
              DeprecAccount,

                       [Group],
              Location,
              TaxCode,
              Nontaxable,
              NonDiscountable,
                       
              Header,
              License,
              Sort,
              NoPrintOnContract,
              VehicleType,
                       
              VehicleEIN,
              [Weight],
              SetupTime,
              WebGroup,
              WebLink,
                       
              HideOnWebsite,
              Category,
              [TYPE] as 'Type',
              Department,
              UserDefined1, 
                       
              UserDefined2,
              QTY,
              QtyCountDifference,
              ReplacementCost,
              Style1,
              
              Style2,
              Style3,
              IRO as 'InternalRepairOrder', 
              IMO as 'InternalMaintenanceOrder', 
                       
              OnRent, 
              IC.Specs,
              LOC,
              inactive,
              RESD,
              QYOT,
              CNTR
              
    FROM ItemFile AS outerItemFileTable 
       LEFT JOIN
              (SELECT iif(ISNULL(ITF.Header, '') = '', ITF.[KEY], ITF.Header) AS ItemKey, 
                           max(iif(ITF.Header = '', ITF.Name, ITF_h.Name)) AS ItemName,
                           max(ITF.Type) AS ItemType, Sum(ITF.QTY) AS OwnedQty, 
                           iif(Sum(ITF.QTY) - (Sum(ItemQty.OnRent) + Sum(ItemQty.IRO)) Is Null, Sum(ITF.QTY - ITF.QYOT), Sum(ITF.QTY) - (Sum(ItemQty.OnRent) + Sum(ItemQty.IRO))) AS QtyAvail, 
                           iif(Sum(ItemQty.OnRent) Is Null, 0, Sum(ItemQty.OnRent)) AS OnRent, 
                           iif(Sum(ItemQty.IRO) Is Null, 0, Sum(ItemQty.IRO)) AS IRO, 
                           iif(Sum(ItemQty.IMO) Is Null, 0, Sum(ItemQty.IMO)) AS IMO
       
              FROM   ItemFile ITF 
                           LEFT JOIN ItemFile AS ITF_h ON ITF.Header =       ITF_h.[KEY]
                           LEFT JOIN ParameterFile PF  ON ITF.CurrentStore = PF.Store
                           LEFT JOIN ItemCategory ITC  ON ITF.Category =     ITC.Category
                           LEFT JOIN ItemDivision ITD  ON ITC.DivisionNumber = ITD.DivisionNumber
                           LEFT JOIN ( 
										SELECT	TI.ITEM, 
												sum(iif(Left(TI.CNTR,1)<>'r' and not(TI.TXTY In ('RR','RX')) ,TI.Qty,0)) AS OnRent, 
												sum(iif(Left(TI.CNTR,1)='r' and Not(TI.TXTY In ('RR','RX')),TI.Qty,0)) AS IRO,
												sum(iif(Left(TI.CNTR,1)='r' and TI.TXTY In ('RR','RX'),TI.Qty,0)) AS IMO
										FROM	((TransactionItems TI 
												INNER JOIN Transactions T ON TI.CNTR = T.CNTR)
												INNER JOIN ItemFile ITF ON TI.Item = ITF.Num)
												INNER JOIN CustomerFile CF ON T.CUSN = CF.CNUM
										WHERE	Left(TI.CNTR,1) Not In ('c','f','l','q','t','w') AND
												Left(TI.TXTY,1) = 'R' and
												Left(T.STAT,1) = 'O'
										GROUP BY TI.Item
                                      ) AS ItemQty ON ITF.Num = ItemQty.Item
                       WHERE not(ITF.[TYPE] in ('e','v'))
              GROUP BY iif(ISNULL(ITF.Header, '') = '', ITF.[KEY], ITF.Header)
    ) AS ItemSearch ON ItemSearch.ItemKey = outerItemFileTable.[KEY]
    LEFT JOIN ItemComments AS IC ON outerItemFileTable.NUM = IC.NUM
      WHERE ( 
                  (outerItemFileTable.[KEY]        Like '%'+ @SearchValue +'%' or 
            outerItemFileTable.Name         Like '%'+ @SearchValue +'%' or 
            outerItemFileTable.PartNumber   Like '%'+ @SearchValue +'%' or 
            outerItemFileTable.NUM          Like '%'+ @SearchValue +'%' or 
            outerItemFileTable.[Lookup]       Like '%'+ @SearchValue +'%')
               ) 
          and (
                     (((@sharedInventory IS NULL OR @sharedInventory = 1) and @Store <> '000') and 
                      (outerItemFileTable.CurrentStore = @Store OR outerItemFileTable.CurrentStore = '000'))
                     or
                     (@sharedInventory = 0 and @Store <> '000' and outerItemFileTable.CurrentStore = @Store)
                     or
                     (@sharedInventory = 0 and @Store = '000' and outerItemFileTable.CurrentStore <> '000')
                     or 
                     (((@sharedInventory IS NULL OR @sharedInventory = 1) and @Store = '000') and
                     (outerItemFileTable.CurrentStore <> '000' OR outerItemFileTable.CurrentStore = '000'))
                     )
          and (
                     (@inactive IS NULL OR @inactive = 1) or (@inactive = 0 AND outerItemFileTable.Inactive = 0)  
                     )
          and  (
                     ((@rentalItems IS NULL OR @rentalItems = 1) AND 
                        outerItemFileTable.[TYPE] IN ('A','H','L','N','R','T','U','V','K','D')) or
                     ((@saleItems IS NULL OR @saleItems = 1) AND 
                        outerItemFileTable.[TYPE] IN ('F','M','P','S','E','B')) or
                     ((@partsItems IS NULL OR @partsItems = 1) AND 
                        outerItemFileTable.[TYPE] IN ('W','O', 'I'))
                     )
          and  (
                     (@zeroQuantity IS NULL OR @zeroQuantity = 1)
                     or
                     (@zeroQuantity = 0 AND (outerItemFileTable.QTY + outerItemFileTable.SUBR) <> 0)
                     or 
                     (@zeroQuantity = 0 AND outerItemFileTable.[TYPE] IN ('F','M','P','S','E','B'))
                     )
          and  (
                     (@serializedItems IS NULL OR @serializedItems = 1)
                     or 
                     (@serializedItems = 0 AND 
                       (ltrim(rtrim(outerItemFileTable.Header)) = '' or outerItemFileTable.Header Is Null or outerItemFileTable.[Type] in ('V','E')))
                     ) 
          and  (
                     (@componentItems IS NULL OR @componentItems = 1)
                     or 
                     (@componentItems = 0 AND outerItemFileTable.NoPrintOnContract <> 1)
                     )             
                                                 
ORDER BY outerItemFileTable.[KEY]

END

go

