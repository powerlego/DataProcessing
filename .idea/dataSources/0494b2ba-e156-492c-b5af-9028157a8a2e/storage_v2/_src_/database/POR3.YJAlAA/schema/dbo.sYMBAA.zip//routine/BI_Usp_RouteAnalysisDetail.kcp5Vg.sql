
CREATE PROCEDURE [dbo].[BI_Usp_RouteAnalysisDetail]
@WidgetDataFilter KeyValuePair READONLY

AS
BEGIN

SET NOCOUNT ON;

-- Default values ----------------------
DECLARE @StartDate    Date = CONVERT(Date, DATEADD(day,-7,GETDATE())),
		@EndDate      Date = CONVERT(Date, GETDATE()),
		@Driver       NVarChar(50) = 'All',
		@StoreNo      NVarChar(3) = null,
		@DateFormat	  NVarchar(5) = 'en-US';

-- Set value from Filter Object only if present --------------
SELECT @StartDate = CAST([Value] AS DATE)	FROM @WidgetDataFilter WHERE [Key] = 'StartDate';
SELECT @EndDate	= CAST([Value] AS DATE)	FROM @WidgetDataFilter WHERE [Key] = 'EndDate';
SELECT @StoreNo = SUBSTRING([Value], 1, 20) FROM @WidgetDataFilter WHERE [Key] = 'StoreNo';
SELECT @Driver  = SUBSTRING([Value], 1, 50) FROM @WidgetDataFilter WHERE [Key] = 'Driver';
SELECT @DateFormat	= [Value] FROM @WidgetDataFilter WHERE [Key] = 'DateFormat';

SELECT Format(MainTbl.[Trip Date],'d', @DateFormat) AS [TripDate], 
		CAST(MainTbl.[Route] AS VARCHAR) as [Route], 
		MainTbl.Store, 
		MainTbl.Driver, 
		count(MainTbl.ContractNumber) AS [Stops], 
		sum(MainTbl.ReqOnTime) AS [ReqNumberLate], 
		sum(MainTbl.PlannedOnTime) AS [PlanNumberLate],
		sum(MainTbl.ReqDiff) AS [ReqMinutesLate], 
		sum(MainTbl.PlannedDiff) AS [PlanMinutesLate]

FROM ( SELECT Main.*,

                    iif(Main.ActualArrival Is Null,0,iif(Main.ActualArrival <= Main.ReqByTime,0,1)) AS ReqOnTime,

                    iif(Main.ActualArrival Is Null or Main.Planned Is Null,0,iif(Main.ActualArrival <= Main.Planned,0,1)) AS PlannedOnTime,

                    iif(Main.ActualArrival Is Null,0,iif(Main.ActualArrival > Main.ReqByTime,DateDiff(Minute,Main.ReqByTime,Main.ActualArrival),0)) AS ReqDiff,

                    iif(Main.ActualArrival Is Null,0,iif(Main.ActualArrival > Main.Planned,DateDiff(Minute,Main.Planned,Main.ActualArrival),0)) AS PlannedDiff

              FROM (

                      SELECT MRD.ContractNumber, MR.routeNumber AS [Route], Convert(Date,MR.tripDate) AS [Trip Date], iif(@StoreNo IS NULL OR @StoreNo = '000' OR @StoreNo = 'All','All',MR.startStore) AS Store,

                                MR.driverID AS [Driver ID], OPR.OPNM AS [Driver], MRD.preferredArrival AS [Required],

                                DATEADD(day, DATEDIFF(day, 0, CONVERT(Date,MRD.preferredArrival)), CONVERT(datetime,CONVERT(TIME,IIF(MRD.MPEstimatedArrivalTime is null, '', MRD.MPEstimatedArrivalTime)))) AS Planned,

                                (CASE

                                    WHEN DATEPART(HOUR,   MRD.preferredArrival) = 00 THEN CONVERT(DateTime, DateDiff(Day,1,Convert(Date, MRD.preferredArrival)))

                                    WHEN DATEPART(SECOND, MRD.preferredArrival) = 00 THEN MRD.preferredArrival

                                    WHEN DATEPART(SECOND, MRD.preferredArrival) = 42 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST('12:30 PM' AS Datetime))

                                    WHEN DATEPART(SECOND, MRD.preferredArrival) > 42 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST(CONCAT(DATEPART(SECOND, MRD.preferredArrival) - 42, ':30 PM') AS Datetime))

                                    WHEN DATEPART(SECOND, MRD.preferredArrival) > 29 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST(CONCAT(DATEPART(SECOND, MRD.preferredArrival) - 30,':30 AM') AS Datetime))

                                    WHEN DATEPART(SECOND, MRD.preferredArrival) > 12 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST(CONCAT(DATEPART(SECOND, MRD.preferredArrival) -12, ':00 PM') AS Datetime))

                                    WHEN DATEPART(SECOND, MRD.preferredArrival) = 12 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST('12:00 PM' AS Datetime))

                                    WHEN DATEPART(SECOND, MRD.preferredArrival) < 12 THEN DATEADD(Day,DATEDIFF(day,0,MRD.preferredArrival),CAST(CONCAT(DATEPART(SECOND, MRD.preferredArrival),':00 AM') AS Datetime))

                                END) AS ReqByTime, MRD.ActualArrival

                           FROM MapRouteDetails MRD

							INNER JOIN MapRoutes MR ON MRD.routeNumber = MR.routeNumber

							INNER JOIN OperatorID OPR ON MR.driverID = OPR.OPNO

                           WHERE MR.tripDate >= @StartDate AND

                                    MR.tripDate <= @EndDate AND

                                    MR.driverID > 0 AND

                                    MR.startStore <> '000' AND

                                    (@Driver IS NULL OR @Driver = 'All' OR @Driver = OPR.OPNM) AND
                                    
                                    (@StoreNo IS NULL OR @StoreNo = 'All' OR @StoreNo = '000' OR (@StoreNo LIKE '%' + MR.startStore + '%'))

                           ) AS Main

              ) AS MainTbl

GROUP BY MainTbl.[Trip Date], MainTbl.[Route], MainTbl.Store, MainTbl.Driver
ORDER BY MainTbl.[Trip Date] DESC

--HAVING sum(MainTbl.PlannedDiff) + sum(MainTbl.ReqDiff) <> 0

END
go

