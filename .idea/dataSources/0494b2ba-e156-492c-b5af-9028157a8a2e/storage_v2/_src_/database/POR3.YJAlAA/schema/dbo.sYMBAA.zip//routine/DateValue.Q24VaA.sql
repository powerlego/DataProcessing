
-- =============================================
-- Author:		JA
-- Create date: 
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[DateValue] 
(
	-- Add the parameters for the function here
	@DTVal [Date]
)
RETURNS [Date]
AS
BEGIN
	-- Declare the return variable here
	DECLARE  @ret [Date]

	-- Add the T-SQL statements to compute the return value here
	SELECT @ret  = Convert(NVARCHAR(10),@DTVal,101)

	-- Return the result of the function

	RETURN @ret

END
go

