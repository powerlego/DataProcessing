
CREATE PROCEDURE [dbo].[spAT_GetContractForExport](
 @pilInvNumber Int
) 
-- WITH ENCRYPTION
AS
SET NOCOUNT ON

DECLARE @sIVC_INVOICE_SOURCE Varchar(1)
DECLARE @lContractNumber Int
SELECT @sIVC_INVOICE_SOURCE = CASE WHEN LEFT(ContractNumber,1) = 'r' THEN 'S'
								   ELSE 'H' END ,
	   @lContractNumber = Id
FROM   dbo.AccountingAPIQueueTr
WHERE  Id = @pilInvNumber

SELECT 
 Tr.Id															AS HCT_CONTRACT_NUMBER
 ,CASE cst.Status
	  WHEN 'E' THEN RTRIM(LTRIM(ac.AccountingLink))
	  ELSE RTRIM(LTRIM(acx.AccountingLink)) END				AS HCT_CUSTOMER_ID

,Tr.ContractNumber												AS HCT_USER_CONTRACT_NUMBER
,2																AS HCT_INVOICE_WHEN
,CASE 
	-- If this is a fully paid contract (15) and the customer
	-- has not already been exported, use the generic cash customer
WHEN tr.TransCodeId = 15 AND ac.AccountingLink IS NULL
	THEN RTRIM(LTRIM(ISNULL(acx.[AccountingLink], x.GenericCashCustomerNumber))) 
ELSE RTRIM(LTRIM(ISNULL(ac.[AccountingLink], tr.CustomerNumber)))  END					AS ACCNO
,Cast(Tr.Store As Int)											AS HCT_DEPOT_ID
,ISNULL(Tr.CustomerPONumber,'')									AS HCT_CUSTOMER_REFERENCE
,Tr.TransDate													AS IVC_INVOICE_DATE
,Tr.Id															AS IVC_INVOICE_NUMBER
,ISNULL(Tr.ContractNumber,'')									AS IVC_USER_INVOICE_NUMBER
,ABS(Tr.TaxAmount)												AS IVC_SALESTAX
,1															    AS IVC_HAS_LINES
,ISNULL(ce.AccountingLink, '')									AS CUR_ACCOUNTS_CURRENCY_CODE
,Cast(ISNULL(tr.ExchangeRate,1) AS REAL)					    AS IVC_EXCH_RATE
,CASE 
	-- If this is a fully paid contract (15) and the customer
	-- has not already been exported, use the generic cash customer
	WHEN tr.TransCodeId = 15 AND ac.AccountingLink IS NULL
		THEN ISNULL(cfc.[NAME],'') 
	ELSE ISNULL(cst.[NAME],'')  END								AS CST_NAME
--, CASE cst.Status
--		WHEN 'E' THEN cst.[NAME] 
--		ELSE cfc.[NAME]  END									AS CST_NAME
,''																AS ACCOUNTS_DEPT
,CAST(stm.number as VARCHAR(12))								AS SALESPERSON_CODE
,''																AS IFT_NAME -- remove 3.28.
,''																AS IFT_ACCOUNTS_CODE
,Tr.TransDate													AS CONFIRMED_DATE
,CASE Tr.TransCodeId
	WHEN 40 THEN 'CREDIT'
	WHEN 43 THEN 'CREDIT'
	WHEN 7 THEN 'ACCOUNT'
	WHEN 15 THEN 'CASH'
	Else 'OTHER' END											 AS IVC_INVOICE_TYPE
,''																 AS IVC_BOTTOM_TITLE
, ISNULL(T.Nontaxable,0)										 AS NonTaxable
FROM ((((((((dbo.AccountingAPIQueueTr AS Tr
        INNER JOIN dbo.CustomerFile AS cst
          ON Tr.CustomerNumber = cst.CNUM) 
	    INNER JOIN dbo.Transactions AS T
	      ON T.CNTR = tr.ContractNumber)
		INNER JOIN AccountNumbers A 
		  ON A.Store = tr.Store)
        LEFT OUTER JOIN dbo.CurrencyExchange AS ce  
          ON T.CurrencyNumber = ce.CurrencyNumber)
        LEFT OUTER JOIN dbo.Salesman AS stm
          ON t.Salesman = stm.Number)
		LEFT OUTER JOIN AccountingCustomer ac
		  ON ac.id = cst.AccountingCustomerId)
		LEFT OUTER JOIN ExportFormat X 
		  ON X.ExportFormatId = A.ExportFormat)
		LEFT OUTER JOIN CustomerFile cfc 
		  ON cfc.CNUM = x.GenericCashCustomerNumber)
		  LEFT OUTER JOIN AccountingCustomer acx ON acx.id = cfc.AccountingCustomerId

WHERE Tr.Id = @pilInvNumber

RETURN
go

grant execute on spAT_GetContractForExport to PORUser
go

