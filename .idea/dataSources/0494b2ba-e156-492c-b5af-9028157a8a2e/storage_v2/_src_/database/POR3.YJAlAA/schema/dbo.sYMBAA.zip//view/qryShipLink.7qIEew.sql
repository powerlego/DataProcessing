CREATE VIEW qryShipLink
AS


SELECT RTrim(LTrim(Transactions.CNTR)) AS ContractNumber,
 
-- Name
--IIf(Transactions.SameAddress=True,CustomerFile.Name, IIf(Trim([Transactions.DeliverToCompany])="",CustomerFile.Name,Transactions.DeliverToCompany)) AS Name, 
IIf(Transactions.SameAddress=1,
	CustomerFile.Name, 
	IIf(RTrim(LTrim(Transactions.[DeliverToCompany]))='', 
		CustomerFile.Name, 
		Transactions.[DeliverToCompany])) AS Name ,

-- Contact
--IIf(Len(Trim(Transactions.Contact))=0, IIf(Len(Trim(Transactions.OrderedBy))=0,"",Transactions.OrderedBy),Transactions.Contact) AS Contact, 
 IIf(Len(RTrim(LTrim(Transactions.Contact)))=0,
	IIf(Len(RTrim(LTrim(Transactions.OrderedBy)))=0,
		'',
		Transactions.OrderedBy),
	Transactions.Contact) AS [Contact], 

-- Address1
--IIf(Transactions.SameAddress=True,CustomerFile.Address,Transactions.DeliveryAddress) AS Address1, 
IIf(Transactions.SameAddress=1,
	CustomerFile.[Address],
	Transactions.DeliveryAddress) AS Address1, 

-- City
--IIf(Transactions.SameAddress=True,IIf(InStr(1,CustomerFile.City,",")>0,Left(CustomerFile.City,InStr(1,CustomerFile.City,",")-1),CustomerFile.City),IIf(InStr(1,DeliveryCity,",")>0,Left(DeliveryCity,InStr(1,DeliveryCity,",")-1),DeliveryCity)) AS City, 
IIf(Transactions.SameAddress=1,
	IIf(CharIndex(',',CustomerFile.City)>0, 
		Left(CustomerFile.City, CharIndex(',',CustomerFile.City)-1), 
		CustomerFile.City),
	IIf(CharIndex(',',DeliveryCity)>0, 
		Left(DeliveryCity,CharIndex(',',DeliveryCity)-1), 
		DeliveryCity)) AS City, 

-- State
--IIf(Transactions.SameAddress=True,IIf(InStr(1,CustomerFile.City,",")>0,Trim(Mid(CustomerFile.City,InStr(1,CustomerFile.City,",")+1)),""),IIf(InStr(1,DeliveryCity,",")>0,Trim(Mid(DeliveryCity,InStr(1,DeliveryCity,",")+1)),"")) AS State, 
IIf(Transactions.SameAddress=1,
	IIf(CharIndex(',',CustomerFile.City)>0,
		Rtrim(Ltrim(SubString(CustomerFile.City,CharIndex(',',(CustomerFile.City))+1,len(Customerfile.City)-CharIndex(',',(CustomerFile.City))))),
		''),
	IIf(CharIndex(',',DeliveryCity)>0,
		Rtrim(Ltrim(SubString(DeliveryCity,CharIndex(',',(DeliveryCity))+1,len(DeliveryCity)-CharIndex(',',(DeliveryCity))))),
		'')) AS [State], 

-- ZIP
--IIf(Transactions.SameAddress=True,CustomerFile.Zip,Transactions.DeliveryZip) AS Zip, 
IIf(Transactions.SameAddress=1,
	CustomerFile.Zip,
	Transactions.DeliveryZip) AS Zip, 

-- COUNTRY
--IIf(IsNumeric(IIf(Transactions.SameAddress=True,CustomerFile.Zip,Transactions.DeliveryZip)),"USA",IIf(IIf(Transactions.SameAddress=True,CustomerFile.Zip,Transactions.DeliveryZip)="","","Canada")) AS Country, 
IIf(IsNumeric(IIf(Transactions.SameAddress=1,CustomerFile.Zip,Transactions.DeliveryZip)) = 1,
	'USA',
	IIf(IIf(Transactions.SameAddress=1, CustomerFile.Zip, Transactions.DeliveryZip)='',
		'',
		'Canada')) AS Country, 

-- CustomerAddress (0/1)
--Transactions.SameAddress AS CustomerAddress, 
Transactions.SameAddress AS CustomerAddress, 

-- Phone
--IIf(Transactions.SameAddress=True,CustomerFile.Phone,Transactions.ContactPhone) AS Phone, 
IIf(Transactions.SameAddress=1,
	CustomerFile.Phone,
	Transactions.ContactPhone) AS Phone, 

-- Email
--IIf(Len(Trim([Transactions].[OrderedBy]))=0,[CustomerFile].[Email],IIf(Len(Trim((SELECT TOP 1 Authorized.Email FROM Authorized WHERE Authorized.NAME=Transactions.OrderedBy and Authorized.CNUM=Transactions.CUSN)))=0,[CustomerFile].[Email],(SELECT TOP 1 Authorized.Email FROM Authorized WHERE Authorized.NAME=Transactions.OrderedBy and Authorized.CNUM=Transactions.CUSN))) AS Email, 
IIf(Len(LTrim(Rtrim(([Transactions].[OrderedBy]))))=0,
	[CustomerFile].[Email],
	IIf(Len(RTrim(LTrim((SELECT TOP 1 Authorized.Email FROM Authorized WHERE Authorized.NAME=Transactions.OrderedBy and Authorized.CNUM=Transactions.CUSN))))=0,
		[CustomerFile].[Email],
		(SELECT TOP 1 Authorized.Email FROM Authorized WHERE Authorized.NAME=Transactions.OrderedBy and Authorized.CNUM=Transactions.CUSN))) AS Email,

--Transactions.JOBN AS Info, Transactions.JBPO AS PO, Transactions.JBID AS Job, Transactions.JobSite AS Expr1, -1 AS ShipNotification, -1 AS ExcpNotification, -1 AS DelivNotification, CustomerFile.NAME AS CustomerName, Transactions.DeliverToCompany AS DeliverTo, 
Transactions.JOBN AS Info, Transactions.JBPO AS PO, Transactions.JBID AS Job, Transactions.JobSite AS Expr1, -1 AS ShipNotification, -1 AS ExcpNotification, 
-1 AS DelivNotification, CustomerFile.NAME AS CustomerName, Transactions.DeliverToCompany AS DeliverTo, 

-- Address2
--IIf(Transactions.SameAddress=True,CustomerFile.Address2,Transactions.DeliverToCompany) AS Address2
IIf(Transactions.SameAddress=1,
	CustomerFile.Address2,
	Transactions.DeliverToCompany) AS Address2
  FROM Transactions 
  LEFT JOIN CustomerFile ON Transactions.CUSN = CustomerFile.CNUM;
go

